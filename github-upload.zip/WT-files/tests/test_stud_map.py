"""Аналитика → «Шпильки» (3D-карта дефектов шпилек): страница, файлы карты, загрузка реестра, права."""
import datetime as dt
import io
import json
import os

import openpyxl
import pytest

from app import stud_map_data as smd


def _data_dir(app):
    return os.path.join(os.path.dirname(app.config['DB_PATH']), 'stud_map')


def _register_xlsx(rows=None, sheet='Реестр дефектов'):
    """Мини-реестр в формате цеха: колонки A..O как в Stud_Defect_Register_BS."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = sheet
    ws.append(['№', 'Кузов', 'Модель', 'Дата', '', '', '', '', 'Категория', 'Источник', 'Станция', 'Кол-во', '', '', '№ шпильки'])
    for r in rows if rows is not None else [
        (1, '06723', 'A13T', dt.datetime(2026, 11, 10), 'Склейка / Stick Weld (SW)', 'Кузовной цех', 'FRONT FLOOR', 2, 300),
        (2, '7604', 'CS55p', dt.datetime(2026, 11, 16), 'Отсутствует / Missing', 'Кузовной цех', 'REAR FLOOR', 1, None),
    ]:
        n, body, model, date, cat, src, loc, qty, stud = r
        ws.append([n, body, model, date, None, None, None, None, cat, src, loc, qty, None, None, stud])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def test_anonymous_gets_nothing(anon_client):
    assert anon_client.get('/analytics/studs').status_code == 302
    assert anon_client.get('/analytics/studs/app/defects.json').status_code == 302
    assert anon_client.get('/api/stud-map/status').status_code == 401


def test_page_and_code(client):
    r = client.get('/analytics/studs')
    assert r.status_code == 200 and 'Шпильки' in r.get_data(as_text=True)
    r = client.get('/analytics/studs/app/')
    html = r.get_data(as_text=True)
    assert r.status_code == 200 and 'Карта дефектов шпилек' in html
    js = next(n for n in os.listdir(os.path.join(client.application.static_folder, 'stud-map')) if n.startswith('app.'))
    assert client.get('/analytics/studs/app/' + js).status_code == 200
    # вкладка видна и со страницы «Аналитика»
    assert '/analytics/studs' in client.get('/analytics').get_data(as_text=True)


def test_data_comes_from_server_folder_not_git(app, client):
    assert client.get('/analytics/studs/app/defects.json').status_code == 404
    st = client.get('/api/stud-map/status').get_json()
    assert st['has_data'] is False and st['has_schemes'] is False and st['can_upload'] is True
    d = _data_dir(app)
    os.makedirs(os.path.join(d, 'body'), exist_ok=True)
    with open(os.path.join(d, 'body', 'x.webp'), 'wb') as f:
        f.write(b'RIFF0000WEBP')
    for name in ('body.json', 'views.json'):
        with open(os.path.join(d, name), 'w', encoding='utf-8') as f:
            f.write('{}')
    assert client.get('/analytics/studs/app/body/x.webp').data == b'RIFF0000WEBP'
    assert client.get('/analytics/studs/app/views.json').status_code == 200
    assert client.get('/api/stud-map/status').get_json()['has_schemes'] is True


@pytest.mark.parametrize('path', ['body/..%2F..%2Fwelding_shop.db', '..%2F..%2Fconfig.py', 'body/', 'img/../../test.db'])
def test_no_path_traversal(client, path):
    assert client.get('/analytics/studs/app/' + path).status_code == 404


def test_upload_register(app, client):
    r = client.post('/api/stud-map/register', data={'file': (_register_xlsx(), 'Stud_Defect_Register_BS_rev12.xlsx')},
                    content_type='multipart/form-data')
    j = r.get_json()
    assert r.status_code == 200 and j['status'] == 'ok' and j['rows'] == 2
    data = json.loads(client.get('/analytics/studs/app/defects.json').get_data(as_text=True))
    a13t = next(x for x in data['rows'] if x['model'] == 'A13T')
    assert a13t['body_no'] == '6723' and a13t['week'] == 'W46' and a13t['stud_no'] == 300 and a13t['category'] == 'Склейка (SW)'
    assert data['source'].startswith('Stud_Defect_Register_BS_rev12.xlsx')
    st = client.get('/api/stud-map/status').get_json()
    assert st['has_data'] is True and st['rows'] == 2 and st['updated']
    assert os.path.isfile(os.path.join(_data_dir(app), 'register.xlsx'))
    assert not [n for n in os.listdir(_data_dir(app)) if n.endswith('.tmp')]


def test_upload_rejects_bad_files(client):
    r = client.post('/api/stud-map/register', data={'file': (io.BytesIO(b'hello'), 'a.txt')}, content_type='multipart/form-data')
    assert r.status_code == 400
    r = client.post('/api/stud-map/register', data={'file': (io.BytesIO(b'not excel'), 'a.xlsx')}, content_type='multipart/form-data')
    assert r.status_code == 400 and 'Excel' in r.get_json()['message']
    r = client.post('/api/stud-map/register', data={'file': (_register_xlsx(sheet='Лист1'), 'a.xlsx')}, content_type='multipart/form-data')
    assert r.status_code == 400 and 'Реестр дефектов' in r.get_json()['message']


def test_only_weldteam_uploads(register_client):
    c = register_client(department='ОТК')
    assert c.get('/analytics/studs').status_code == 200            # смотреть может любой отдел
    assert c.get('/api/stud-map/status').get_json()['can_upload'] is False
    r = c.post('/api/stud-map/register', data={'file': (_register_xlsx(), 'r.xlsx')}, content_type='multipart/form-data')
    assert r.status_code == 403


def test_build_marks_mass_events(tmp_path):
    rows = [(i, '777', 'A01', dt.datetime(2026, 11, 3), 'Погнута / Bent', 'Кузовной цех', 'FRONT FLOOR', 1, 6000 + i)
            for i in range(1, 11)]
    p = tmp_path / 'r.xlsx'
    p.write_bytes(_register_xlsx(rows).getvalue())
    data, notes = smd.build(p)
    assert len(data['rows']) == 10 and all(x['mass'] for x in data['rows'])
    assert any('10 строк' in n for n in notes)

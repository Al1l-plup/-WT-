"""Ролевой доступ по отделам (RBAC).

Матрица (кроме админа-суперпользователя, который может всё + панель «Пользователи»):

| Отдел         | Разделы (видит) | Может менять                  |
|---------------|-----------------|-------------------------------|
| WeldTeam      | все             | да, везде                     |
| ИТО           | все             | Редактор + Обзор (остальное просмотр) |
| ОТК           | все             | Дефекты (фиксация; остальное просмотр) |
| Производство  | все             | нет (только просмотр)         |
| ОТО           | все             | нет (только просмотр)         |

Проверка идёт по «разделам» (features). Каждый эндпоинт относится к разделу
(по имени blueprint + несколько явных исключений). Право на раздел — 'r'
(только чтение) или 'w' (чтение+запись). Метод записи (POST/PUT/DELETE) при
праве 'r' запрещён. Неотнесённые эндпоинты (auth.me, logout, смена своего
пароля) доступны любому вошедшему.
"""

WRITE_METHODS = {'POST', 'PUT', 'DELETE', 'PATCH'}

# Разделы сайта.
AREAS = ('home', 'maintenance', 'defects', 'studs', 'analytics', 'workers',
         'explorer', 'editor', 'catalog', 'reconciliation')

# Страницы (path → раздел) — для гейта страниц и построения навигации.
# 'useradmin' — только админ.
PAGES = [
    ('/', 'home', 'Главная'),
    ('/maintenance', 'maintenance', 'ТО'),
    ('/defects', 'defects', 'Дефекты'),
    ('/studs', 'studs', 'Шпильки'),
    ('/analytics', 'analytics', 'Аналитика'),
    ('/workers', 'workers', 'Сотрудники'),
    ('/explorer', 'explorer', 'Обзор'),
    ('/admin', 'editor', 'Редактор'),
    ('/history', 'editor', 'Журнал'),
    ('/reconciliation', 'reconciliation', 'Сверка'),
    ('/users', 'useradmin', 'Пользователи'),
]

# Явные исключения endpoint → раздел (переопределяют маппинг по blueprint).
_ENDPOINT_AREA = {
    'pages.index': 'home',
    'pages.maintenance': 'maintenance',
    'pages.defects_page': 'defects',
    'pages.analytics_page': 'analytics',
    'pages.workers_page': 'workers',
    'pages.explorer_page': 'explorer',
    'admin.admin_page': 'editor',
    'admin.history_page': 'editor',
    'analytics.stats': 'home',   # /api/stats — плитки на Главной, нужны всем вошедшим
}

# blueprint → раздел (для остальных эндпоинтов).
_BP_AREA = {
    'maintenance': 'maintenance',
    'defects': 'defects',
    'studs': 'studs',          # «Шпильки»: оператор сборки записывает, ИТО/УЗК разбирают
    'analytics': 'analytics',
    'stud_map': 'analytics',   # Аналитика → «Шпильки» (3D-карта); загрузка реестра — WeldTeam
    'workers': 'workers',
    'explorer': 'explorer',
    'admin': 'editor',
    'catalog': 'catalog',
    'admin_users': 'useradmin',
    'reconciliation': 'reconciliation',   # «Сверка» с WB: видят все, разбирает ИТО
}

# Права отдела на разделы: 'w' — чтение+запись, 'r' — только чтение,
# отсутствие ключа — раздел недоступен вовсе.
_ALL_R = {a: 'r' for a in AREAS}
_ALL_W = {a: 'w' for a in AREAS}
# Дефекты 4M: Производство/WeldTeam/ИТО/ОТО участвуют в цепочке согласования,
# поэтому все получают запись в раздел «Дефекты». КТО именно может действовать над
# конкретным дефектом (владение этапом, регистрация=ОТК, переоткрытие=WeldTeam) решает
# сам эндпоинт по текущему этапу — см. app/blueprints/defects.py.
# «Шпильки»: записывают все отделы с правом записи (оператор сборки — Производство),
# разбирают по фото ИТО и УЗК — это проверяет сам эндпоинт (app/studs.py: can_review).
DEPARTMENT_PERMS = {
    'WeldTeam': _ALL_W,                                                  # всё (+ админ/переоткрытие)
    'ИТО': {**_ALL_R, 'editor': 'w', 'explorer': 'w', 'defects': 'w',
            'reconciliation': 'w', 'studs': 'w'},                       # Редактор+Обзор+Дефекты+Сверка+Шпильки
    'ОТК': {**_ALL_R, 'defects': 'w', 'studs': 'w'},                     # регистрация + участие + разбор шпилек
    'Производство': {**_ALL_R, 'defects': 'w', 'studs': 'w'},            # участие в цепочке + запись шпилек
    'ОТО': {**_ALL_R, 'defects': 'w'},                                   # исполнитель по оборудованию
}


def area_for_endpoint(endpoint: str | None) -> str | None:
    """Раздел эндпоинта или None — если эндпоинт не под контролем прав (доступен всем вошедшим)."""
    if not endpoint:
        return None
    if endpoint in _ENDPOINT_AREA:
        return _ENDPOINT_AREA[endpoint]
    return _BP_AREA.get(endpoint.split('.', 1)[0])


def can_access(dept: str | None, is_admin: bool, endpoint: str | None, method: str) -> bool:
    """Разрешён ли данному пользователю (отдел + флаг админа) вызов эндпоинта."""
    if is_admin:
        return True
    area = area_for_endpoint(endpoint)
    if area is None:
        return True                      # неотнесённое — любому вошедшему
    if area == 'useradmin':
        return False                     # панель пользователей — только админ
    perm = DEPARTMENT_PERMS.get(dept, {}).get(area)
    if perm is None:
        return False                     # раздел недоступен отделу
    if method.upper() in WRITE_METHODS and perm != 'w':
        return False                     # запись при праве «только чтение»
    return True


def visible_pages(dept: str | None, is_admin: bool) -> list[str]:
    """Список путей страниц, которые пользователь может открыть (для навигации)."""
    out = []
    for path, area, _label in PAGES:
        if area == 'useradmin':
            if is_admin:
                out.append(path)
        elif is_admin or DEPARTMENT_PERMS.get(dept, {}).get(area) is not None:
            out.append(path)
    return out


def is_readonly(dept: str | None, is_admin: bool) -> bool:
    """True, если отдел не может ничего менять (Производство/ОТО)."""
    if is_admin:
        return False
    perms = DEPARTMENT_PERMS.get(dept, {})
    return bool(perms) and 'w' not in perms.values()


def can_edit_docs(dept: str | None, is_admin: bool) -> bool:
    """Может ли пользователь править «документы» Редактора (в т.ч. встроенные
    редакторы записей ТО/Дефектов) — т.е. есть ли право записи в раздел editor."""
    return bool(is_admin) or DEPARTMENT_PERMS.get(dept, {}).get('editor') == 'w'

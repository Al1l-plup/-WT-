(()=>{var Ka="147",Oi={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},zi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},zh=0,El=1,Fh=2;var yo=1,kh=2,Bs=3,fs=0,An=1,fn=2,gi=0,cs=1,Cl=2,Pl=3,Ll=4,Bh=5,as=100,Uh=101,Vh=102,Rl=103,Il=104,Gh=200,Hh=201,Wh=202,Xh=203,Jc=204,$c=205,qh=206,Yh=207,Zh=208,Jh=209,$h=210,Kh=0,jh=1,Qh=2,pa=3,eu=4,tu=5,nu=6,iu=7,Kc=0,su=1,ru=2,Qn=0,ou=1,au=2,lu=3,cu=4,hu=5,jc=300,ps=301,ms=302,ma=303,ga=304,vo=306,xa=1e3,On=1001,_a=1002,dn=1003,Dl=1004;var Nl=1005;var Tn=1006,uu=1007;var bo=1008;var Li=1009,du=1010,fu=1011,Qc=1012,pu=1013,Ai=1014,Ei=1015,Ws=1016,mu=1017,gu=1018,hs=1020,xu=1021,_u=1022,zn=1023,yu=1024,vu=1025,Ci=1026,gs=1027,bu=1028,Mu=1029,wu=1030,Su=1031,Tu=1033,No=33776,Oo=33777,zo=33778,Fo=33779,Ol=35840,zl=35841,Fl=35842,kl=35843,Au=36196,Bl=37492,Ul=37496,Vl=37808,Gl=37809,Hl=37810,Wl=37811,Xl=37812,ql=37813,Yl=37814,Zl=37815,Jl=37816,$l=37817,Kl=37818,jl=37819,Ql=37820,ec=37821,tc=36492;var Yr=2300,Zr=2301,ko=2302,nc=2400,ic=2401,sc=2402;var Ri=3e3,_t=3001,Eu=3200,Cu=3201,eh=0,Pu=1;var Un="srgb",Xs="srgb-linear";var Bo=7680;var Lu=519,ya=35044;var rc="300 es",va=1035,Gn=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let s=i.indexOf(t);s!==-1&&i.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let n=this._listeners[e.type];if(n!==void 0){e.target=this;let i=n.slice(0);for(let s=0,a=i.length;s<a;s++)i[s].call(this,e);e.target=null}}},Kt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],oc=1234567,Vs=Math.PI/180,Jr=180/Math.PI;function ei(){let r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Kt[r&255]+Kt[r>>8&255]+Kt[r>>16&255]+Kt[r>>24&255]+"-"+Kt[e&255]+Kt[e>>8&255]+"-"+Kt[e>>16&15|64]+Kt[e>>24&255]+"-"+Kt[t&63|128]+Kt[t>>8&255]+"-"+Kt[t>>16&255]+Kt[t>>24&255]+Kt[n&255]+Kt[n>>8&255]+Kt[n>>16&255]+Kt[n>>24&255]).toLowerCase()}function sn(r,e,t){return Math.max(e,Math.min(t,r))}function ja(r,e){return(r%e+e)%e}function Ru(r,e,t,n,i){return n+(r-e)*(i-n)/(t-e)}function Iu(r,e,t){return r!==e?(t-r)/(e-r):0}function Gs(r,e,t){return(1-t)*r+t*e}function Du(r,e,t,n){return Gs(r,e,1-Math.exp(-t*n))}function Nu(r,e=1){return e-Math.abs(ja(r,e*2)-e)}function Ou(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*(3-2*r))}function zu(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*r*(r*(r*6-15)+10))}function Fu(r,e){return r+Math.floor(Math.random()*(e-r+1))}function ku(r,e){return r+Math.random()*(e-r)}function Bu(r){return r*(.5-Math.random())}function Uu(r){r!==void 0&&(oc=r);let e=oc+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Vu(r){return r*Vs}function Gu(r){return r*Jr}function ba(r){return(r&r-1)===0&&r!==0}function Hu(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function $r(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Wu(r,e,t,n,i){let s=Math.cos,a=Math.sin,o=s(t/2),c=a(t/2),h=s((e+n)/2),u=a((e+n)/2),l=s((e-n)/2),d=a((e-n)/2),m=s((n-e)/2),_=a((n-e)/2);switch(i){case"XYX":r.set(o*u,c*l,c*d,o*h);break;case"YZY":r.set(c*d,o*u,c*l,o*h);break;case"ZXZ":r.set(c*l,c*d,o*u,o*h);break;case"XZX":r.set(o*u,c*_,c*m,o*h);break;case"YXY":r.set(c*m,o*u,c*_,o*h);break;case"ZYZ":r.set(c*_,c*m,o*u,o*h);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function jn(r,e){switch(e.constructor){case Float32Array:return r;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function wt(r,e){switch(e.constructor){case Float32Array:return r;case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}var Qa=Object.freeze({__proto__:null,DEG2RAD:Vs,RAD2DEG:Jr,generateUUID:ei,clamp:sn,euclideanModulo:ja,mapLinear:Ru,inverseLerp:Iu,lerp:Gs,damp:Du,pingpong:Nu,smoothstep:Ou,smootherstep:zu,randInt:Fu,randFloat:ku,randFloatSpread:Bu,seededRandom:Uu,degToRad:Vu,radToDeg:Gu,isPowerOfTwo:ba,ceilPowerOfTwo:Hu,floorPowerOfTwo:$r,setQuaternionFromProperEuler:Wu,normalize:wt,denormalize:jn}),Ve=class r{constructor(e=0,t=0){r.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6],this.y=i[1]*t+i[4]*n+i[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=this.x<0?Math.ceil(this.x):Math.floor(this.x),this.y=this.y<0?Math.ceil(this.y):Math.floor(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),i=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*n-a*i+e.x,this.y=s*i+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},_n=class r{constructor(){r.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1]}set(e,t,n,i,s,a,o,c,h){let u=this.elements;return u[0]=e,u[1]=i,u[2]=o,u[3]=t,u[4]=s,u[5]=c,u[6]=n,u[7]=a,u[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,a=n[0],o=n[3],c=n[6],h=n[1],u=n[4],l=n[7],d=n[2],m=n[5],_=n[8],p=i[0],f=i[3],b=i[6],C=i[1],S=i[4],y=i[7],M=i[2],N=i[5],k=i[8];return s[0]=a*p+o*C+c*M,s[3]=a*f+o*S+c*N,s[6]=a*b+o*y+c*k,s[1]=h*p+u*C+l*M,s[4]=h*f+u*S+l*N,s[7]=h*b+u*y+l*k,s[2]=d*p+m*C+_*M,s[5]=d*f+m*S+_*N,s[8]=d*b+m*y+_*k,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],a=e[4],o=e[5],c=e[6],h=e[7],u=e[8];return t*a*u-t*o*h-n*s*u+n*o*c+i*s*h-i*a*c}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],a=e[4],o=e[5],c=e[6],h=e[7],u=e[8],l=u*a-o*h,d=o*c-u*s,m=h*s-a*c,_=t*l+n*d+i*m;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);let p=1/_;return e[0]=l*p,e[1]=(i*h-u*n)*p,e[2]=(o*n-i*a)*p,e[3]=d*p,e[4]=(u*t-i*c)*p,e[5]=(i*s-o*t)*p,e[6]=m*p,e[7]=(n*c-h*t)*p,e[8]=(a*t-n*s)*p,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,i,s,a,o){let c=Math.cos(s),h=Math.sin(s);return this.set(n*c,n*h,-n*(c*a+h*o)+a+e,-i*h,i*c,-i*(-h*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Uo.makeScale(e,t)),this}rotate(e){return this.premultiply(Uo.makeRotation(-e)),this}translate(e,t){return this.premultiply(Uo.makeTranslation(e,t)),this}makeTranslation(e,t){return this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<9;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},Uo=new _n;function th(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function qs(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function Pi(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function qr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}var Vo={[Un]:{[Xs]:Pi},[Xs]:{[Un]:qr}},en={legacyMode:!0,get workingColorSpace(){return Xs},set workingColorSpace(r){console.warn("THREE.ColorManagement: .workingColorSpace is readonly.")},convert:function(r,e,t){if(this.legacyMode||e===t||!e||!t)return r;if(Vo[e]&&Vo[e][t]!==void 0){let n=Vo[e][t];return r.r=n(r.r),r.g=n(r.g),r.b=n(r.b),r}throw new Error("Unsupported color space conversion.")},fromWorkingColorSpace:function(r,e){return this.convert(r,this.workingColorSpace,e)},toWorkingColorSpace:function(r,e){return this.convert(r,e,this.workingColorSpace)}},nh={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Bt={r:0,g:0,b:0},In={h:0,s:0,l:0},vr={h:0,s:0,l:0};function Go(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+(e-r)*6*t:t<1/2?e:t<2/3?r+(e-r)*6*(2/3-t):r}function br(r,e){return e.r=r.r,e.g=r.g,e.b=r.b,e}var pt=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,t===void 0&&n===void 0?this.set(e):this.setRGB(e,t,n)}set(e){return e&&e.isColor?this.copy(e):typeof e=="number"?this.setHex(e):typeof e=="string"&&this.setStyle(e),this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Un){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,en.toWorkingColorSpace(this,t),this}setRGB(e,t,n,i=en.workingColorSpace){return this.r=e,this.g=t,this.b=n,en.toWorkingColorSpace(this,i),this}setHSL(e,t,n,i=en.workingColorSpace){if(e=ja(e,1),t=sn(t,0,1),n=sn(n,0,1),t===0)this.r=this.g=this.b=n;else{let s=n<=.5?n*(1+t):n+t-n*t,a=2*n-s;this.r=Go(a,s,e+1/3),this.g=Go(a,s,e),this.b=Go(a,s,e-1/3)}return en.toWorkingColorSpace(this,i),this}setStyle(e,t=Un){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^((?:rgb|hsl)a?)\(([^\)]*)\)/.exec(e)){let s,a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return this.r=Math.min(255,parseInt(s[1],10))/255,this.g=Math.min(255,parseInt(s[2],10))/255,this.b=Math.min(255,parseInt(s[3],10))/255,en.toWorkingColorSpace(this,t),n(s[4]),this;if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return this.r=Math.min(100,parseInt(s[1],10))/100,this.g=Math.min(100,parseInt(s[2],10))/100,this.b=Math.min(100,parseInt(s[3],10))/100,en.toWorkingColorSpace(this,t),n(s[4]),this;break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o)){let c=parseFloat(s[1])/360,h=parseFloat(s[2])/100,u=parseFloat(s[3])/100;return n(s[4]),this.setHSL(c,h,u,t)}break}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=i[1],a=s.length;if(a===3)return this.r=parseInt(s.charAt(0)+s.charAt(0),16)/255,this.g=parseInt(s.charAt(1)+s.charAt(1),16)/255,this.b=parseInt(s.charAt(2)+s.charAt(2),16)/255,en.toWorkingColorSpace(this,t),this;if(a===6)return this.r=parseInt(s.charAt(0)+s.charAt(1),16)/255,this.g=parseInt(s.charAt(2)+s.charAt(3),16)/255,this.b=parseInt(s.charAt(4)+s.charAt(5),16)/255,en.toWorkingColorSpace(this,t),this}return e&&e.length>0?this.setColorName(e,t):this}setColorName(e,t=Un){let n=nh[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Pi(e.r),this.g=Pi(e.g),this.b=Pi(e.b),this}copyLinearToSRGB(e){return this.r=qr(e.r),this.g=qr(e.g),this.b=qr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Un){return en.fromWorkingColorSpace(br(this,Bt),e),sn(Bt.r*255,0,255)<<16^sn(Bt.g*255,0,255)<<8^sn(Bt.b*255,0,255)<<0}getHexString(e=Un){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=en.workingColorSpace){en.fromWorkingColorSpace(br(this,Bt),t);let n=Bt.r,i=Bt.g,s=Bt.b,a=Math.max(n,i,s),o=Math.min(n,i,s),c,h,u=(o+a)/2;if(o===a)c=0,h=0;else{let l=a-o;switch(h=u<=.5?l/(a+o):l/(2-a-o),a){case n:c=(i-s)/l+(i<s?6:0);break;case i:c=(s-n)/l+2;break;case s:c=(n-i)/l+4;break}c/=6}return e.h=c,e.s=h,e.l=u,e}getRGB(e,t=en.workingColorSpace){return en.fromWorkingColorSpace(br(this,Bt),t),e.r=Bt.r,e.g=Bt.g,e.b=Bt.b,e}getStyle(e=Un){return en.fromWorkingColorSpace(br(this,Bt),e),e!==Un?`color(${e} ${Bt.r} ${Bt.g} ${Bt.b})`:`rgb(${Bt.r*255|0},${Bt.g*255|0},${Bt.b*255|0})`}offsetHSL(e,t,n){return this.getHSL(In),In.h+=e,In.s+=t,In.l+=n,this.setHSL(In.h,In.s,In.l),this}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(In),e.getHSL(vr);let n=Gs(In.h,vr.h,t),i=Gs(In.s,vr.s,t),s=Gs(In.l,vr.l,t);return this.setHSL(n,i,s),this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}};pt.NAMES=nh;var Hi,Kr=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement=="undefined")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Hi===void 0&&(Hi=qs("canvas")),Hi.width=e.width,Hi.height=e.height;let n=Hi.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=Hi}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement!="undefined"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&e instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&e instanceof ImageBitmap){let t=qs("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let i=n.getImageData(0,0,e.width,e.height),s=i.data;for(let a=0;a<s.length;a++)s[a]=Pi(s[a]/255)*255;return n.putImageData(i,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Pi(t[n]/255)*255):t[n]=Pi(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},jr=class{constructor(e=null){this.isSource=!0,this.uuid=ei(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?s.push(Ho(i[a].image)):s.push(Ho(i[a]))}else s=Ho(i);n.url=s}return t||(e.images[this.uuid]=n),n}};function Ho(r){return typeof HTMLImageElement!="undefined"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&r instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&r instanceof ImageBitmap?Kr.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var Xu=0,an=class r extends Gn{constructor(e=r.DEFAULT_IMAGE,t=r.DEFAULT_MAPPING,n=On,i=On,s=Tn,a=bo,o=zn,c=Li,h=r.DEFAULT_ANISOTROPY,u=Ri){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Xu++}),this.uuid=ei(),this.name="",this.source=new jr(e),this.mipmaps=[],this.mapping=t,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=a,this.anisotropy=h,this.format=o,this.internalFormat=null,this.type=c,this.offset=new Ve(0,0),this.repeat=new Ve(1,1),this.center=new Ve(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new _n,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.encoding=u,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.encoding=e.encoding,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.5,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,type:this.type,encoding:this.encoding,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return JSON.stringify(this.userData)!=="{}"&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==jc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case xa:e.x=e.x-Math.floor(e.x);break;case On:e.x=e.x<0?0:1;break;case _a:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case xa:e.y=e.y-Math.floor(e.y);break;case On:e.y=e.y<0?0:1;break;case _a:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}};an.DEFAULT_IMAGE=null;an.DEFAULT_MAPPING=jc;an.DEFAULT_ANISOTROPY=1;var Xt=class r{constructor(e=0,t=0,n=0,i=1){r.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,i){return this.x=e,this.y=t,this.z=n,this.w=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*i+a[12]*s,this.y=a[1]*t+a[5]*n+a[9]*i+a[13]*s,this.z=a[2]*t+a[6]*n+a[10]*i+a[14]*s,this.w=a[3]*t+a[7]*n+a[11]*i+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,i,s,c=e.elements,h=c[0],u=c[4],l=c[8],d=c[1],m=c[5],_=c[9],p=c[2],f=c[6],b=c[10];if(Math.abs(u-d)<.01&&Math.abs(l-p)<.01&&Math.abs(_-f)<.01){if(Math.abs(u+d)<.1&&Math.abs(l+p)<.1&&Math.abs(_+f)<.1&&Math.abs(h+m+b-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let S=(h+1)/2,y=(m+1)/2,M=(b+1)/2,N=(u+d)/4,k=(l+p)/4,x=(_+f)/4;return S>y&&S>M?S<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(S),i=N/n,s=k/n):y>M?y<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(y),n=N/i,s=x/i):M<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(M),n=k/s,i=x/s),this.set(n,i,s,t),this}let C=Math.sqrt((f-_)*(f-_)+(l-p)*(l-p)+(d-u)*(d-u));return Math.abs(C)<.001&&(C=1),this.x=(f-_)/C,this.y=(l-p)/C,this.z=(d-u)/C,this.w=Math.acos((h+m+b-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=this.x<0?Math.ceil(this.x):Math.floor(this.x),this.y=this.y<0?Math.ceil(this.y):Math.floor(this.y),this.z=this.z<0?Math.ceil(this.z):Math.floor(this.z),this.w=this.w<0?Math.ceil(this.w):Math.floor(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},ti=class extends Gn{constructor(e=1,t=1,n={}){super(),this.isWebGLRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new Xt(0,0,e,t),this.scissorTest=!1,this.viewport=new Xt(0,0,e,t);let i={width:e,height:t,depth:1};this.texture=new an(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.encoding),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=n.generateMipmaps!==void 0?n.generateMipmaps:!1,this.texture.internalFormat=n.internalFormat!==void 0?n.internalFormat:null,this.texture.minFilter=n.minFilter!==void 0?n.minFilter:Tn,this.depthBuffer=n.depthBuffer!==void 0?n.depthBuffer:!0,this.stencilBuffer=n.stencilBuffer!==void 0?n.stencilBuffer:!1,this.depthTexture=n.depthTexture!==void 0?n.depthTexture:null,this.samples=n.samples!==void 0?n.samples:0}setSize(e,t,n=1){(this.width!==e||this.height!==t||this.depth!==n)&&(this.width=e,this.height=t,this.depth=n,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=n,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new jr(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Qr=class extends an{constructor(e=null,t=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=dn,this.minFilter=dn,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Ma=class extends an{constructor(e=null,t=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=dn,this.minFilter=dn,this.wrapR=On,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var yn=class{constructor(e=0,t=0,n=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=i}static slerpFlat(e,t,n,i,s,a,o){let c=n[i+0],h=n[i+1],u=n[i+2],l=n[i+3],d=s[a+0],m=s[a+1],_=s[a+2],p=s[a+3];if(o===0){e[t+0]=c,e[t+1]=h,e[t+2]=u,e[t+3]=l;return}if(o===1){e[t+0]=d,e[t+1]=m,e[t+2]=_,e[t+3]=p;return}if(l!==p||c!==d||h!==m||u!==_){let f=1-o,b=c*d+h*m+u*_+l*p,C=b>=0?1:-1,S=1-b*b;if(S>Number.EPSILON){let M=Math.sqrt(S),N=Math.atan2(M,b*C);f=Math.sin(f*N)/M,o=Math.sin(o*N)/M}let y=o*C;if(c=c*f+d*y,h=h*f+m*y,u=u*f+_*y,l=l*f+p*y,f===1-o){let M=1/Math.sqrt(c*c+h*h+u*u+l*l);c*=M,h*=M,u*=M,l*=M}}e[t]=c,e[t+1]=h,e[t+2]=u,e[t+3]=l}static multiplyQuaternionsFlat(e,t,n,i,s,a){let o=n[i],c=n[i+1],h=n[i+2],u=n[i+3],l=s[a],d=s[a+1],m=s[a+2],_=s[a+3];return e[t]=o*_+u*l+c*m-h*d,e[t+1]=c*_+u*d+h*l-o*m,e[t+2]=h*_+u*m+o*d-c*l,e[t+3]=u*_-o*l-c*d-h*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,i){return this._x=e,this._y=t,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t){let n=e._x,i=e._y,s=e._z,a=e._order,o=Math.cos,c=Math.sin,h=o(n/2),u=o(i/2),l=o(s/2),d=c(n/2),m=c(i/2),_=c(s/2);switch(a){case"XYZ":this._x=d*u*l+h*m*_,this._y=h*m*l-d*u*_,this._z=h*u*_+d*m*l,this._w=h*u*l-d*m*_;break;case"YXZ":this._x=d*u*l+h*m*_,this._y=h*m*l-d*u*_,this._z=h*u*_-d*m*l,this._w=h*u*l+d*m*_;break;case"ZXY":this._x=d*u*l-h*m*_,this._y=h*m*l+d*u*_,this._z=h*u*_+d*m*l,this._w=h*u*l-d*m*_;break;case"ZYX":this._x=d*u*l-h*m*_,this._y=h*m*l+d*u*_,this._z=h*u*_-d*m*l,this._w=h*u*l+d*m*_;break;case"YZX":this._x=d*u*l+h*m*_,this._y=h*m*l+d*u*_,this._z=h*u*_-d*m*l,this._w=h*u*l-d*m*_;break;case"XZY":this._x=d*u*l-h*m*_,this._y=h*m*l-d*u*_,this._z=h*u*_+d*m*l,this._w=h*u*l+d*m*_;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t!==!1&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,i=Math.sin(n);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],i=t[4],s=t[8],a=t[1],o=t[5],c=t[9],h=t[2],u=t[6],l=t[10],d=n+o+l;if(d>0){let m=.5/Math.sqrt(d+1);this._w=.25/m,this._x=(u-c)*m,this._y=(s-h)*m,this._z=(a-i)*m}else if(n>o&&n>l){let m=2*Math.sqrt(1+n-o-l);this._w=(u-c)/m,this._x=.25*m,this._y=(i+a)/m,this._z=(s+h)/m}else if(o>l){let m=2*Math.sqrt(1+o-n-l);this._w=(s-h)/m,this._x=(i+a)/m,this._y=.25*m,this._z=(c+u)/m}else{let m=2*Math.sqrt(1+l-n-o);this._w=(a-i)/m,this._x=(s+h)/m,this._y=(c+u)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(sn(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let i=Math.min(1,t/n);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,i=e._y,s=e._z,a=e._w,o=t._x,c=t._y,h=t._z,u=t._w;return this._x=n*u+a*o+i*h-s*c,this._y=i*u+a*c+s*o-n*h,this._z=s*u+a*h+n*c-i*o,this._w=a*u-n*o-i*c-s*h,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let n=this._x,i=this._y,s=this._z,a=this._w,o=a*e._w+n*e._x+i*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=n,this._y=i,this._z=s,this;let c=1-o*o;if(c<=Number.EPSILON){let m=1-t;return this._w=m*a+t*this._w,this._x=m*n+t*this._x,this._y=m*i+t*this._y,this._z=m*s+t*this._z,this.normalize(),this._onChangeCallback(),this}let h=Math.sqrt(c),u=Math.atan2(h,o),l=Math.sin((1-t)*u)/h,d=Math.sin(t*u)/h;return this._w=a*l+this._w*d,this._x=n*l+this._x*d,this._y=i*l+this._y*d,this._z=s*l+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=Math.random(),t=Math.sqrt(1-e),n=Math.sqrt(e),i=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(i),n*Math.sin(s),n*Math.cos(s),t*Math.sin(i))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},R=class r{constructor(e=0,t=0,n=0){r.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(ac.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(ac.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*i,this.y=s[1]*t+s[4]*n+s[7]*i,this.z=s[2]*t+s[5]*n+s[8]*i,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,i=this.z,s=e.elements,a=1/(s[3]*t+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*i+s[12])*a,this.y=(s[1]*t+s[5]*n+s[9]*i+s[13])*a,this.z=(s[2]*t+s[6]*n+s[10]*i+s[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,i=this.z,s=e.x,a=e.y,o=e.z,c=e.w,h=c*t+a*i-o*n,u=c*n+o*t-s*i,l=c*i+s*n-a*t,d=-s*t-a*n-o*i;return this.x=h*c+d*-s+u*-o-l*-a,this.y=u*c+d*-a+l*-s-h*-o,this.z=l*c+d*-o+h*-a-u*-s,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*i,this.y=s[1]*t+s[5]*n+s[9]*i,this.z=s[2]*t+s[6]*n+s[10]*i,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=this.x<0?Math.ceil(this.x):Math.floor(this.x),this.y=this.y<0?Math.ceil(this.y):Math.floor(this.y),this.z=this.z<0?Math.ceil(this.z):Math.floor(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,i=e.y,s=e.z,a=t.x,o=t.y,c=t.z;return this.x=i*c-s*o,this.y=s*a-n*c,this.z=n*o-i*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Wo.copy(this).projectOnVector(e),this.sub(Wo)}reflect(e){return this.sub(Wo.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(sn(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,i=this.z-e.z;return t*t+n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let i=Math.sin(t)*e;return this.x=i*Math.sin(n),this.y=Math.cos(t)*e,this.z=i*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),i=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=i,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,n=Math.sqrt(1-e**2);return this.x=n*Math.cos(t),this.y=n*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Wo=new R,ac=new yn,Ii=class{constructor(e=new R(1/0,1/0,1/0),t=new R(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){let t=1/0,n=1/0,i=1/0,s=-1/0,a=-1/0,o=-1/0;for(let c=0,h=e.length;c<h;c+=3){let u=e[c],l=e[c+1],d=e[c+2];u<t&&(t=u),l<n&&(n=l),d<i&&(i=d),u>s&&(s=u),l>a&&(a=l),d>o&&(o=d)}return this.min.set(t,n,i),this.max.set(s,a,o),this}setFromBufferAttribute(e){let t=1/0,n=1/0,i=1/0,s=-1/0,a=-1/0,o=-1/0;for(let c=0,h=e.count;c<h;c++){let u=e.getX(c),l=e.getY(c),d=e.getZ(c);u<t&&(t=u),l<n&&(n=l),d<i&&(i=d),u>s&&(s=u),l>a&&(a=l),d>o&&(o=d)}return this.min.set(t,n,i),this.max.set(s,a,o),this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=bi.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0)if(t&&n.attributes!=null&&n.attributes.position!==void 0){let s=n.attributes.position;for(let a=0,o=s.count;a<o;a++)bi.fromBufferAttribute(s,a).applyMatrix4(e.matrixWorld),this.expandByPoint(bi)}else n.boundingBox===null&&n.computeBoundingBox(),Xo.copy(n.boundingBox),Xo.applyMatrix4(e.matrixWorld),this.union(Xo);let i=e.children;for(let s=0,a=i.length;s<a;s++)this.expandByObject(i[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,bi),bi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Rs),Mr.subVectors(this.max,Rs),Wi.subVectors(e.a,Rs),Xi.subVectors(e.b,Rs),qi.subVectors(e.c,Rs),li.subVectors(Xi,Wi),ci.subVectors(qi,Xi),Mi.subVectors(Wi,qi);let t=[0,-li.z,li.y,0,-ci.z,ci.y,0,-Mi.z,Mi.y,li.z,0,-li.x,ci.z,0,-ci.x,Mi.z,0,-Mi.x,-li.y,li.x,0,-ci.y,ci.x,0,-Mi.y,Mi.x,0];return!qo(t,Wi,Xi,qi,Mr)||(t=[1,0,0,0,1,0,0,0,1],!qo(t,Wi,Xi,qi,Mr))?!1:(wr.crossVectors(li,ci),t=[wr.x,wr.y,wr.z],qo(t,Wi,Xi,qi,Mr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return bi.copy(e).clamp(this.min,this.max).sub(e).length()}getBoundingSphere(e){return this.getCenter(e.center),e.radius=this.getSize(bi).length()*.5,e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(qn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),qn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),qn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),qn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),qn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),qn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),qn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),qn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(qn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},qn=[new R,new R,new R,new R,new R,new R,new R,new R],bi=new R,Xo=new Ii,Wi=new R,Xi=new R,qi=new R,li=new R,ci=new R,Mi=new R,Rs=new R,Mr=new R,wr=new R,wi=new R;function qo(r,e,t,n,i){for(let s=0,a=r.length-3;s<=a;s+=3){wi.fromArray(r,s);let o=i.x*Math.abs(wi.x)+i.y*Math.abs(wi.y)+i.z*Math.abs(wi.z),c=e.dot(wi),h=t.dot(wi),u=n.dot(wi);if(Math.max(-Math.max(c,h,u),Math.min(c,h,u))>o)return!1}return!0}var qu=new Ii,Is=new R,Yo=new R,xs=class{constructor(e=new R,t=-1){this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):qu.setFromPoints(e).getCenter(n);let i=0;for(let s=0,a=e.length;s<a;s++)i=Math.max(i,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Is.subVectors(e,this.center);let t=Is.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),i=(n-this.radius)*.5;this.center.addScaledVector(Is,i/n),this.radius+=i}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Yo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Is.copy(e.center).add(Yo)),this.expandByPoint(Is.copy(e.center).sub(Yo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},Yn=new R,Zo=new R,Sr=new R,hi=new R,Jo=new R,Tr=new R,$o=new R,eo=class{constructor(e=new R,t=new R(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.direction).multiplyScalar(e).add(this.origin)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Yn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.direction).multiplyScalar(n).add(this.origin)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Yn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Yn.copy(this.direction).multiplyScalar(t).add(this.origin),Yn.distanceToSquared(e))}distanceSqToSegment(e,t,n,i){Zo.copy(e).add(t).multiplyScalar(.5),Sr.copy(t).sub(e).normalize(),hi.copy(this.origin).sub(Zo);let s=e.distanceTo(t)*.5,a=-this.direction.dot(Sr),o=hi.dot(this.direction),c=-hi.dot(Sr),h=hi.lengthSq(),u=Math.abs(1-a*a),l,d,m,_;if(u>0)if(l=a*c-o,d=a*o-c,_=s*u,l>=0)if(d>=-_)if(d<=_){let p=1/u;l*=p,d*=p,m=l*(l+a*d+2*o)+d*(a*l+d+2*c)+h}else d=s,l=Math.max(0,-(a*d+o)),m=-l*l+d*(d+2*c)+h;else d=-s,l=Math.max(0,-(a*d+o)),m=-l*l+d*(d+2*c)+h;else d<=-_?(l=Math.max(0,-(-a*s+o)),d=l>0?-s:Math.min(Math.max(-s,-c),s),m=-l*l+d*(d+2*c)+h):d<=_?(l=0,d=Math.min(Math.max(-s,-c),s),m=d*(d+2*c)+h):(l=Math.max(0,-(a*s+o)),d=l>0?s:Math.min(Math.max(-s,-c),s),m=-l*l+d*(d+2*c)+h);else d=a>0?-s:s,l=Math.max(0,-(a*d+o)),m=-l*l+d*(d+2*c)+h;return n&&n.copy(this.direction).multiplyScalar(l).add(this.origin),i&&i.copy(Sr).multiplyScalar(d).add(Zo),m}intersectSphere(e,t){Yn.subVectors(e.center,this.origin);let n=Yn.dot(this.direction),i=Yn.dot(Yn)-n*n,s=e.radius*e.radius;if(i>s)return null;let a=Math.sqrt(s-i),o=n-a,c=n+a;return o<0&&c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,i,s,a,o,c,h=1/this.direction.x,u=1/this.direction.y,l=1/this.direction.z,d=this.origin;return h>=0?(n=(e.min.x-d.x)*h,i=(e.max.x-d.x)*h):(n=(e.max.x-d.x)*h,i=(e.min.x-d.x)*h),u>=0?(s=(e.min.y-d.y)*u,a=(e.max.y-d.y)*u):(s=(e.max.y-d.y)*u,a=(e.min.y-d.y)*u),n>a||s>i||((s>n||isNaN(n))&&(n=s),(a<i||isNaN(i))&&(i=a),l>=0?(o=(e.min.z-d.z)*l,c=(e.max.z-d.z)*l):(o=(e.max.z-d.z)*l,c=(e.min.z-d.z)*l),n>c||o>i)||((o>n||n!==n)&&(n=o),(c<i||i!==i)&&(i=c),i<0)?null:this.at(n>=0?n:i,t)}intersectsBox(e){return this.intersectBox(e,Yn)!==null}intersectTriangle(e,t,n,i,s){Jo.subVectors(t,e),Tr.subVectors(n,e),$o.crossVectors(Jo,Tr);let a=this.direction.dot($o),o;if(a>0){if(i)return null;o=1}else if(a<0)o=-1,a=-a;else return null;hi.subVectors(this.origin,e);let c=o*this.direction.dot(Tr.crossVectors(hi,Tr));if(c<0)return null;let h=o*this.direction.dot(Jo.cross(hi));if(h<0||c+h>a)return null;let u=-o*hi.dot($o);return u<0?null:this.at(u/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Tt=class r{constructor(){r.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}set(e,t,n,i,s,a,o,c,h,u,l,d,m,_,p,f){let b=this.elements;return b[0]=e,b[4]=t,b[8]=n,b[12]=i,b[1]=s,b[5]=a,b[9]=o,b[13]=c,b[2]=h,b[6]=u,b[10]=l,b[14]=d,b[3]=m,b[7]=_,b[11]=p,b[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new r().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,n=e.elements,i=1/Yi.setFromMatrixColumn(e,0).length(),s=1/Yi.setFromMatrixColumn(e,1).length(),a=1/Yi.setFromMatrixColumn(e,2).length();return t[0]=n[0]*i,t[1]=n[1]*i,t[2]=n[2]*i,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,i=e.y,s=e.z,a=Math.cos(n),o=Math.sin(n),c=Math.cos(i),h=Math.sin(i),u=Math.cos(s),l=Math.sin(s);if(e.order==="XYZ"){let d=a*u,m=a*l,_=o*u,p=o*l;t[0]=c*u,t[4]=-c*l,t[8]=h,t[1]=m+_*h,t[5]=d-p*h,t[9]=-o*c,t[2]=p-d*h,t[6]=_+m*h,t[10]=a*c}else if(e.order==="YXZ"){let d=c*u,m=c*l,_=h*u,p=h*l;t[0]=d+p*o,t[4]=_*o-m,t[8]=a*h,t[1]=a*l,t[5]=a*u,t[9]=-o,t[2]=m*o-_,t[6]=p+d*o,t[10]=a*c}else if(e.order==="ZXY"){let d=c*u,m=c*l,_=h*u,p=h*l;t[0]=d-p*o,t[4]=-a*l,t[8]=_+m*o,t[1]=m+_*o,t[5]=a*u,t[9]=p-d*o,t[2]=-a*h,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){let d=a*u,m=a*l,_=o*u,p=o*l;t[0]=c*u,t[4]=_*h-m,t[8]=d*h+p,t[1]=c*l,t[5]=p*h+d,t[9]=m*h-_,t[2]=-h,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){let d=a*c,m=a*h,_=o*c,p=o*h;t[0]=c*u,t[4]=p-d*l,t[8]=_*l+m,t[1]=l,t[5]=a*u,t[9]=-o*u,t[2]=-h*u,t[6]=m*l+_,t[10]=d-p*l}else if(e.order==="XZY"){let d=a*c,m=a*h,_=o*c,p=o*h;t[0]=c*u,t[4]=-l,t[8]=h*u,t[1]=d*l+p,t[5]=a*u,t[9]=m*l-_,t[2]=_*l-m,t[6]=o*u,t[10]=p*l+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Yu,e,Zu)}lookAt(e,t,n){let i=this.elements;return gn.subVectors(e,t),gn.lengthSq()===0&&(gn.z=1),gn.normalize(),ui.crossVectors(n,gn),ui.lengthSq()===0&&(Math.abs(n.z)===1?gn.x+=1e-4:gn.z+=1e-4,gn.normalize(),ui.crossVectors(n,gn)),ui.normalize(),Ar.crossVectors(gn,ui),i[0]=ui.x,i[4]=Ar.x,i[8]=gn.x,i[1]=ui.y,i[5]=Ar.y,i[9]=gn.y,i[2]=ui.z,i[6]=Ar.z,i[10]=gn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,i=t.elements,s=this.elements,a=n[0],o=n[4],c=n[8],h=n[12],u=n[1],l=n[5],d=n[9],m=n[13],_=n[2],p=n[6],f=n[10],b=n[14],C=n[3],S=n[7],y=n[11],M=n[15],N=i[0],k=i[4],x=i[8],P=i[12],z=i[1],Y=i[5],ie=i[9],q=i[13],B=i[2],K=i[6],re=i[10],ue=i[14],Z=i[3],me=i[7],ae=i[11],ee=i[15];return s[0]=a*N+o*z+c*B+h*Z,s[4]=a*k+o*Y+c*K+h*me,s[8]=a*x+o*ie+c*re+h*ae,s[12]=a*P+o*q+c*ue+h*ee,s[1]=u*N+l*z+d*B+m*Z,s[5]=u*k+l*Y+d*K+m*me,s[9]=u*x+l*ie+d*re+m*ae,s[13]=u*P+l*q+d*ue+m*ee,s[2]=_*N+p*z+f*B+b*Z,s[6]=_*k+p*Y+f*K+b*me,s[10]=_*x+p*ie+f*re+b*ae,s[14]=_*P+p*q+f*ue+b*ee,s[3]=C*N+S*z+y*B+M*Z,s[7]=C*k+S*Y+y*K+M*me,s[11]=C*x+S*ie+y*re+M*ae,s[15]=C*P+S*q+y*ue+M*ee,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],i=e[8],s=e[12],a=e[1],o=e[5],c=e[9],h=e[13],u=e[2],l=e[6],d=e[10],m=e[14],_=e[3],p=e[7],f=e[11],b=e[15];return _*(+s*c*l-i*h*l-s*o*d+n*h*d+i*o*m-n*c*m)+p*(+t*c*m-t*h*d+s*a*d-i*a*m+i*h*u-s*c*u)+f*(+t*h*l-t*o*m-s*a*l+n*a*m+s*o*u-n*h*u)+b*(-i*o*u-t*c*l+t*o*d+i*a*l-n*a*d+n*c*u)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let i=this.elements;return e.isVector3?(i[12]=e.x,i[13]=e.y,i[14]=e.z):(i[12]=e,i[13]=t,i[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],a=e[4],o=e[5],c=e[6],h=e[7],u=e[8],l=e[9],d=e[10],m=e[11],_=e[12],p=e[13],f=e[14],b=e[15],C=l*f*h-p*d*h+p*c*m-o*f*m-l*c*b+o*d*b,S=_*d*h-u*f*h-_*c*m+a*f*m+u*c*b-a*d*b,y=u*p*h-_*l*h+_*o*m-a*p*m-u*o*b+a*l*b,M=_*l*c-u*p*c-_*o*d+a*p*d+u*o*f-a*l*f,N=t*C+n*S+i*y+s*M;if(N===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let k=1/N;return e[0]=C*k,e[1]=(p*d*s-l*f*s-p*i*m+n*f*m+l*i*b-n*d*b)*k,e[2]=(o*f*s-p*c*s+p*i*h-n*f*h-o*i*b+n*c*b)*k,e[3]=(l*c*s-o*d*s-l*i*h+n*d*h+o*i*m-n*c*m)*k,e[4]=S*k,e[5]=(u*f*s-_*d*s+_*i*m-t*f*m-u*i*b+t*d*b)*k,e[6]=(_*c*s-a*f*s-_*i*h+t*f*h+a*i*b-t*c*b)*k,e[7]=(a*d*s-u*c*s+u*i*h-t*d*h-a*i*m+t*c*m)*k,e[8]=y*k,e[9]=(_*l*s-u*p*s-_*n*m+t*p*m+u*n*b-t*l*b)*k,e[10]=(a*p*s-_*o*s+_*n*h-t*p*h-a*n*b+t*o*b)*k,e[11]=(u*o*s-a*l*s-u*n*h+t*l*h+a*n*m-t*o*m)*k,e[12]=M*k,e[13]=(u*p*i-_*l*i+_*n*d-t*p*d-u*n*f+t*l*f)*k,e[14]=(_*o*i-a*p*i-_*n*c+t*p*c+a*n*f-t*o*f)*k,e[15]=(a*l*i-u*o*i+u*n*c-t*l*c-a*n*d+t*o*d)*k,this}scale(e){let t=this.elements,n=e.x,i=e.y,s=e.z;return t[0]*=n,t[4]*=i,t[8]*=s,t[1]*=n,t[5]*=i,t[9]*=s,t[2]*=n,t[6]*=i,t[10]*=s,t[3]*=n,t[7]*=i,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],i=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,i))}makeTranslation(e,t,n){return this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),i=Math.sin(t),s=1-n,a=e.x,o=e.y,c=e.z,h=s*a,u=s*o;return this.set(h*a+n,h*o-i*c,h*c+i*o,0,h*o+i*c,u*o+n,u*c-i*a,0,h*c-i*o,u*c+i*a,s*c*c+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,i,s,a){return this.set(1,n,s,0,e,1,a,0,t,i,1,0,0,0,0,1),this}compose(e,t,n){let i=this.elements,s=t._x,a=t._y,o=t._z,c=t._w,h=s+s,u=a+a,l=o+o,d=s*h,m=s*u,_=s*l,p=a*u,f=a*l,b=o*l,C=c*h,S=c*u,y=c*l,M=n.x,N=n.y,k=n.z;return i[0]=(1-(p+b))*M,i[1]=(m+y)*M,i[2]=(_-S)*M,i[3]=0,i[4]=(m-y)*N,i[5]=(1-(d+b))*N,i[6]=(f+C)*N,i[7]=0,i[8]=(_+S)*k,i[9]=(f-C)*k,i[10]=(1-(d+p))*k,i[11]=0,i[12]=e.x,i[13]=e.y,i[14]=e.z,i[15]=1,this}decompose(e,t,n){let i=this.elements,s=Yi.set(i[0],i[1],i[2]).length(),a=Yi.set(i[4],i[5],i[6]).length(),o=Yi.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),e.x=i[12],e.y=i[13],e.z=i[14],Dn.copy(this);let h=1/s,u=1/a,l=1/o;return Dn.elements[0]*=h,Dn.elements[1]*=h,Dn.elements[2]*=h,Dn.elements[4]*=u,Dn.elements[5]*=u,Dn.elements[6]*=u,Dn.elements[8]*=l,Dn.elements[9]*=l,Dn.elements[10]*=l,t.setFromRotationMatrix(Dn),n.x=s,n.y=a,n.z=o,this}makePerspective(e,t,n,i,s,a){let o=this.elements,c=2*s/(t-e),h=2*s/(n-i),u=(t+e)/(t-e),l=(n+i)/(n-i),d=-(a+s)/(a-s),m=-2*a*s/(a-s);return o[0]=c,o[4]=0,o[8]=u,o[12]=0,o[1]=0,o[5]=h,o[9]=l,o[13]=0,o[2]=0,o[6]=0,o[10]=d,o[14]=m,o[3]=0,o[7]=0,o[11]=-1,o[15]=0,this}makeOrthographic(e,t,n,i,s,a){let o=this.elements,c=1/(t-e),h=1/(n-i),u=1/(a-s),l=(t+e)*c,d=(n+i)*h,m=(a+s)*u;return o[0]=2*c,o[4]=0,o[8]=0,o[12]=-l,o[1]=0,o[5]=2*h,o[9]=0,o[13]=-d,o[2]=0,o[6]=0,o[10]=-2*u,o[14]=-m,o[3]=0,o[7]=0,o[11]=0,o[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let i=0;i<16;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Yi=new R,Dn=new Tt,Yu=new R(0,0,0),Zu=new R(1,1,1),ui=new R,Ar=new R,gn=new R,lc=new Tt,cc=new yn,Ys=class r{constructor(e=0,t=0,n=0,i=r.DefaultOrder){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,i=this._order){return this._x=e,this._y=t,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let i=e.elements,s=i[0],a=i[4],o=i[8],c=i[1],h=i[5],u=i[9],l=i[2],d=i[6],m=i[10];switch(t){case"XYZ":this._y=Math.asin(sn(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-u,m),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(d,h),this._z=0);break;case"YXZ":this._x=Math.asin(-sn(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(c,h)):(this._y=Math.atan2(-l,s),this._z=0);break;case"ZXY":this._x=Math.asin(sn(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-l,m),this._z=Math.atan2(-a,h)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-sn(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(d,m),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,h));break;case"YZX":this._z=Math.asin(sn(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,h),this._y=Math.atan2(-l,s)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-sn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,h),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-u,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return lc.makeRotationFromQuaternion(e),this.setFromRotationMatrix(lc,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return cc.setFromEuler(this),this.setFromQuaternion(cc,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}toVector3(){console.error("THREE.Euler: .toVector3() has been removed. Use Vector3.setFromEuler() instead")}};Ys.DefaultOrder="XYZ";Ys.RotationOrders=["XYZ","YZX","ZXY","XZY","YXZ","ZYX"];var to=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Ju=0,hc=new R,Zi=new yn,Zn=new Tt,Er=new R,Ds=new R,$u=new R,Ku=new yn,uc=new R(1,0,0),dc=new R(0,1,0),fc=new R(0,0,1),ju={type:"added"},pc={type:"removed"},Jt=class r extends Gn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Ju++}),this.uuid=ei(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=r.DefaultUp.clone();let e=new R,t=new Ys,n=new yn,i=new R(1,1,1);function s(){n.setFromEuler(t,!1)}function a(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Tt},normalMatrix:{value:new _n}}),this.matrix=new Tt,this.matrixWorld=new Tt,this.matrixAutoUpdate=r.DefaultMatrixAutoUpdate,this.matrixWorldNeedsUpdate=!1,this.matrixWorldAutoUpdate=r.DefaultMatrixWorldAutoUpdate,this.layers=new to,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Zi.setFromAxisAngle(e,t),this.quaternion.multiply(Zi),this}rotateOnWorldAxis(e,t){return Zi.setFromAxisAngle(e,t),this.quaternion.premultiply(Zi),this}rotateX(e){return this.rotateOnAxis(uc,e)}rotateY(e){return this.rotateOnAxis(dc,e)}rotateZ(e){return this.rotateOnAxis(fc,e)}translateOnAxis(e,t){return hc.copy(e).applyQuaternion(this.quaternion),this.position.add(hc.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(uc,e)}translateY(e){return this.translateOnAxis(dc,e)}translateZ(e){return this.translateOnAxis(fc,e)}localToWorld(e){return e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return e.applyMatrix4(Zn.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Er.copy(e):Er.set(e,t,n);let i=this.parent;this.updateWorldMatrix(!0,!1),Ds.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Zn.lookAt(Ds,Er,this.up):Zn.lookAt(Er,Ds,this.up),this.quaternion.setFromRotationMatrix(Zn),i&&(Zn.extractRotation(i.matrixWorld),Zi.setFromRotationMatrix(Zn),this.quaternion.premultiply(Zi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(ju)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(pc)),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){for(let e=0;e<this.children.length;e++){let t=this.children[e];t.parent=null,t.dispatchEvent(pc)}return this.children.length=0,this}attach(e){return this.updateWorldMatrix(!0,!1),Zn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Zn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Zn),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,i=this.children.length;n<i;n++){let a=this.children[n].getObjectByProperty(e,t);if(a!==void 0)return a}}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ds,e,$u),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ds,Ku,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,i=t.length;n<i;n++){let s=t[n];(s.matrixWorldAutoUpdate===!0||e===!0)&&s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){let n=this.parent;if(e===!0&&n!==null&&n.matrixWorldAutoUpdate===!0&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){let i=this.children;for(let s=0,a=i.length;s<a;s++){let o=i[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.5,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),JSON.stringify(this.userData)!=="{}"&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON()));function s(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let c=o.shapes;if(Array.isArray(c))for(let h=0,u=c.length;h<u;h++){let l=c[h];s(e.shapes,l)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let c=0,h=this.material.length;c<h;c++)o.push(s(e.materials,this.material[c]));i.material=o}else i.material=s(e.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let c=this.animations[o];i.animations.push(s(e.animations,c))}}if(t){let o=a(e.geometries),c=a(e.materials),h=a(e.textures),u=a(e.images),l=a(e.shapes),d=a(e.skeletons),m=a(e.animations),_=a(e.nodes);o.length>0&&(n.geometries=o),c.length>0&&(n.materials=c),h.length>0&&(n.textures=h),u.length>0&&(n.images=u),l.length>0&&(n.shapes=l),d.length>0&&(n.skeletons=d),m.length>0&&(n.animations=m),_.length>0&&(n.nodes=_)}return n.object=i,n;function a(o){let c=[];for(let h in o){let u=o[h];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let i=e.children[n];this.add(i.clone())}return this}};Jt.DefaultUp=new R(0,1,0);Jt.DefaultMatrixAutoUpdate=!0;Jt.DefaultMatrixWorldAutoUpdate=!0;var Nn=new R,Jn=new R,Ko=new R,$n=new R,Ji=new R,$i=new R,mc=new R,jo=new R,Qo=new R,ea=new R,us=class r{constructor(e=new R,t=new R,n=new R){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,i){i.subVectors(n,t),Nn.subVectors(e,t),i.cross(Nn);let s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(e,t,n,i,s){Nn.subVectors(i,t),Jn.subVectors(n,t),Ko.subVectors(e,t);let a=Nn.dot(Nn),o=Nn.dot(Jn),c=Nn.dot(Ko),h=Jn.dot(Jn),u=Jn.dot(Ko),l=a*h-o*o;if(l===0)return s.set(-2,-1,-1);let d=1/l,m=(h*c-o*u)*d,_=(a*u-o*c)*d;return s.set(1-m-_,_,m)}static containsPoint(e,t,n,i){return this.getBarycoord(e,t,n,i,$n),$n.x>=0&&$n.y>=0&&$n.x+$n.y<=1}static getUV(e,t,n,i,s,a,o,c){return this.getBarycoord(e,t,n,i,$n),c.set(0,0),c.addScaledVector(s,$n.x),c.addScaledVector(a,$n.y),c.addScaledVector(o,$n.z),c}static isFrontFacing(e,t,n,i){return Nn.subVectors(n,t),Jn.subVectors(e,t),Nn.cross(Jn).dot(i)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,i){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[i]),this}setFromAttributeAndIndices(e,t,n,i){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Nn.subVectors(this.c,this.b),Jn.subVectors(this.a,this.b),Nn.cross(Jn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return r.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return r.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,n,i,s){return r.getUV(e,this.a,this.b,this.c,t,n,i,s)}containsPoint(e){return r.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return r.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,i=this.b,s=this.c,a,o;Ji.subVectors(i,n),$i.subVectors(s,n),jo.subVectors(e,n);let c=Ji.dot(jo),h=$i.dot(jo);if(c<=0&&h<=0)return t.copy(n);Qo.subVectors(e,i);let u=Ji.dot(Qo),l=$i.dot(Qo);if(u>=0&&l<=u)return t.copy(i);let d=c*l-u*h;if(d<=0&&c>=0&&u<=0)return a=c/(c-u),t.copy(n).addScaledVector(Ji,a);ea.subVectors(e,s);let m=Ji.dot(ea),_=$i.dot(ea);if(_>=0&&m<=_)return t.copy(s);let p=m*h-c*_;if(p<=0&&h>=0&&_<=0)return o=h/(h-_),t.copy(n).addScaledVector($i,o);let f=u*_-m*l;if(f<=0&&l-u>=0&&m-_>=0)return mc.subVectors(s,i),o=(l-u)/(l-u+(m-_)),t.copy(i).addScaledVector(mc,o);let b=1/(f+p+d);return a=p*b,o=d*b,t.copy(n).addScaledVector(Ji,a).addScaledVector($i,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Qu=0,ni=class extends Gn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Qu++}),this.uuid=ei(),this.name="",this.type="Material",this.blending=cs,this.side=fs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.blendSrc=Jc,this.blendDst=$c,this.blendEquation=as,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.depthFunc=pa,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Lu,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Bo,this.stencilZFail=Bo,this.stencilZPass=Bo,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){console.warn("THREE.Material: '"+t+"' parameter is undefined.");continue}let i=this[t];if(i===void 0){console.warn("THREE."+this.type+": '"+t+"' is not a property of this material.");continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.5,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==cs&&(n.blending=this.blending),this.side!==fs&&(n.side=this.side),this.vertexColors&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=this.transparent),n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.stencilWrite=this.stencilWrite,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaToCoverage===!0&&(n.alphaToCoverage=this.alphaToCoverage),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=this.premultipliedAlpha),this.wireframe===!0&&(n.wireframe=this.wireframe),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=this.flatShading),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),JSON.stringify(this.userData)!=="{}"&&(n.userData=this.userData);function i(s){let a=[];for(let o in s){let c=s[o];delete c.metadata,a.push(c)}return a}if(t){let s=i(e.textures),a=i(e.images);s.length>0&&(n.textures=s),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let i=t.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Ut=class extends ni{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new pt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Kc,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Ot=new R,Cr=new Ve,jt=class{constructor(e,t,n){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n===!0,this.usage=ya,this.updateRange={offset:0,count:-1},this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[e+i]=t.array[n+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Cr.fromBufferAttribute(this,t),Cr.applyMatrix3(e),this.setXY(t,Cr.x,Cr.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Ot.fromBufferAttribute(this,t),Ot.applyMatrix3(e),this.setXYZ(t,Ot.x,Ot.y,Ot.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Ot.fromBufferAttribute(this,t),Ot.applyMatrix4(e),this.setXYZ(t,Ot.x,Ot.y,Ot.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Ot.fromBufferAttribute(this,t),Ot.applyNormalMatrix(e),this.setXYZ(t,Ot.x,Ot.y,Ot.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Ot.fromBufferAttribute(this,t),Ot.transformDirection(e),this.setXYZ(t,Ot.x,Ot.y,Ot.z);return this}set(e,t=0){return this.array.set(e,t),this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=jn(t,this.array)),t}setX(e,t){return this.normalized&&(t=wt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=jn(t,this.array)),t}setY(e,t){return this.normalized&&(t=wt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=jn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=wt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=jn(t,this.array)),t}setW(e,t){return this.normalized&&(t=wt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,i){return e*=this.itemSize,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array),i=wt(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e*=this.itemSize,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array),i=wt(i,this.array),s=wt(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==ya&&(e.usage=this.usage),(this.updateRange.offset!==0||this.updateRange.count!==-1)&&(e.updateRange=this.updateRange),e}copyColorsArray(){console.error("THREE.BufferAttribute: copyColorsArray() was removed in r144.")}copyVector2sArray(){console.error("THREE.BufferAttribute: copyVector2sArray() was removed in r144.")}copyVector3sArray(){console.error("THREE.BufferAttribute: copyVector3sArray() was removed in r144.")}copyVector4sArray(){console.error("THREE.BufferAttribute: copyVector4sArray() was removed in r144.")}};var no=class extends jt{constructor(e,t,n){super(new Uint16Array(e),t,n)}};var io=class extends jt{constructor(e,t,n){super(new Uint32Array(e),t,n)}};var mt=class extends jt{constructor(e,t,n){super(new Float32Array(e),t,n)}};var ed=0,Sn=new Tt,ta=new Jt,Ki=new R,xn=new Ii,Ns=new Ii,Wt=new R,zt=class r extends Gn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:ed++}),this.uuid=ei(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(th(e)?io:no)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let s=new _n().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(e),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Sn.makeRotationFromQuaternion(e),this.applyMatrix4(Sn),this}rotateX(e){return Sn.makeRotationX(e),this.applyMatrix4(Sn),this}rotateY(e){return Sn.makeRotationY(e),this.applyMatrix4(Sn),this}rotateZ(e){return Sn.makeRotationZ(e),this.applyMatrix4(Sn),this}translate(e,t,n){return Sn.makeTranslation(e,t,n),this.applyMatrix4(Sn),this}scale(e,t,n){return Sn.makeScale(e,t,n),this.applyMatrix4(Sn),this}lookAt(e){return ta.lookAt(e),ta.updateMatrix(),this.applyMatrix4(ta.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ki).negate(),this.translate(Ki.x,Ki.y,Ki.z),this}setFromPoints(e){let t=[];for(let n=0,i=e.length;n<i;n++){let s=e[n];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new mt(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ii);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new R(-1/0,-1/0,-1/0),new R(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,i=t.length;n<i;n++){let s=t[n];xn.setFromBufferAttribute(s),this.morphTargetsRelative?(Wt.addVectors(this.boundingBox.min,xn.min),this.boundingBox.expandByPoint(Wt),Wt.addVectors(this.boundingBox.max,xn.max),this.boundingBox.expandByPoint(Wt)):(this.boundingBox.expandByPoint(xn.min),this.boundingBox.expandByPoint(xn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new xs);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new R,1/0);return}if(e){let n=this.boundingSphere.center;if(xn.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){let o=t[s];Ns.setFromBufferAttribute(o),this.morphTargetsRelative?(Wt.addVectors(xn.min,Ns.min),xn.expandByPoint(Wt),Wt.addVectors(xn.max,Ns.max),xn.expandByPoint(Wt)):(xn.expandByPoint(Ns.min),xn.expandByPoint(Ns.max))}xn.getCenter(n);let i=0;for(let s=0,a=e.count;s<a;s++)Wt.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(Wt));if(t)for(let s=0,a=t.length;s<a;s++){let o=t[s],c=this.morphTargetsRelative;for(let h=0,u=o.count;h<u;h++)Wt.fromBufferAttribute(o,h),c&&(Ki.fromBufferAttribute(e,h),Wt.add(Ki)),i=Math.max(i,n.distanceToSquared(Wt))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.array,i=t.position.array,s=t.normal.array,a=t.uv.array,o=i.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*o),4));let c=this.getAttribute("tangent").array,h=[],u=[];for(let z=0;z<o;z++)h[z]=new R,u[z]=new R;let l=new R,d=new R,m=new R,_=new Ve,p=new Ve,f=new Ve,b=new R,C=new R;function S(z,Y,ie){l.fromArray(i,z*3),d.fromArray(i,Y*3),m.fromArray(i,ie*3),_.fromArray(a,z*2),p.fromArray(a,Y*2),f.fromArray(a,ie*2),d.sub(l),m.sub(l),p.sub(_),f.sub(_);let q=1/(p.x*f.y-f.x*p.y);isFinite(q)&&(b.copy(d).multiplyScalar(f.y).addScaledVector(m,-p.y).multiplyScalar(q),C.copy(m).multiplyScalar(p.x).addScaledVector(d,-f.x).multiplyScalar(q),h[z].add(b),h[Y].add(b),h[ie].add(b),u[z].add(C),u[Y].add(C),u[ie].add(C))}let y=this.groups;y.length===0&&(y=[{start:0,count:n.length}]);for(let z=0,Y=y.length;z<Y;++z){let ie=y[z],q=ie.start,B=ie.count;for(let K=q,re=q+B;K<re;K+=3)S(n[K+0],n[K+1],n[K+2])}let M=new R,N=new R,k=new R,x=new R;function P(z){k.fromArray(s,z*3),x.copy(k);let Y=h[z];M.copy(Y),M.sub(k.multiplyScalar(k.dot(Y))).normalize(),N.crossVectors(x,Y);let q=N.dot(u[z])<0?-1:1;c[z*4]=M.x,c[z*4+1]=M.y,c[z*4+2]=M.z,c[z*4+3]=q}for(let z=0,Y=y.length;z<Y;++z){let ie=y[z],q=ie.start,B=ie.count;for(let K=q,re=q+B;K<re;K+=3)P(n[K+0]),P(n[K+1]),P(n[K+2])}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new jt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,m=n.count;d<m;d++)n.setXYZ(d,0,0,0);let i=new R,s=new R,a=new R,o=new R,c=new R,h=new R,u=new R,l=new R;if(e)for(let d=0,m=e.count;d<m;d+=3){let _=e.getX(d+0),p=e.getX(d+1),f=e.getX(d+2);i.fromBufferAttribute(t,_),s.fromBufferAttribute(t,p),a.fromBufferAttribute(t,f),u.subVectors(a,s),l.subVectors(i,s),u.cross(l),o.fromBufferAttribute(n,_),c.fromBufferAttribute(n,p),h.fromBufferAttribute(n,f),o.add(u),c.add(u),h.add(u),n.setXYZ(_,o.x,o.y,o.z),n.setXYZ(p,c.x,c.y,c.z),n.setXYZ(f,h.x,h.y,h.z)}else for(let d=0,m=t.count;d<m;d+=3)i.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),a.fromBufferAttribute(t,d+2),u.subVectors(a,s),l.subVectors(i,s),u.cross(l),n.setXYZ(d+0,u.x,u.y,u.z),n.setXYZ(d+1,u.x,u.y,u.z),n.setXYZ(d+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}merge(){return console.error("THREE.BufferGeometry.merge() has been removed. Use THREE.BufferGeometryUtils.mergeBufferGeometries() instead."),this}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Wt.fromBufferAttribute(e,t),Wt.normalize(),e.setXYZ(t,Wt.x,Wt.y,Wt.z)}toNonIndexed(){function e(o,c){let h=o.array,u=o.itemSize,l=o.normalized,d=new h.constructor(c.length*u),m=0,_=0;for(let p=0,f=c.length;p<f;p++){o.isInterleavedBufferAttribute?m=c[p]*o.data.stride+o.offset:m=c[p]*u;for(let b=0;b<u;b++)d[_++]=h[m++]}return new jt(d,u,l)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new r,n=this.index.array,i=this.attributes;for(let o in i){let c=i[o],h=e(c,n);t.setAttribute(o,h)}let s=this.morphAttributes;for(let o in s){let c=[],h=s[o];for(let u=0,l=h.length;u<l;u++){let d=h[u],m=e(d,n);c.push(m)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,c=a.length;o<c;o++){let h=a[o];t.addGroup(h.start,h.count,h.materialIndex)}return t}toJSON(){let e={metadata:{version:4.5,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let c=this.parameters;for(let h in c)c[h]!==void 0&&(e[h]=c[h]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let c in n){let h=n[c];e.data.attributes[c]=h.toJSON(e.data)}let i={},s=!1;for(let c in this.morphAttributes){let h=this.morphAttributes[c],u=[];for(let l=0,d=h.length;l<d;l++){let m=h[l];u.push(m.toJSON(e.data))}u.length>0&&(i[c]=u,s=!0)}s&&(e.data.morphAttributes=i,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone(t));let i=e.attributes;for(let h in i){let u=i[h];this.setAttribute(h,u.clone(t))}let s=e.morphAttributes;for(let h in s){let u=[],l=s[h];for(let d=0,m=l.length;d<m;d++)u.push(l[d].clone(t));this.morphAttributes[h]=u}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let h=0,u=a.length;h<u;h++){let l=a[h];this.addGroup(l.start,l.count,l.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,e.parameters!==void 0&&(this.parameters=Object.assign({},e.parameters)),this}dispose(){this.dispatchEvent({type:"dispose"})}},gc=new Tt,ji=new eo,na=new xs,di=new R,fi=new R,pi=new R,ia=new R,sa=new R,ra=new R,Pr=new R,Lr=new R,Rr=new R,Ir=new Ve,Dr=new Ve,Nr=new Ve,oa=new R,Or=new R,ut=class extends Jt{constructor(e=new zt,t=new Ut){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}raycast(e,t){let n=this.geometry,i=this.material,s=this.matrixWorld;if(i===void 0||(n.boundingSphere===null&&n.computeBoundingSphere(),na.copy(n.boundingSphere),na.applyMatrix4(s),e.ray.intersectsSphere(na)===!1)||(gc.copy(s).invert(),ji.copy(e.ray).applyMatrix4(gc),n.boundingBox!==null&&ji.intersectsBox(n.boundingBox)===!1))return;let a,o=n.index,c=n.attributes.position,h=n.morphAttributes.position,u=n.morphTargetsRelative,l=n.attributes.uv,d=n.attributes.uv2,m=n.groups,_=n.drawRange;if(o!==null)if(Array.isArray(i))for(let p=0,f=m.length;p<f;p++){let b=m[p],C=i[b.materialIndex],S=Math.max(b.start,_.start),y=Math.min(o.count,Math.min(b.start+b.count,_.start+_.count));for(let M=S,N=y;M<N;M+=3){let k=o.getX(M),x=o.getX(M+1),P=o.getX(M+2);a=zr(this,C,e,ji,c,h,u,l,d,k,x,P),a&&(a.faceIndex=Math.floor(M/3),a.face.materialIndex=b.materialIndex,t.push(a))}}else{let p=Math.max(0,_.start),f=Math.min(o.count,_.start+_.count);for(let b=p,C=f;b<C;b+=3){let S=o.getX(b),y=o.getX(b+1),M=o.getX(b+2);a=zr(this,i,e,ji,c,h,u,l,d,S,y,M),a&&(a.faceIndex=Math.floor(b/3),t.push(a))}}else if(c!==void 0)if(Array.isArray(i))for(let p=0,f=m.length;p<f;p++){let b=m[p],C=i[b.materialIndex],S=Math.max(b.start,_.start),y=Math.min(c.count,Math.min(b.start+b.count,_.start+_.count));for(let M=S,N=y;M<N;M+=3){let k=M,x=M+1,P=M+2;a=zr(this,C,e,ji,c,h,u,l,d,k,x,P),a&&(a.faceIndex=Math.floor(M/3),a.face.materialIndex=b.materialIndex,t.push(a))}}else{let p=Math.max(0,_.start),f=Math.min(c.count,_.start+_.count);for(let b=p,C=f;b<C;b+=3){let S=b,y=b+1,M=b+2;a=zr(this,i,e,ji,c,h,u,l,d,S,y,M),a&&(a.faceIndex=Math.floor(b/3),t.push(a))}}}};function td(r,e,t,n,i,s,a,o){let c;if(e.side===An?c=n.intersectTriangle(a,s,i,!0,o):c=n.intersectTriangle(i,s,a,e.side!==fn,o),c===null)return null;Or.copy(o),Or.applyMatrix4(r.matrixWorld);let h=t.ray.origin.distanceTo(Or);return h<t.near||h>t.far?null:{distance:h,point:Or.clone(),object:r}}function zr(r,e,t,n,i,s,a,o,c,h,u,l){di.fromBufferAttribute(i,h),fi.fromBufferAttribute(i,u),pi.fromBufferAttribute(i,l);let d=r.morphTargetInfluences;if(s&&d){Pr.set(0,0,0),Lr.set(0,0,0),Rr.set(0,0,0);for(let _=0,p=s.length;_<p;_++){let f=d[_],b=s[_];f!==0&&(ia.fromBufferAttribute(b,h),sa.fromBufferAttribute(b,u),ra.fromBufferAttribute(b,l),a?(Pr.addScaledVector(ia,f),Lr.addScaledVector(sa,f),Rr.addScaledVector(ra,f)):(Pr.addScaledVector(ia.sub(di),f),Lr.addScaledVector(sa.sub(fi),f),Rr.addScaledVector(ra.sub(pi),f)))}di.add(Pr),fi.add(Lr),pi.add(Rr)}r.isSkinnedMesh&&(r.boneTransform(h,di),r.boneTransform(u,fi),r.boneTransform(l,pi));let m=td(r,e,t,n,di,fi,pi,oa);if(m){o&&(Ir.fromBufferAttribute(o,h),Dr.fromBufferAttribute(o,u),Nr.fromBufferAttribute(o,l),m.uv=us.getUV(oa,di,fi,pi,Ir,Dr,Nr,new Ve)),c&&(Ir.fromBufferAttribute(c,h),Dr.fromBufferAttribute(c,u),Nr.fromBufferAttribute(c,l),m.uv2=us.getUV(oa,di,fi,pi,Ir,Dr,Nr,new Ve));let _={a:h,b:u,c:l,normal:new R,materialIndex:0};us.getNormal(di,fi,pi,_.normal),m.face=_}return m}var ii=class r extends zt{constructor(e=1,t=1,n=1,i=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:i,heightSegments:s,depthSegments:a};let o=this;i=Math.floor(i),s=Math.floor(s),a=Math.floor(a);let c=[],h=[],u=[],l=[],d=0,m=0;_("z","y","x",-1,-1,n,t,e,a,s,0),_("z","y","x",1,-1,n,t,-e,a,s,1),_("x","z","y",1,1,e,n,t,i,a,2),_("x","z","y",1,-1,e,n,-t,i,a,3),_("x","y","z",1,-1,e,t,n,i,s,4),_("x","y","z",-1,-1,e,t,-n,i,s,5),this.setIndex(c),this.setAttribute("position",new mt(h,3)),this.setAttribute("normal",new mt(u,3)),this.setAttribute("uv",new mt(l,2));function _(p,f,b,C,S,y,M,N,k,x,P){let z=y/k,Y=M/x,ie=y/2,q=M/2,B=N/2,K=k+1,re=x+1,ue=0,Z=0,me=new R;for(let ae=0;ae<re;ae++){let ee=ae*Y-q;for(let $=0;$<K;$++){let _e=$*z-ie;me[p]=_e*C,me[f]=ee*S,me[b]=B,h.push(me.x,me.y,me.z),me[p]=0,me[f]=0,me[b]=N>0?1:-1,u.push(me.x,me.y,me.z),l.push($/k),l.push(1-ae/x),ue+=1}}for(let ae=0;ae<x;ae++)for(let ee=0;ee<k;ee++){let $=d+ee+K*ae,_e=d+ee+K*(ae+1),pe=d+(ee+1)+K*(ae+1),ve=d+(ee+1)+K*ae;c.push($,_e,ve),c.push(_e,pe,ve),Z+=6}o.addGroup(m,Z,P),m+=Z,d+=ue}}static fromJSON(e){return new r(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function _s(r){let e={};for(let t in r){e[t]={};for(let n in r[t]){let i=r[t][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?e[t][n]=i.clone():Array.isArray(i)?e[t][n]=i.slice():e[t][n]=i}}return e}function nn(r){let e={};for(let t=0;t<r.length;t++){let n=_s(r[t]);for(let i in n)e[i]=n[i]}return e}function nd(r){let e=[];for(let t=0;t<r.length;t++)e.push(r[t].clone());return e}function ih(r){return r.getRenderTarget()===null&&r.outputEncoding===_t?Un:Xs}var id={clone:_s,merge:nn},sd=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,rd=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,si=class extends ni{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=sd,this.fragmentShader=rd,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv2:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=_s(e.uniforms),this.uniformsGroups=nd(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let i in this.uniforms){let a=this.uniforms[i].value;a&&a.isTexture?t.uniforms[i]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[i]={type:"m4",value:a.toArray()}:t.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}},so=class extends Jt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Tt,this.projectionMatrix=new Tt,this.projectionMatrixInverse=new Tt}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(-t[8],-t[9],-t[10]).normalize()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},rn=class extends so{constructor(e=50,t=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=Jr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Vs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Jr*2*Math.atan(Math.tan(Vs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,n,i,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Vs*.5*this.fov)/this.zoom,n=2*t,i=this.aspect*n,s=-.5*i,a=this.view;if(this.view!==null&&this.view.enabled){let c=a.fullWidth,h=a.fullHeight;s+=a.offsetX*i/c,t-=a.offsetY*n/h,i*=a.width/c,n*=a.height/h}let o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,t,t-n,e,this.far),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Qi=-90,es=1,wa=class extends Jt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n;let i=new rn(Qi,es,e,t);i.layers=this.layers,i.up.set(0,1,0),i.lookAt(1,0,0),this.add(i);let s=new rn(Qi,es,e,t);s.layers=this.layers,s.up.set(0,1,0),s.lookAt(-1,0,0),this.add(s);let a=new rn(Qi,es,e,t);a.layers=this.layers,a.up.set(0,0,-1),a.lookAt(0,1,0),this.add(a);let o=new rn(Qi,es,e,t);o.layers=this.layers,o.up.set(0,0,1),o.lookAt(0,-1,0),this.add(o);let c=new rn(Qi,es,e,t);c.layers=this.layers,c.up.set(0,1,0),c.lookAt(0,0,1),this.add(c);let h=new rn(Qi,es,e,t);h.layers=this.layers,h.up.set(0,1,0),h.lookAt(0,0,-1),this.add(h)}update(e,t){this.parent===null&&this.updateMatrixWorld();let n=this.renderTarget,[i,s,a,o,c,h]=this.children,u=e.getRenderTarget(),l=e.toneMapping,d=e.xr.enabled;e.toneMapping=Qn,e.xr.enabled=!1;let m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0),e.render(t,i),e.setRenderTarget(n,1),e.render(t,s),e.setRenderTarget(n,2),e.render(t,a),e.setRenderTarget(n,3),e.render(t,o),e.setRenderTarget(n,4),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5),e.render(t,h),e.setRenderTarget(u),e.toneMapping=l,e.xr.enabled=d,n.texture.needsPMREMUpdate=!0}},ro=class extends an{constructor(e,t,n,i,s,a,o,c,h,u){e=e!==void 0?e:[],t=t!==void 0?t:ps,super(e,t,n,i,s,a,o,c,h,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Sa=class extends ti{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},i=[n,n,n,n,n,n];this.texture=new ro(i,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.encoding),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Tn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.encoding=t.encoding,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new ii(5,5,5),s=new si({name:"CubemapFromEquirect",uniforms:_s(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:An,blending:gi});s.uniforms.tEquirect.value=t;let a=new ut(i,s),o=t.minFilter;return t.minFilter===bo&&(t.minFilter=Tn),new wa(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,n,i){let s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,n,i);e.setRenderTarget(s)}},aa=new R,od=new R,ad=new _n,Kn=class{constructor(e=new R(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,i){return this.normal.set(e,t,n),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let i=aa.subVectors(n,t).cross(od.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(this.normal).multiplyScalar(-this.distanceToPoint(e)).add(e)}intersectLine(e,t){let n=e.delta(aa),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let s=-(e.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:t.copy(n).multiplyScalar(s).add(e.start)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||ad.getNormalMatrix(e),i=this.coplanarPoint(aa).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},ts=new xs,Fr=new R,Zs=class{constructor(e=new Kn,t=new Kn,n=new Kn,i=new Kn,s=new Kn,a=new Kn){this.planes=[e,t,n,i,s,a]}set(e,t,n,i,s,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(i),o[4].copy(s),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e){let t=this.planes,n=e.elements,i=n[0],s=n[1],a=n[2],o=n[3],c=n[4],h=n[5],u=n[6],l=n[7],d=n[8],m=n[9],_=n[10],p=n[11],f=n[12],b=n[13],C=n[14],S=n[15];return t[0].setComponents(o-i,l-c,p-d,S-f).normalize(),t[1].setComponents(o+i,l+c,p+d,S+f).normalize(),t[2].setComponents(o+s,l+h,p+m,S+b).normalize(),t[3].setComponents(o-s,l-h,p-m,S-b).normalize(),t[4].setComponents(o-a,l-u,p-_,S-C).normalize(),t[5].setComponents(o+a,l+u,p+_,S+C).normalize(),this}intersectsObject(e){let t=e.geometry;return t.boundingSphere===null&&t.computeBoundingSphere(),ts.copy(t.boundingSphere).applyMatrix4(e.matrixWorld),this.intersectsSphere(ts)}intersectsSprite(e){return ts.center.set(0,0,0),ts.radius=.7071067811865476,ts.applyMatrix4(e.matrixWorld),this.intersectsSphere(ts)}intersectsSphere(e){let t=this.planes,n=e.center,i=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let i=t[n];if(Fr.x=i.normal.x>0?e.max.x:e.min.x,Fr.y=i.normal.y>0?e.max.y:e.min.y,Fr.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(Fr)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function sh(){let r=null,e=!1,t=null,n=null;function i(s,a){t(s,a),n=r.requestAnimationFrame(i)}return{start:function(){e!==!0&&t!==null&&(n=r.requestAnimationFrame(i),e=!0)},stop:function(){r.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function ld(r,e){let t=e.isWebGL2,n=new WeakMap;function i(h,u){let l=h.array,d=h.usage,m=r.createBuffer();r.bindBuffer(u,m),r.bufferData(u,l,d),h.onUploadCallback();let _;if(l instanceof Float32Array)_=5126;else if(l instanceof Uint16Array)if(h.isFloat16BufferAttribute)if(t)_=5131;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else _=5123;else if(l instanceof Int16Array)_=5122;else if(l instanceof Uint32Array)_=5125;else if(l instanceof Int32Array)_=5124;else if(l instanceof Int8Array)_=5120;else if(l instanceof Uint8Array)_=5121;else if(l instanceof Uint8ClampedArray)_=5121;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:m,type:_,bytesPerElement:l.BYTES_PER_ELEMENT,version:h.version}}function s(h,u,l){let d=u.array,m=u.updateRange;r.bindBuffer(l,h),m.count===-1?r.bufferSubData(l,0,d):(t?r.bufferSubData(l,m.offset*d.BYTES_PER_ELEMENT,d,m.offset,m.count):r.bufferSubData(l,m.offset*d.BYTES_PER_ELEMENT,d.subarray(m.offset,m.offset+m.count)),m.count=-1),u.onUploadCallback()}function a(h){return h.isInterleavedBufferAttribute&&(h=h.data),n.get(h)}function o(h){h.isInterleavedBufferAttribute&&(h=h.data);let u=n.get(h);u&&(r.deleteBuffer(u.buffer),n.delete(h))}function c(h,u){if(h.isGLBufferAttribute){let d=n.get(h);(!d||d.version<h.version)&&n.set(h,{buffer:h.buffer,type:h.type,bytesPerElement:h.elementSize,version:h.version});return}h.isInterleavedBufferAttribute&&(h=h.data);let l=n.get(h);l===void 0?n.set(h,i(h,u)):l.version<h.version&&(s(l.buffer,h,u),l.version=h.version)}return{get:a,remove:o,update:c}}var ri=class r extends zt{constructor(e=1,t=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:i};let s=e/2,a=t/2,o=Math.floor(n),c=Math.floor(i),h=o+1,u=c+1,l=e/o,d=t/c,m=[],_=[],p=[],f=[];for(let b=0;b<u;b++){let C=b*d-a;for(let S=0;S<h;S++){let y=S*l-s;_.push(y,-C,0),p.push(0,0,1),f.push(S/o),f.push(1-b/c)}}for(let b=0;b<c;b++)for(let C=0;C<o;C++){let S=C+h*b,y=C+h*(b+1),M=C+1+h*(b+1),N=C+1+h*b;m.push(S,y,N),m.push(y,M,N)}this.setIndex(m),this.setAttribute("position",new mt(_,3)),this.setAttribute("normal",new mt(p,3)),this.setAttribute("uv",new mt(f,2))}static fromJSON(e){return new r(e.width,e.height,e.widthSegments,e.heightSegments)}},cd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vUv ).g;
#endif`,hd=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,ud=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,dd=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,fd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vUv2 ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometry.normal, geometry.viewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,pd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,md="vec3 transformed = vec3( position );",gd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,xd=`vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 f0, const in float f90, const in float roughness ) {
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
	float D = D_GGX( alpha, dotNH );
	return F * ( V * D );
}
#ifdef USE_IRIDESCENCE
	vec3 BRDF_GGX_Iridescence( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 f0, const in float f90, const in float iridescence, const in vec3 iridescenceFresnel, const in float roughness ) {
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = mix( F_Schlick( f0, f90, dotVH ), iridescenceFresnel, iridescence );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif`,_d=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			 return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float R21 = R12;
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,yd=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vUv );
		vec2 dSTdy = dFdy( vUv );
		float Hll = bumpScale * texture2D( bumpMap, vUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = dFdx( surf_pos.xyz );
		vec3 vSigmaY = dFdy( surf_pos.xyz );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,vd=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,bd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Md=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,wd=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Sd=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Td=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Ad=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Ed=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Cd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
struct GeometricContext {
	vec3 position;
	vec3 normal;
	vec3 viewDir;
#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal;
#endif
};
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}`,Pd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_v0 0.339
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_v1 0.276
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_v4 0.046
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_v5 0.016
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_v6 0.0038
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Ld=`vec3 transformedNormal = objectNormal;
#ifdef USE_INSTANCING
	mat3 m = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( m[ 0 ], m[ 0 ] ), dot( m[ 1 ], m[ 1 ] ), dot( m[ 2 ], m[ 2 ] ) );
	transformedNormal = m * transformedNormal;
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	vec3 transformedTangent = ( modelViewMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Rd=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Id=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vUv ).x * displacementScale + displacementBias );
#endif`,Dd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Nd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Od="gl_FragColor = linearToOutputTexel( gl_FragColor );",zd=`vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Fd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,kd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Bd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Ud=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Vd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Gd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Hd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Wd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Xd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,qd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Yd=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vUv2 );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Zd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Jd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,$d=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in GeometricContext geometry, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometry.normal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in GeometricContext geometry, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Kd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
uniform vec3 lightProbe[ 9 ];
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( PHYSICALLY_CORRECT_LIGHTS )
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#else
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, const in GeometricContext geometry, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in GeometricContext geometry, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometry.position;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in GeometricContext geometry, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometry.position;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,jd=`#if defined( USE_ENVMAP )
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#if defined( ENVMAP_TYPE_CUBE_UV )
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#if defined( ENVMAP_TYPE_CUBE_UV )
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
#endif`,Qd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ef=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in GeometricContext geometry, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometry.normal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in GeometricContext geometry, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,tf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,nf=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in GeometricContext geometry, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometry.normal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometry.viewDir, geometry.normal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in GeometricContext geometry, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( geometryNormal ) ), abs( dFdy( geometryNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULARINTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vUv ).a;
		#endif
		#ifdef USE_SPECULARCOLORMAP
			specularColorFactor *= texture2D( specularColorMap, vUv ).rgb;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEENCOLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEENROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vUv ).a;
	#endif
#endif`,rf=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
};
vec3 clearcoatSpecular = vec3( 0.0 );
vec3 sheenSpecular = vec3( 0.0 );
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in GeometricContext geometry, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometry.normal;
		vec3 viewDir = geometry.viewDir;
		vec3 position = geometry.position;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in GeometricContext geometry, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometry.normal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometry.clearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecular += ccIrradiance * BRDF_GGX( directLight.direction, geometry.viewDir, geometry.clearcoatNormal, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecular += irradiance * BRDF_Sheen( directLight.direction, geometry.viewDir, geometry.normal, material.sheenColor, material.sheenRoughness );
	#endif
	#ifdef USE_IRIDESCENCE
		reflectedLight.directSpecular += irradiance * BRDF_GGX_Iridescence( directLight.direction, geometry.viewDir, geometry.normal, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness );
	#else
		reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometry.viewDir, geometry.normal, material.specularColor, material.specularF90, material.roughness );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in GeometricContext geometry, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in GeometricContext geometry, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecular += clearcoatRadiance * EnvironmentBRDF( geometry.clearcoatNormal, geometry.viewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecular += irradiance * material.sheenColor * IBLSheenBRDF( geometry.normal, geometry.viewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometry.normal, geometry.viewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometry.normal, geometry.viewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,of=`
GeometricContext geometry;
geometry.position = - vViewPosition;
geometry.normal = normal;
geometry.viewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
#ifdef USE_CLEARCOAT
	geometry.clearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometry.viewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometry, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= all( bvec2( directLight.visible, receiveShadow ) ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometry, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometry, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometry, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, geometry, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= all( bvec2( directLight.visible, receiveShadow ) ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometry, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometry, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	irradiance += getLightProbeIrradiance( lightProbe, geometry.normal );
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometry.normal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,af=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vUv2 );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometry.normal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	radiance += getIBLRadiance( geometry.viewDir, geometry.normal, material.roughness );
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometry.viewDir, geometry.clearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometry, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometry, material, reflectedLight );
#endif`,cf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,hf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,uf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,df=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,ff=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,pf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,mf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,gf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	uniform mat3 uvTransform;
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xf=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vUv );
	metalnessFactor *= texelMetalness.b;
#endif`,_f=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,yf=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,vf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,bf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Mf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,wf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	#ifdef USE_TANGENT
		vec3 tangent = normalize( vTangent );
		vec3 bitangent = normalize( vBitangent );
		#ifdef DOUBLE_SIDED
			tangent = tangent * faceDirection;
			bitangent = bitangent * faceDirection;
		#endif
		#if defined( TANGENTSPACE_NORMALMAP ) || defined( USE_CLEARCOAT_NORMALMAP )
			mat3 vTBN = mat3( tangent, bitangent, normal );
		#endif
	#endif
#endif
vec3 geometryNormal = normal;`,Sf=`#ifdef OBJECTSPACE_NORMALMAP
	normal = texture2D( normalMap, vUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( TANGENTSPACE_NORMALMAP )
	vec3 mapN = texture2D( normalMap, vUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	#ifdef USE_TANGENT
		normal = normalize( vTBN * mapN );
	#else
		normal = perturbNormal2Arb( - vViewPosition, normal, mapN, faceDirection );
	#endif
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Tf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Af=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ef=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Cf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef OBJECTSPACE_NORMALMAP
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( TANGENTSPACE_NORMALMAP ) || defined ( USE_CLEARCOAT_NORMALMAP ) )
	vec3 perturbNormal2Arb( vec3 eye_pos, vec3 surf_norm, vec3 mapN, float faceDirection ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( vUv.st );
		vec2 st1 = dFdy( vUv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : faceDirection * inversesqrt( det );
		return normalize( T * ( mapN.x * scale ) + B * ( mapN.y * scale ) + N * mapN.z );
	}
#endif`,Pf=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = geometryNormal;
#endif`,Lf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	#ifdef USE_TANGENT
		clearcoatNormal = normalize( vTBN * clearcoatMapN );
	#else
		clearcoatNormal = perturbNormal2Arb( - vViewPosition, clearcoatNormal, clearcoatMapN, faceDirection );
	#endif
#endif`,Rf=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif`,If=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Df=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha + 0.1;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Nf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float linearClipZ, const in float near, const in float far ) {
	return linearClipZ * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float invClipZ, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * invClipZ - far );
}`,Of=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,zf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Ff=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,kf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Bf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Uf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Vf=`#if NUM_SPOT_LIGHT_COORDS > 0
  varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
  uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bvec4 inFrustumVec = bvec4 ( shadowCoord.x >= 0.0, shadowCoord.x <= 1.0, shadowCoord.y >= 0.0, shadowCoord.y <= 1.0 );
		bool inFrustum = all( inFrustumVec );
		bvec2 frustumTestVec = bvec2( inFrustum, shadowCoord.z <= 1.0 );
		bool frustumTest = all( frustumTestVec );
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Gf=`#if NUM_SPOT_LIGHT_COORDS > 0
  uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
  varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Hf=`#if defined( USE_SHADOWMAP ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#if NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SPOT_LIGHT_COORDS > 0 || NUM_POINT_LIGHT_SHADOWS > 0
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		vec4 shadowWorldPosition;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
		vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
		vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
	#endif
#endif`,Wf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Xf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,qf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	uniform int boneTextureSize;
	mat4 getBoneMatrix( const in float i ) {
		float j = i * 4.0;
		float x = mod( j, float( boneTextureSize ) );
		float y = floor( j / float( boneTextureSize ) );
		float dx = 1.0 / float( boneTextureSize );
		float dy = 1.0 / float( boneTextureSize );
		y = dy * ( y + 0.5 );
		vec4 v1 = texture2D( boneTexture, vec2( dx * ( x + 0.5 ), y ) );
		vec4 v2 = texture2D( boneTexture, vec2( dx * ( x + 1.5 ), y ) );
		vec4 v3 = texture2D( boneTexture, vec2( dx * ( x + 2.5 ), y ) );
		vec4 v4 = texture2D( boneTexture, vec2( dx * ( x + 3.5 ), y ) );
		mat4 bone = mat4( v1, v2, v3, v4 );
		return bone;
	}
#endif`,Yf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Zf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Jf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,$f=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Kf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,jf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return toneMappingExposure * color;
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Qf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmission = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmission.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmission.rgb, material.transmission );
#endif`,ep=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float framebufferLod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		#ifdef texture2DLodEXT
			return texture2DLodEXT( transmissionSamplerMap, fragCoord.xy, framebufferLod );
		#else
			return texture2D( transmissionSamplerMap, fragCoord.xy, framebufferLod );
		#endif
	}
	vec3 applyVolumeAttenuation( const in vec3 radiance, const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return radiance;
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance * radiance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 attenuatedColor = applyVolumeAttenuation( transmittedLight.rgb, length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		return vec4( ( 1.0 - F ) * attenuatedColor * diffuseColor, transmittedLight.a );
	}
#endif`,tp=`#if ( defined( USE_UV ) && ! defined( UVS_VERTEX_ONLY ) )
	varying vec2 vUv;
#endif`,np=`#ifdef USE_UV
	#ifdef UVS_VERTEX_ONLY
		vec2 vUv;
	#else
		varying vec2 vUv;
	#endif
	uniform mat3 uvTransform;
#endif`,ip=`#ifdef USE_UV
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
#endif`,sp=`#if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
	varying vec2 vUv2;
#endif`,rp=`#if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
	attribute vec2 uv2;
	varying vec2 vUv2;
	uniform mat3 uv2Transform;
#endif`,op=`#if defined( USE_LIGHTMAP ) || defined( USE_AOMAP )
	vUv2 = ( uv2Transform * vec3( uv2, 1 ) ).xy;
#endif`,ap=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,lp=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,cp=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <encodings_fragment>
}`,hp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,up=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <encodings_fragment>
}`,dp=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,fp=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <encodings_fragment>
}`,pp=`#include <common>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,mp=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,gp=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,xp=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,_p=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,yp=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <encodings_fragment>
}`,vp=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,bp=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Mp=`#include <common>
#include <uv_pars_vertex>
#include <uv2_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <uv2_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wp=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <uv2_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vUv2 );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sp=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <uv_pars_vertex>
#include <uv2_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <uv2_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Tp=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <uv2_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ap=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Ep=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Cp=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( TANGENTSPACE_NORMALMAP )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( TANGENTSPACE_NORMALMAP )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Pp=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( TANGENTSPACE_NORMALMAP )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Lp=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <uv_pars_vertex>
#include <uv2_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <uv2_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rp=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <uv2_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ip=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <uv_pars_vertex>
#include <uv2_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <uv2_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Dp=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULARINTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
	#ifdef USE_SPECULARCOLORMAP
		uniform sampler2D specularColorMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEENCOLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEENROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <uv2_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <bsdfs>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecular;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometry.clearcoatNormal, geometry.viewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + clearcoatSpecular * material.clearcoat;
	#endif
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Np=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <uv_pars_vertex>
#include <uv2_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <uv2_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Op=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <uv2_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zp=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Fp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,kp=`#include <common>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Bp=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
}`,Up=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Vp=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <output_fragment>
	#include <tonemapping_fragment>
	#include <encodings_fragment>
	#include <fog_fragment>
}`,nt={alphamap_fragment:cd,alphamap_pars_fragment:hd,alphatest_fragment:ud,alphatest_pars_fragment:dd,aomap_fragment:fd,aomap_pars_fragment:pd,begin_vertex:md,beginnormal_vertex:gd,bsdfs:xd,iridescence_fragment:_d,bumpmap_pars_fragment:yd,clipping_planes_fragment:vd,clipping_planes_pars_fragment:bd,clipping_planes_pars_vertex:Md,clipping_planes_vertex:wd,color_fragment:Sd,color_pars_fragment:Td,color_pars_vertex:Ad,color_vertex:Ed,common:Cd,cube_uv_reflection_fragment:Pd,defaultnormal_vertex:Ld,displacementmap_pars_vertex:Rd,displacementmap_vertex:Id,emissivemap_fragment:Dd,emissivemap_pars_fragment:Nd,encodings_fragment:Od,encodings_pars_fragment:zd,envmap_fragment:Fd,envmap_common_pars_fragment:kd,envmap_pars_fragment:Bd,envmap_pars_vertex:Ud,envmap_physical_pars_fragment:jd,envmap_vertex:Vd,fog_vertex:Gd,fog_pars_vertex:Hd,fog_fragment:Wd,fog_pars_fragment:Xd,gradientmap_pars_fragment:qd,lightmap_fragment:Yd,lightmap_pars_fragment:Zd,lights_lambert_fragment:Jd,lights_lambert_pars_fragment:$d,lights_pars_begin:Kd,lights_toon_fragment:Qd,lights_toon_pars_fragment:ef,lights_phong_fragment:tf,lights_phong_pars_fragment:nf,lights_physical_fragment:sf,lights_physical_pars_fragment:rf,lights_fragment_begin:of,lights_fragment_maps:af,lights_fragment_end:lf,logdepthbuf_fragment:cf,logdepthbuf_pars_fragment:hf,logdepthbuf_pars_vertex:uf,logdepthbuf_vertex:df,map_fragment:ff,map_pars_fragment:pf,map_particle_fragment:mf,map_particle_pars_fragment:gf,metalnessmap_fragment:xf,metalnessmap_pars_fragment:_f,morphcolor_vertex:yf,morphnormal_vertex:vf,morphtarget_pars_vertex:bf,morphtarget_vertex:Mf,normal_fragment_begin:wf,normal_fragment_maps:Sf,normal_pars_fragment:Tf,normal_pars_vertex:Af,normal_vertex:Ef,normalmap_pars_fragment:Cf,clearcoat_normal_fragment_begin:Pf,clearcoat_normal_fragment_maps:Lf,clearcoat_pars_fragment:Rf,iridescence_pars_fragment:If,output_fragment:Df,packing:Nf,premultiplied_alpha_fragment:Of,project_vertex:zf,dithering_fragment:Ff,dithering_pars_fragment:kf,roughnessmap_fragment:Bf,roughnessmap_pars_fragment:Uf,shadowmap_pars_fragment:Vf,shadowmap_pars_vertex:Gf,shadowmap_vertex:Hf,shadowmask_pars_fragment:Wf,skinbase_vertex:Xf,skinning_pars_vertex:qf,skinning_vertex:Yf,skinnormal_vertex:Zf,specularmap_fragment:Jf,specularmap_pars_fragment:$f,tonemapping_fragment:Kf,tonemapping_pars_fragment:jf,transmission_fragment:Qf,transmission_pars_fragment:ep,uv_pars_fragment:tp,uv_pars_vertex:np,uv_vertex:ip,uv2_pars_fragment:sp,uv2_pars_vertex:rp,uv2_vertex:op,worldpos_vertex:ap,background_vert:lp,background_frag:cp,backgroundCube_vert:hp,backgroundCube_frag:up,cube_vert:dp,cube_frag:fp,depth_vert:pp,depth_frag:mp,distanceRGBA_vert:gp,distanceRGBA_frag:xp,equirect_vert:_p,equirect_frag:yp,linedashed_vert:vp,linedashed_frag:bp,meshbasic_vert:Mp,meshbasic_frag:wp,meshlambert_vert:Sp,meshlambert_frag:Tp,meshmatcap_vert:Ap,meshmatcap_frag:Ep,meshnormal_vert:Cp,meshnormal_frag:Pp,meshphong_vert:Lp,meshphong_frag:Rp,meshphysical_vert:Ip,meshphysical_frag:Dp,meshtoon_vert:Np,meshtoon_frag:Op,points_vert:zp,points_frag:Fp,shadow_vert:kp,shadow_frag:Bp,sprite_vert:Up,sprite_frag:Vp},ye={common:{diffuse:{value:new pt(16777215)},opacity:{value:1},map:{value:null},uvTransform:{value:new _n},uv2Transform:{value:new _n},alphaMap:{value:null},alphaTest:{value:0}},specularmap:{specularMap:{value:null}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1}},emissivemap:{emissiveMap:{value:null}},bumpmap:{bumpMap:{value:null},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalScale:{value:new Ve(1,1)}},displacementmap:{displacementMap:{value:null},displacementScale:{value:1},displacementBias:{value:0}},roughnessmap:{roughnessMap:{value:null}},metalnessmap:{metalnessMap:{value:null}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new pt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new pt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaTest:{value:0},uvTransform:{value:new _n}},sprite:{diffuse:{value:new pt(16777215)},opacity:{value:1},center:{value:new Ve(.5,.5)},rotation:{value:0},map:{value:null},alphaMap:{value:null},alphaTest:{value:0},uvTransform:{value:new _n}}},Vn={basic:{uniforms:nn([ye.common,ye.specularmap,ye.envmap,ye.aomap,ye.lightmap,ye.fog]),vertexShader:nt.meshbasic_vert,fragmentShader:nt.meshbasic_frag},lambert:{uniforms:nn([ye.common,ye.specularmap,ye.envmap,ye.aomap,ye.lightmap,ye.emissivemap,ye.bumpmap,ye.normalmap,ye.displacementmap,ye.fog,ye.lights,{emissive:{value:new pt(0)}}]),vertexShader:nt.meshlambert_vert,fragmentShader:nt.meshlambert_frag},phong:{uniforms:nn([ye.common,ye.specularmap,ye.envmap,ye.aomap,ye.lightmap,ye.emissivemap,ye.bumpmap,ye.normalmap,ye.displacementmap,ye.fog,ye.lights,{emissive:{value:new pt(0)},specular:{value:new pt(1118481)},shininess:{value:30}}]),vertexShader:nt.meshphong_vert,fragmentShader:nt.meshphong_frag},standard:{uniforms:nn([ye.common,ye.envmap,ye.aomap,ye.lightmap,ye.emissivemap,ye.bumpmap,ye.normalmap,ye.displacementmap,ye.roughnessmap,ye.metalnessmap,ye.fog,ye.lights,{emissive:{value:new pt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:nt.meshphysical_vert,fragmentShader:nt.meshphysical_frag},toon:{uniforms:nn([ye.common,ye.aomap,ye.lightmap,ye.emissivemap,ye.bumpmap,ye.normalmap,ye.displacementmap,ye.gradientmap,ye.fog,ye.lights,{emissive:{value:new pt(0)}}]),vertexShader:nt.meshtoon_vert,fragmentShader:nt.meshtoon_frag},matcap:{uniforms:nn([ye.common,ye.bumpmap,ye.normalmap,ye.displacementmap,ye.fog,{matcap:{value:null}}]),vertexShader:nt.meshmatcap_vert,fragmentShader:nt.meshmatcap_frag},points:{uniforms:nn([ye.points,ye.fog]),vertexShader:nt.points_vert,fragmentShader:nt.points_frag},dashed:{uniforms:nn([ye.common,ye.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:nt.linedashed_vert,fragmentShader:nt.linedashed_frag},depth:{uniforms:nn([ye.common,ye.displacementmap]),vertexShader:nt.depth_vert,fragmentShader:nt.depth_frag},normal:{uniforms:nn([ye.common,ye.bumpmap,ye.normalmap,ye.displacementmap,{opacity:{value:1}}]),vertexShader:nt.meshnormal_vert,fragmentShader:nt.meshnormal_frag},sprite:{uniforms:nn([ye.sprite,ye.fog]),vertexShader:nt.sprite_vert,fragmentShader:nt.sprite_frag},background:{uniforms:{uvTransform:{value:new _n},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:nt.background_vert,fragmentShader:nt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:nt.backgroundCube_vert,fragmentShader:nt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:nt.cube_vert,fragmentShader:nt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:nt.equirect_vert,fragmentShader:nt.equirect_frag},distanceRGBA:{uniforms:nn([ye.common,ye.displacementmap,{referencePosition:{value:new R},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:nt.distanceRGBA_vert,fragmentShader:nt.distanceRGBA_frag},shadow:{uniforms:nn([ye.lights,ye.fog,{color:{value:new pt(0)},opacity:{value:1}}]),vertexShader:nt.shadow_vert,fragmentShader:nt.shadow_frag}};Vn.physical={uniforms:nn([Vn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatNormalScale:{value:new Ve(1,1)},clearcoatNormalMap:{value:null},iridescence:{value:0},iridescenceMap:{value:null},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},sheen:{value:0},sheenColor:{value:new pt(0)},sheenColorMap:{value:null},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},transmission:{value:0},transmissionMap:{value:null},transmissionSamplerSize:{value:new Ve},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},attenuationDistance:{value:0},attenuationColor:{value:new pt(0)},specularIntensity:{value:1},specularIntensityMap:{value:null},specularColor:{value:new pt(1,1,1)},specularColorMap:{value:null}}]),vertexShader:nt.meshphysical_vert,fragmentShader:nt.meshphysical_frag};var kr={r:0,b:0,g:0};function Gp(r,e,t,n,i,s,a){let o=new pt(0),c=s===!0?0:1,h,u,l=null,d=0,m=null;function _(f,b){let C=!1,S=b.isScene===!0?b.background:null;S&&S.isTexture&&(S=(b.backgroundBlurriness>0?t:e).get(S));let y=r.xr,M=y.getSession&&y.getSession();M&&M.environmentBlendMode==="additive"&&(S=null),S===null?p(o,c):S&&S.isColor&&(p(S,1),C=!0),(r.autoClear||C)&&r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil),S&&(S.isCubeTexture||S.mapping===vo)?(u===void 0&&(u=new ut(new ii(1,1,1),new si({name:"BackgroundCubeMaterial",uniforms:_s(Vn.backgroundCube.uniforms),vertexShader:Vn.backgroundCube.vertexShader,fragmentShader:Vn.backgroundCube.fragmentShader,side:An,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),u.geometry.deleteAttribute("uv"),u.onBeforeRender=function(N,k,x){this.matrixWorld.copyPosition(x.matrixWorld)},Object.defineProperty(u.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(u)),u.material.uniforms.envMap.value=S,u.material.uniforms.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,u.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,u.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,(l!==S||d!==S.version||m!==r.toneMapping)&&(u.material.needsUpdate=!0,l=S,d=S.version,m=r.toneMapping),u.layers.enableAll(),f.unshift(u,u.geometry,u.material,0,0,null)):S&&S.isTexture&&(h===void 0&&(h=new ut(new ri(2,2),new si({name:"BackgroundMaterial",uniforms:_s(Vn.background.uniforms),vertexShader:Vn.background.vertexShader,fragmentShader:Vn.background.fragmentShader,side:fs,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),Object.defineProperty(h.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(h)),h.material.uniforms.t2D.value=S,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,S.matrixAutoUpdate===!0&&S.updateMatrix(),h.material.uniforms.uvTransform.value.copy(S.matrix),(l!==S||d!==S.version||m!==r.toneMapping)&&(h.material.needsUpdate=!0,l=S,d=S.version,m=r.toneMapping),h.layers.enableAll(),f.unshift(h,h.geometry,h.material,0,0,null))}function p(f,b){f.getRGB(kr,ih(r)),n.buffers.color.setClear(kr.r,kr.g,kr.b,b,a)}return{getClearColor:function(){return o},setClearColor:function(f,b=1){o.set(f),c=b,p(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(f){c=f,p(o,c)},render:_}}function Hp(r,e,t,n){let i=r.getParameter(34921),s=n.isWebGL2?null:e.get("OES_vertex_array_object"),a=n.isWebGL2||s!==null,o={},c=f(null),h=c,u=!1;function l(B,K,re,ue,Z){let me=!1;if(a){let ae=p(ue,re,K);h!==ae&&(h=ae,m(h.object)),me=b(B,ue,re,Z),me&&C(B,ue,re,Z)}else{let ae=K.wireframe===!0;(h.geometry!==ue.id||h.program!==re.id||h.wireframe!==ae)&&(h.geometry=ue.id,h.program=re.id,h.wireframe=ae,me=!0)}Z!==null&&t.update(Z,34963),(me||u)&&(u=!1,x(B,K,re,ue),Z!==null&&r.bindBuffer(34963,t.get(Z).buffer))}function d(){return n.isWebGL2?r.createVertexArray():s.createVertexArrayOES()}function m(B){return n.isWebGL2?r.bindVertexArray(B):s.bindVertexArrayOES(B)}function _(B){return n.isWebGL2?r.deleteVertexArray(B):s.deleteVertexArrayOES(B)}function p(B,K,re){let ue=re.wireframe===!0,Z=o[B.id];Z===void 0&&(Z={},o[B.id]=Z);let me=Z[K.id];me===void 0&&(me={},Z[K.id]=me);let ae=me[ue];return ae===void 0&&(ae=f(d()),me[ue]=ae),ae}function f(B){let K=[],re=[],ue=[];for(let Z=0;Z<i;Z++)K[Z]=0,re[Z]=0,ue[Z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:K,enabledAttributes:re,attributeDivisors:ue,object:B,attributes:{},index:null}}function b(B,K,re,ue){let Z=h.attributes,me=K.attributes,ae=0,ee=re.getAttributes();for(let $ in ee)if(ee[$].location>=0){let pe=Z[$],ve=me[$];if(ve===void 0&&($==="instanceMatrix"&&B.instanceMatrix&&(ve=B.instanceMatrix),$==="instanceColor"&&B.instanceColor&&(ve=B.instanceColor)),pe===void 0||pe.attribute!==ve||ve&&pe.data!==ve.data)return!0;ae++}return h.attributesNum!==ae||h.index!==ue}function C(B,K,re,ue){let Z={},me=K.attributes,ae=0,ee=re.getAttributes();for(let $ in ee)if(ee[$].location>=0){let pe=me[$];pe===void 0&&($==="instanceMatrix"&&B.instanceMatrix&&(pe=B.instanceMatrix),$==="instanceColor"&&B.instanceColor&&(pe=B.instanceColor));let ve={};ve.attribute=pe,pe&&pe.data&&(ve.data=pe.data),Z[$]=ve,ae++}h.attributes=Z,h.attributesNum=ae,h.index=ue}function S(){let B=h.newAttributes;for(let K=0,re=B.length;K<re;K++)B[K]=0}function y(B){M(B,0)}function M(B,K){let re=h.newAttributes,ue=h.enabledAttributes,Z=h.attributeDivisors;re[B]=1,ue[B]===0&&(r.enableVertexAttribArray(B),ue[B]=1),Z[B]!==K&&((n.isWebGL2?r:e.get("ANGLE_instanced_arrays"))[n.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](B,K),Z[B]=K)}function N(){let B=h.newAttributes,K=h.enabledAttributes;for(let re=0,ue=K.length;re<ue;re++)K[re]!==B[re]&&(r.disableVertexAttribArray(re),K[re]=0)}function k(B,K,re,ue,Z,me){n.isWebGL2===!0&&(re===5124||re===5125)?r.vertexAttribIPointer(B,K,re,Z,me):r.vertexAttribPointer(B,K,re,ue,Z,me)}function x(B,K,re,ue){if(n.isWebGL2===!1&&(B.isInstancedMesh||ue.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;S();let Z=ue.attributes,me=re.getAttributes(),ae=K.defaultAttributeValues;for(let ee in me){let $=me[ee];if($.location>=0){let _e=Z[ee];if(_e===void 0&&(ee==="instanceMatrix"&&B.instanceMatrix&&(_e=B.instanceMatrix),ee==="instanceColor"&&B.instanceColor&&(_e=B.instanceColor)),_e!==void 0){let pe=_e.normalized,ve=_e.itemSize,te=t.get(_e);if(te===void 0)continue;let Ze=te.buffer,Re=te.type,Be=te.bytesPerElement;if(_e.isInterleavedBufferAttribute){let Pe=_e.data,ft=Pe.stride,Je=_e.offset;if(Pe.isInstancedInterleavedBuffer){for(let Ce=0;Ce<$.locationSize;Ce++)M($.location+Ce,Pe.meshPerAttribute);B.isInstancedMesh!==!0&&ue._maxInstanceCount===void 0&&(ue._maxInstanceCount=Pe.meshPerAttribute*Pe.count)}else for(let Ce=0;Ce<$.locationSize;Ce++)y($.location+Ce);r.bindBuffer(34962,Ze);for(let Ce=0;Ce<$.locationSize;Ce++)k($.location+Ce,ve/$.locationSize,Re,pe,ft*Be,(Je+ve/$.locationSize*Ce)*Be)}else{if(_e.isInstancedBufferAttribute){for(let Pe=0;Pe<$.locationSize;Pe++)M($.location+Pe,_e.meshPerAttribute);B.isInstancedMesh!==!0&&ue._maxInstanceCount===void 0&&(ue._maxInstanceCount=_e.meshPerAttribute*_e.count)}else for(let Pe=0;Pe<$.locationSize;Pe++)y($.location+Pe);r.bindBuffer(34962,Ze);for(let Pe=0;Pe<$.locationSize;Pe++)k($.location+Pe,ve/$.locationSize,Re,pe,ve*Be,ve/$.locationSize*Pe*Be)}}else if(ae!==void 0){let pe=ae[ee];if(pe!==void 0)switch(pe.length){case 2:r.vertexAttrib2fv($.location,pe);break;case 3:r.vertexAttrib3fv($.location,pe);break;case 4:r.vertexAttrib4fv($.location,pe);break;default:r.vertexAttrib1fv($.location,pe)}}}}N()}function P(){ie();for(let B in o){let K=o[B];for(let re in K){let ue=K[re];for(let Z in ue)_(ue[Z].object),delete ue[Z];delete K[re]}delete o[B]}}function z(B){if(o[B.id]===void 0)return;let K=o[B.id];for(let re in K){let ue=K[re];for(let Z in ue)_(ue[Z].object),delete ue[Z];delete K[re]}delete o[B.id]}function Y(B){for(let K in o){let re=o[K];if(re[B.id]===void 0)continue;let ue=re[B.id];for(let Z in ue)_(ue[Z].object),delete ue[Z];delete re[B.id]}}function ie(){q(),u=!0,h!==c&&(h=c,m(h.object))}function q(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:l,reset:ie,resetDefaultState:q,dispose:P,releaseStatesOfGeometry:z,releaseStatesOfProgram:Y,initAttributes:S,enableAttribute:y,disableUnusedAttributes:N}}function Wp(r,e,t,n){let i=n.isWebGL2,s;function a(h){s=h}function o(h,u){r.drawArrays(s,h,u),t.update(u,s,1)}function c(h,u,l){if(l===0)return;let d,m;if(i)d=r,m="drawArraysInstanced";else if(d=e.get("ANGLE_instanced_arrays"),m="drawArraysInstancedANGLE",d===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}d[m](s,h,u,l),t.update(u,s,l)}this.setMode=a,this.render=o,this.renderInstances=c}function Xp(r,e,t){let n;function i(){if(n!==void 0)return n;if(e.has("EXT_texture_filter_anisotropic")===!0){let k=e.get("EXT_texture_filter_anisotropic");n=r.getParameter(k.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n}function s(k){if(k==="highp"){if(r.getShaderPrecisionFormat(35633,36338).precision>0&&r.getShaderPrecisionFormat(35632,36338).precision>0)return"highp";k="mediump"}return k==="mediump"&&r.getShaderPrecisionFormat(35633,36337).precision>0&&r.getShaderPrecisionFormat(35632,36337).precision>0?"mediump":"lowp"}let a=typeof WebGL2RenderingContext!="undefined"&&r instanceof WebGL2RenderingContext||typeof WebGL2ComputeRenderingContext!="undefined"&&r instanceof WebGL2ComputeRenderingContext,o=t.precision!==void 0?t.precision:"highp",c=s(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);let h=a||e.has("WEBGL_draw_buffers"),u=t.logarithmicDepthBuffer===!0,l=r.getParameter(34930),d=r.getParameter(35660),m=r.getParameter(3379),_=r.getParameter(34076),p=r.getParameter(34921),f=r.getParameter(36347),b=r.getParameter(36348),C=r.getParameter(36349),S=d>0,y=a||e.has("OES_texture_float"),M=S&&y,N=a?r.getParameter(36183):0;return{isWebGL2:a,drawBuffers:h,getMaxAnisotropy:i,getMaxPrecision:s,precision:o,logarithmicDepthBuffer:u,maxTextures:l,maxVertexTextures:d,maxTextureSize:m,maxCubemapSize:_,maxAttributes:p,maxVertexUniforms:f,maxVaryings:b,maxFragmentUniforms:C,vertexTextures:S,floatFragmentTextures:y,floatVertexTextures:M,maxSamples:N}}function qp(r){let e=this,t=null,n=0,i=!1,s=!1,a=new Kn,o=new _n,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(l,d,m){let _=l.length!==0||d||n!==0||i;return i=d,t=u(l,m,0),n=l.length,_},this.beginShadows=function(){s=!0,u(null)},this.endShadows=function(){s=!1,h()},this.setState=function(l,d,m){let _=l.clippingPlanes,p=l.clipIntersection,f=l.clipShadows,b=r.get(l);if(!i||_===null||_.length===0||s&&!f)s?u(null):h();else{let C=s?0:n,S=C*4,y=b.clippingState||null;c.value=y,y=u(_,d,S,m);for(let M=0;M!==S;++M)y[M]=t[M];b.clippingState=y,this.numIntersection=p?this.numPlanes:0,this.numPlanes+=C}};function h(){c.value!==t&&(c.value=t,c.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function u(l,d,m,_){let p=l!==null?l.length:0,f=null;if(p!==0){if(f=c.value,_!==!0||f===null){let b=m+p*4,C=d.matrixWorldInverse;o.getNormalMatrix(C),(f===null||f.length<b)&&(f=new Float32Array(b));for(let S=0,y=m;S!==p;++S,y+=4)a.copy(l[S]).applyMatrix4(C,o),a.normal.toArray(f,y),f[y+3]=a.constant}c.value=f,c.needsUpdate=!0}return e.numPlanes=p,e.numIntersection=0,f}}function Yp(r){let e=new WeakMap;function t(a,o){return o===ma?a.mapping=ps:o===ga&&(a.mapping=ms),a}function n(a){if(a&&a.isTexture&&a.isRenderTargetTexture===!1){let o=a.mapping;if(o===ma||o===ga)if(e.has(a)){let c=e.get(a).texture;return t(c,a.mapping)}else{let c=a.image;if(c&&c.height>0){let h=new Sa(c.height/2);return h.fromEquirectangularTexture(r,a),e.set(a,h),a.addEventListener("dispose",i),t(h.texture,a.mapping)}else return null}}return a}function i(a){let o=a.target;o.removeEventListener("dispose",i);let c=e.get(o);c!==void 0&&(e.delete(o),c.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}var oo=class extends so{constructor(e=-1,t=1,n=1,i=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=i,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,i,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,s=n-e,a=n+e,o=i+t,c=i-t;if(this.view!==null&&this.view.enabled){let h=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=h*this.view.offsetX,a=s+h*this.view.width,o-=u*this.view.offsetY,c=o-u*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,c,this.near,this.far),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},ls=4,xc=[.125,.215,.35,.446,.526,.582],Ti=20,la=new oo,_c=new pt,ca=null,Si=(1+Math.sqrt(5))/2,ns=1/Si,yc=[new R(1,1,1),new R(-1,1,1),new R(1,1,-1),new R(-1,1,-1),new R(0,Si,ns),new R(0,Si,-ns),new R(ns,0,Si),new R(-ns,0,Si),new R(Si,ns,0),new R(-Si,ns,0)],ao=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,i=100){ca=this._renderer.getRenderTarget(),this._setSize(256);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,i,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Mc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=bc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ca),e.scissorTest=!1,Br(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ps||e.mapping===ms?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ca=this._renderer.getRenderTarget();let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Tn,minFilter:Tn,generateMipmaps:!1,type:Ws,format:zn,encoding:Ri,depthBuffer:!1},i=vc(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=vc(e,t,n);let{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Zp(s)),this._blurMaterial=Jp(s,e,t)}return i}_compileMaterial(e){let t=new ut(this._lodPlanes[0],e);this._renderer.compile(t,la)}_sceneToCubeUV(e,t,n,i){let o=new rn(90,1,t,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,l=u.autoClear,d=u.toneMapping;u.getClearColor(_c),u.toneMapping=Qn,u.autoClear=!1;let m=new Ut({name:"PMREM.Background",side:An,depthWrite:!1,depthTest:!1}),_=new ut(new ii,m),p=!1,f=e.background;f?f.isColor&&(m.color.copy(f),e.background=null,p=!0):(m.color.copy(_c),p=!0);for(let b=0;b<6;b++){let C=b%3;C===0?(o.up.set(0,c[b],0),o.lookAt(h[b],0,0)):C===1?(o.up.set(0,0,c[b]),o.lookAt(0,h[b],0)):(o.up.set(0,c[b],0),o.lookAt(0,0,h[b]));let S=this._cubeSize;Br(i,C*S,b>2?S:0,S,S),u.setRenderTarget(i),p&&u.render(_,o),u.render(e,o)}_.geometry.dispose(),_.material.dispose(),u.toneMapping=d,u.autoClear=l,e.background=f}_textureToCubeUV(e,t){let n=this._renderer,i=e.mapping===ps||e.mapping===ms;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Mc()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=bc());let s=i?this._cubemapMaterial:this._equirectMaterial,a=new ut(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;let c=this._cubeSize;Br(t,0,0,3*c,2*c),n.setRenderTarget(t),n.render(a,la)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;for(let i=1;i<this._lodPlanes.length;i++){let s=Math.sqrt(this._sigmas[i]*this._sigmas[i]-this._sigmas[i-1]*this._sigmas[i-1]),a=yc[(i-1)%yc.length];this._blur(e,i-1,i,s,a)}t.autoClear=n}_blur(e,t,n,i,s){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,n,i,"latitudinal",s),this._halfBlur(a,e,n,n,i,"longitudinal",s)}_halfBlur(e,t,n,i,s,a,o){let c=this._renderer,h=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let u=3,l=new ut(this._lodPlanes[i],h),d=h.uniforms,m=this._sizeLods[n]-1,_=isFinite(s)?Math.PI/(2*m):2*Math.PI/(2*Ti-1),p=s/_,f=isFinite(s)?1+Math.floor(u*p):Ti;f>Ti&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${f} samples when the maximum is set to ${Ti}`);let b=[],C=0;for(let k=0;k<Ti;++k){let x=k/p,P=Math.exp(-x*x/2);b.push(P),k===0?C+=P:k<f&&(C+=2*P)}for(let k=0;k<b.length;k++)b[k]=b[k]/C;d.envMap.value=e.texture,d.samples.value=f,d.weights.value=b,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:S}=this;d.dTheta.value=_,d.mipInt.value=S-n;let y=this._sizeLods[i],M=3*y*(i>S-ls?i-S+ls:0),N=4*(this._cubeSize-y);Br(t,M,N,3*y,2*y),c.setRenderTarget(t),c.render(l,la)}};function Zp(r){let e=[],t=[],n=[],i=r,s=r-ls+1+xc.length;for(let a=0;a<s;a++){let o=Math.pow(2,i);t.push(o);let c=1/o;a>r-ls?c=xc[a-r+ls-1]:a===0&&(c=0),n.push(c);let h=1/(o-2),u=-h,l=1+h,d=[u,u,l,u,l,l,u,u,l,l,u,l],m=6,_=6,p=3,f=2,b=1,C=new Float32Array(p*_*m),S=new Float32Array(f*_*m),y=new Float32Array(b*_*m);for(let N=0;N<m;N++){let k=N%3*2/3-1,x=N>2?0:-1,P=[k,x,0,k+2/3,x,0,k+2/3,x+1,0,k,x,0,k+2/3,x+1,0,k,x+1,0];C.set(P,p*_*N),S.set(d,f*_*N);let z=[N,N,N,N,N,N];y.set(z,b*_*N)}let M=new zt;M.setAttribute("position",new jt(C,p)),M.setAttribute("uv",new jt(S,f)),M.setAttribute("faceIndex",new jt(y,b)),e.push(M),i>ls&&i--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function vc(r,e,t){let n=new ti(r,e,t);return n.texture.mapping=vo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Br(r,e,t,n,i){r.viewport.set(e,t,n,i),r.scissor.set(e,t,n,i)}function Jp(r,e,t){let n=new Float32Array(Ti),i=new R(0,1,0);return new si({name:"SphericalGaussianBlur",defines:{n:Ti,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:el(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function bc(){return new si({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:el(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function Mc(){return new si({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:el(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function el(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function $p(r){let e=new WeakMap,t=null;function n(o){if(o&&o.isTexture){let c=o.mapping,h=c===ma||c===ga,u=c===ps||c===ms;if(h||u)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let l=e.get(o);return t===null&&(t=new ao(r)),l=h?t.fromEquirectangular(o,l):t.fromCubemap(o,l),e.set(o,l),l.texture}else{if(e.has(o))return e.get(o).texture;{let l=o.image;if(h&&l&&l.height>0||u&&l&&i(l)){t===null&&(t=new ao(r));let d=h?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,d),o.addEventListener("dispose",s),d.texture}else return null}}}return o}function i(o){let c=0,h=6;for(let u=0;u<h;u++)o[u]!==void 0&&c++;return c===h}function s(o){let c=o.target;c.removeEventListener("dispose",s);let h=e.get(c);h!==void 0&&(e.delete(c),h.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:a}}function Kp(r){let e={};function t(n){if(e[n]!==void 0)return e[n];let i;switch(n){case"WEBGL_depth_texture":i=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=r.getExtension(n)}return e[n]=i,i}return{has:function(n){return t(n)!==null},init:function(n){n.isWebGL2?t("EXT_color_buffer_float"):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(n){let i=t(n);return i===null&&console.warn("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function jp(r,e,t,n){let i={},s=new WeakMap;function a(l){let d=l.target;d.index!==null&&e.remove(d.index);for(let _ in d.attributes)e.remove(d.attributes[_]);d.removeEventListener("dispose",a),delete i[d.id];let m=s.get(d);m&&(e.remove(m),s.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function o(l,d){return i[d.id]===!0||(d.addEventListener("dispose",a),i[d.id]=!0,t.memory.geometries++),d}function c(l){let d=l.attributes;for(let _ in d)e.update(d[_],34962);let m=l.morphAttributes;for(let _ in m){let p=m[_];for(let f=0,b=p.length;f<b;f++)e.update(p[f],34962)}}function h(l){let d=[],m=l.index,_=l.attributes.position,p=0;if(m!==null){let C=m.array;p=m.version;for(let S=0,y=C.length;S<y;S+=3){let M=C[S+0],N=C[S+1],k=C[S+2];d.push(M,N,N,k,k,M)}}else{let C=_.array;p=_.version;for(let S=0,y=C.length/3-1;S<y;S+=3){let M=S+0,N=S+1,k=S+2;d.push(M,N,N,k,k,M)}}let f=new(th(d)?io:no)(d,1);f.version=p;let b=s.get(l);b&&e.remove(b),s.set(l,f)}function u(l){let d=s.get(l);if(d){let m=l.index;m!==null&&d.version<m.version&&h(l)}else h(l);return s.get(l)}return{get:o,update:c,getWireframeAttribute:u}}function Qp(r,e,t,n){let i=n.isWebGL2,s;function a(d){s=d}let o,c;function h(d){o=d.type,c=d.bytesPerElement}function u(d,m){r.drawElements(s,m,o,d*c),t.update(m,s,1)}function l(d,m,_){if(_===0)return;let p,f;if(i)p=r,f="drawElementsInstanced";else if(p=e.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",p===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[f](s,m,o,d*c,_),t.update(m,s,_)}this.setMode=a,this.setIndex=h,this.render=u,this.renderInstances=l}function em(r){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,a,o){switch(t.calls++,a){case 4:t.triangles+=o*(s/3);break;case 1:t.lines+=o*(s/2);break;case 3:t.lines+=o*(s-1);break;case 2:t.lines+=o*s;break;case 0:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){t.frame++,t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:i,update:n}}function tm(r,e){return r[0]-e[0]}function nm(r,e){return Math.abs(e[1])-Math.abs(r[1])}function im(r,e,t){let n={},i=new Float32Array(8),s=new WeakMap,a=new Xt,o=[];for(let h=0;h<8;h++)o[h]=[h,0];function c(h,u,l,d){let m=h.morphTargetInfluences;if(e.isWebGL2===!0){let _=u.morphAttributes.position||u.morphAttributes.normal||u.morphAttributes.color,p=_!==void 0?_.length:0,f=s.get(u);if(f===void 0||f.count!==p){let K=function(){q.dispose(),s.delete(u),u.removeEventListener("dispose",K)};f!==void 0&&f.texture.dispose();let S=u.morphAttributes.position!==void 0,y=u.morphAttributes.normal!==void 0,M=u.morphAttributes.color!==void 0,N=u.morphAttributes.position||[],k=u.morphAttributes.normal||[],x=u.morphAttributes.color||[],P=0;S===!0&&(P=1),y===!0&&(P=2),M===!0&&(P=3);let z=u.attributes.position.count*P,Y=1;z>e.maxTextureSize&&(Y=Math.ceil(z/e.maxTextureSize),z=e.maxTextureSize);let ie=new Float32Array(z*Y*4*p),q=new Qr(ie,z,Y,p);q.type=Ei,q.needsUpdate=!0;let B=P*4;for(let re=0;re<p;re++){let ue=N[re],Z=k[re],me=x[re],ae=z*Y*4*re;for(let ee=0;ee<ue.count;ee++){let $=ee*B;S===!0&&(a.fromBufferAttribute(ue,ee),ie[ae+$+0]=a.x,ie[ae+$+1]=a.y,ie[ae+$+2]=a.z,ie[ae+$+3]=0),y===!0&&(a.fromBufferAttribute(Z,ee),ie[ae+$+4]=a.x,ie[ae+$+5]=a.y,ie[ae+$+6]=a.z,ie[ae+$+7]=0),M===!0&&(a.fromBufferAttribute(me,ee),ie[ae+$+8]=a.x,ie[ae+$+9]=a.y,ie[ae+$+10]=a.z,ie[ae+$+11]=me.itemSize===4?a.w:1)}}f={count:p,texture:q,size:new Ve(z,Y)},s.set(u,f),u.addEventListener("dispose",K)}let b=0;for(let S=0;S<m.length;S++)b+=m[S];let C=u.morphTargetsRelative?1:1-b;d.getUniforms().setValue(r,"morphTargetBaseInfluence",C),d.getUniforms().setValue(r,"morphTargetInfluences",m),d.getUniforms().setValue(r,"morphTargetsTexture",f.texture,t),d.getUniforms().setValue(r,"morphTargetsTextureSize",f.size)}else{let _=m===void 0?0:m.length,p=n[u.id];if(p===void 0||p.length!==_){p=[];for(let y=0;y<_;y++)p[y]=[y,0];n[u.id]=p}for(let y=0;y<_;y++){let M=p[y];M[0]=y,M[1]=m[y]}p.sort(nm);for(let y=0;y<8;y++)y<_&&p[y][1]?(o[y][0]=p[y][0],o[y][1]=p[y][1]):(o[y][0]=Number.MAX_SAFE_INTEGER,o[y][1]=0);o.sort(tm);let f=u.morphAttributes.position,b=u.morphAttributes.normal,C=0;for(let y=0;y<8;y++){let M=o[y],N=M[0],k=M[1];N!==Number.MAX_SAFE_INTEGER&&k?(f&&u.getAttribute("morphTarget"+y)!==f[N]&&u.setAttribute("morphTarget"+y,f[N]),b&&u.getAttribute("morphNormal"+y)!==b[N]&&u.setAttribute("morphNormal"+y,b[N]),i[y]=k,C+=k):(f&&u.hasAttribute("morphTarget"+y)===!0&&u.deleteAttribute("morphTarget"+y),b&&u.hasAttribute("morphNormal"+y)===!0&&u.deleteAttribute("morphNormal"+y),i[y]=0)}let S=u.morphTargetsRelative?1:1-C;d.getUniforms().setValue(r,"morphTargetBaseInfluence",S),d.getUniforms().setValue(r,"morphTargetInfluences",i)}}return{update:c}}function sm(r,e,t,n){let i=new WeakMap;function s(c){let h=n.render.frame,u=c.geometry,l=e.get(c,u);return i.get(l)!==h&&(e.update(l),i.set(l,h)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),t.update(c.instanceMatrix,34962),c.instanceColor!==null&&t.update(c.instanceColor,34962)),l}function a(){i=new WeakMap}function o(c){let h=c.target;h.removeEventListener("dispose",o),t.remove(h.instanceMatrix),h.instanceColor!==null&&t.remove(h.instanceColor)}return{update:s,dispose:a}}var rh=new an,oh=new Qr,ah=new Ma,lh=new ro,wc=[],Sc=[],Tc=new Float32Array(16),Ac=new Float32Array(9),Ec=new Float32Array(4);function ws(r,e,t){let n=r[0];if(n<=0||n>0)return r;let i=e*t,s=wc[i];if(s===void 0&&(s=new Float32Array(i),wc[i]=s),e!==0){n.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,r[a].toArray(s,o)}return s}function Vt(r,e){if(r.length!==e.length)return!1;for(let t=0,n=r.length;t<n;t++)if(r[t]!==e[t])return!1;return!0}function Gt(r,e){for(let t=0,n=e.length;t<n;t++)r[t]=e[t]}function Mo(r,e){let t=Sc[e];t===void 0&&(t=new Int32Array(e),Sc[e]=t);for(let n=0;n!==e;++n)t[n]=r.allocateTextureUnit();return t}function rm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function om(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Vt(t,e))return;r.uniform2fv(this.addr,e),Gt(t,e)}}function am(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Vt(t,e))return;r.uniform3fv(this.addr,e),Gt(t,e)}}function lm(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Vt(t,e))return;r.uniform4fv(this.addr,e),Gt(t,e)}}function cm(r,e){let t=this.cache,n=e.elements;if(n===void 0){if(Vt(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),Gt(t,e)}else{if(Vt(t,n))return;Ec.set(n),r.uniformMatrix2fv(this.addr,!1,Ec),Gt(t,n)}}function hm(r,e){let t=this.cache,n=e.elements;if(n===void 0){if(Vt(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),Gt(t,e)}else{if(Vt(t,n))return;Ac.set(n),r.uniformMatrix3fv(this.addr,!1,Ac),Gt(t,n)}}function um(r,e){let t=this.cache,n=e.elements;if(n===void 0){if(Vt(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),Gt(t,e)}else{if(Vt(t,n))return;Tc.set(n),r.uniformMatrix4fv(this.addr,!1,Tc),Gt(t,n)}}function dm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function fm(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Vt(t,e))return;r.uniform2iv(this.addr,e),Gt(t,e)}}function pm(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Vt(t,e))return;r.uniform3iv(this.addr,e),Gt(t,e)}}function mm(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Vt(t,e))return;r.uniform4iv(this.addr,e),Gt(t,e)}}function gm(r,e){let t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function xm(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Vt(t,e))return;r.uniform2uiv(this.addr,e),Gt(t,e)}}function _m(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Vt(t,e))return;r.uniform3uiv(this.addr,e),Gt(t,e)}}function ym(r,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Vt(t,e))return;r.uniform4uiv(this.addr,e),Gt(t,e)}}function vm(r,e,t){let n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture2D(e||rh,i)}function bm(r,e,t){let n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture3D(e||ah,i)}function Mm(r,e,t){let n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTextureCube(e||lh,i)}function wm(r,e,t){let n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture2DArray(e||oh,i)}function Sm(r){switch(r){case 5126:return rm;case 35664:return om;case 35665:return am;case 35666:return lm;case 35674:return cm;case 35675:return hm;case 35676:return um;case 5124:case 35670:return dm;case 35667:case 35671:return fm;case 35668:case 35672:return pm;case 35669:case 35673:return mm;case 5125:return gm;case 36294:return xm;case 36295:return _m;case 36296:return ym;case 35678:case 36198:case 36298:case 36306:case 35682:return vm;case 35679:case 36299:case 36307:return bm;case 35680:case 36300:case 36308:case 36293:return Mm;case 36289:case 36303:case 36311:case 36292:return wm}}function Tm(r,e){r.uniform1fv(this.addr,e)}function Am(r,e){let t=ws(e,this.size,2);r.uniform2fv(this.addr,t)}function Em(r,e){let t=ws(e,this.size,3);r.uniform3fv(this.addr,t)}function Cm(r,e){let t=ws(e,this.size,4);r.uniform4fv(this.addr,t)}function Pm(r,e){let t=ws(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function Lm(r,e){let t=ws(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function Rm(r,e){let t=ws(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function Im(r,e){r.uniform1iv(this.addr,e)}function Dm(r,e){r.uniform2iv(this.addr,e)}function Nm(r,e){r.uniform3iv(this.addr,e)}function Om(r,e){r.uniform4iv(this.addr,e)}function zm(r,e){r.uniform1uiv(this.addr,e)}function Fm(r,e){r.uniform2uiv(this.addr,e)}function km(r,e){r.uniform3uiv(this.addr,e)}function Bm(r,e){r.uniform4uiv(this.addr,e)}function Um(r,e,t){let n=this.cache,i=e.length,s=Mo(t,i);Vt(n,s)||(r.uniform1iv(this.addr,s),Gt(n,s));for(let a=0;a!==i;++a)t.setTexture2D(e[a]||rh,s[a])}function Vm(r,e,t){let n=this.cache,i=e.length,s=Mo(t,i);Vt(n,s)||(r.uniform1iv(this.addr,s),Gt(n,s));for(let a=0;a!==i;++a)t.setTexture3D(e[a]||ah,s[a])}function Gm(r,e,t){let n=this.cache,i=e.length,s=Mo(t,i);Vt(n,s)||(r.uniform1iv(this.addr,s),Gt(n,s));for(let a=0;a!==i;++a)t.setTextureCube(e[a]||lh,s[a])}function Hm(r,e,t){let n=this.cache,i=e.length,s=Mo(t,i);Vt(n,s)||(r.uniform1iv(this.addr,s),Gt(n,s));for(let a=0;a!==i;++a)t.setTexture2DArray(e[a]||oh,s[a])}function Wm(r){switch(r){case 5126:return Tm;case 35664:return Am;case 35665:return Em;case 35666:return Cm;case 35674:return Pm;case 35675:return Lm;case 35676:return Rm;case 5124:case 35670:return Im;case 35667:case 35671:return Dm;case 35668:case 35672:return Nm;case 35669:case 35673:return Om;case 5125:return zm;case 36294:return Fm;case 36295:return km;case 36296:return Bm;case 35678:case 36198:case 36298:case 36306:case 35682:return Um;case 35679:case 36299:case 36307:return Vm;case 35680:case 36300:case 36308:case 36293:return Gm;case 36289:case 36303:case 36311:case 36292:return Hm}}var Ta=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.setValue=Sm(t.type)}},Aa=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.size=t.size,this.setValue=Wm(t.type)}},Ea=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let i=this.seq;for(let s=0,a=i.length;s!==a;++s){let o=i[s];o.setValue(e,t[o.id],n)}}},ha=/(\w+)(\])?(\[|\.)?/g;function Cc(r,e){r.seq.push(e),r.map[e.id]=e}function Xm(r,e,t){let n=r.name,i=n.length;for(ha.lastIndex=0;;){let s=ha.exec(n),a=ha.lastIndex,o=s[1],c=s[2]==="]",h=s[3];if(c&&(o=o|0),h===void 0||h==="["&&a+2===i){Cc(t,h===void 0?new Ta(o,r,e):new Aa(o,r,e));break}else{let l=t.map[o];l===void 0&&(l=new Ea(o),Cc(t,l)),t=l}}}var ds=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,35718);for(let i=0;i<n;++i){let s=e.getActiveUniform(t,i),a=e.getUniformLocation(t,s.name);Xm(s,a,this)}}setValue(e,t,n,i){let s=this.map[t];s!==void 0&&s.setValue(e,n,i)}setOptional(e,t,n){let i=t[n];i!==void 0&&this.setValue(e,n,i)}static upload(e,t,n,i){for(let s=0,a=t.length;s!==a;++s){let o=t[s],c=n[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,i)}}static seqWithValue(e,t){let n=[];for(let i=0,s=e.length;i!==s;++i){let a=e[i];a.id in t&&n.push(a)}return n}};function Pc(r,e,t){let n=r.createShader(e);return r.shaderSource(n,t),r.compileShader(n),n}var qm=0;function Ym(r,e){let t=r.split(`
`),n=[],i=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=i;a<s;a++){let o=a+1;n.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return n.join(`
`)}function Zm(r){switch(r){case Ri:return["Linear","( value )"];case _t:return["sRGB","( value )"];default:return console.warn("THREE.WebGLProgram: Unsupported encoding:",r),["Linear","( value )"]}}function Lc(r,e,t){let n=r.getShaderParameter(e,35713),i=r.getShaderInfoLog(e).trim();if(n&&i==="")return"";let s=/ERROR: 0:(\d+)/.exec(i);if(s){let a=parseInt(s[1]);return t.toUpperCase()+`

`+i+`

`+Ym(r.getShaderSource(e),a)}else return i}function Jm(r,e){let t=Zm(e);return"vec4 "+r+"( vec4 value ) { return LinearTo"+t[0]+t[1]+"; }"}function $m(r,e){let t;switch(e){case ou:t="Linear";break;case au:t="Reinhard";break;case lu:t="OptimizedCineon";break;case cu:t="ACESFilmic";break;case hu:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function Km(r){return[r.extensionDerivatives||r.envMapCubeUVHeight||r.bumpMap||r.tangentSpaceNormalMap||r.clearcoatNormalMap||r.flatShading||r.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(r.extensionFragDepth||r.logarithmicDepthBuffer)&&r.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",r.extensionDrawBuffers&&r.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(r.extensionShaderTextureLOD||r.envMap||r.transmission)&&r.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Us).join(`
`)}function jm(r){let e=[];for(let t in r){let n=r[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Qm(r,e){let t={},n=r.getProgramParameter(e,35721);for(let i=0;i<n;i++){let s=r.getActiveAttrib(e,i),a=s.name,o=1;s.type===35674&&(o=2),s.type===35675&&(o=3),s.type===35676&&(o=4),t[a]={type:s.type,location:r.getAttribLocation(e,a),locationSize:o}}return t}function Us(r){return r!==""}function Rc(r,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ic(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var eg=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ca(r){return r.replace(eg,tg)}function tg(r,e){let t=nt[e];if(t===void 0)throw new Error("Can not resolve #include <"+e+">");return Ca(t)}var ng=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Dc(r){return r.replace(ng,ig)}function ig(r,e,t,n){let i="";for(let s=parseInt(e);s<parseInt(t);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function Nc(r){let e="precision "+r.precision+` float;
precision `+r.precision+" int;";return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function sg(r){let e="SHADOWMAP_TYPE_BASIC";return r.shadowMapType===yo?e="SHADOWMAP_TYPE_PCF":r.shadowMapType===kh?e="SHADOWMAP_TYPE_PCF_SOFT":r.shadowMapType===Bs&&(e="SHADOWMAP_TYPE_VSM"),e}function rg(r){let e="ENVMAP_TYPE_CUBE";if(r.envMap)switch(r.envMapMode){case ps:case ms:e="ENVMAP_TYPE_CUBE";break;case vo:e="ENVMAP_TYPE_CUBE_UV";break}return e}function og(r){let e="ENVMAP_MODE_REFLECTION";if(r.envMap)switch(r.envMapMode){case ms:e="ENVMAP_MODE_REFRACTION";break}return e}function ag(r){let e="ENVMAP_BLENDING_NONE";if(r.envMap)switch(r.combine){case Kc:e="ENVMAP_BLENDING_MULTIPLY";break;case su:e="ENVMAP_BLENDING_MIX";break;case ru:e="ENVMAP_BLENDING_ADD";break}return e}function lg(r){let e=r.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function cg(r,e,t,n){let i=r.getContext(),s=t.defines,a=t.vertexShader,o=t.fragmentShader,c=sg(t),h=rg(t),u=og(t),l=ag(t),d=lg(t),m=t.isWebGL2?"":Km(t),_=jm(s),p=i.createProgram(),f,b,C=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=[_].filter(Us).join(`
`),f.length>0&&(f+=`
`),b=[m,_].filter(Us).join(`
`),b.length>0&&(b+=`
`)):(f=[Nc(t),"#define SHADER_NAME "+t.shaderName,_,t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.supportsVertexTextures?"#define VERTEX_TEXTURES":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMap&&t.objectSpaceNormalMap?"#define OBJECTSPACE_NORMALMAP":"",t.normalMap&&t.tangentSpaceNormalMap?"#define TANGENTSPACE_NORMALMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.displacementMap&&t.supportsVertexTextures?"#define USE_DISPLACEMENTMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularIntensityMap?"#define USE_SPECULARINTENSITYMAP":"",t.specularColorMap?"#define USE_SPECULARCOLORMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEENCOLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEENROUGHNESSMAP":"",t.vertexTangents?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUvs?"#define USE_UV":"",t.uvsVertexOnly?"#define UVS_VERTEX_ONLY":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Us).join(`
`),b=[m,Nc(t),"#define SHADER_NAME "+t.shaderName,_,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",t.envMap?"#define "+l:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMap&&t.objectSpaceNormalMap?"#define OBJECTSPACE_NORMALMAP":"",t.normalMap&&t.tangentSpaceNormalMap?"#define TANGENTSPACE_NORMALMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularIntensityMap?"#define USE_SPECULARINTENSITYMAP":"",t.specularColorMap?"#define USE_SPECULARCOLORMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEENCOLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEENROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.vertexTangents?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUvs?"#define USE_UV":"",t.uvsVertexOnly?"#define UVS_VERTEX_ONLY":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.physicallyCorrectLights?"#define PHYSICALLY_CORRECT_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Qn?"#define TONE_MAPPING":"",t.toneMapping!==Qn?nt.tonemapping_pars_fragment:"",t.toneMapping!==Qn?$m("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",nt.encodings_pars_fragment,Jm("linearToOutputTexel",t.outputEncoding),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Us).join(`
`)),a=Ca(a),a=Rc(a,t),a=Ic(a,t),o=Ca(o),o=Rc(o,t),o=Ic(o,t),a=Dc(a),o=Dc(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(C=`#version 300 es
`,f=["precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,b=["#define varying in",t.glslVersion===rc?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===rc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+b);let S=C+f+a,y=C+b+o,M=Pc(i,35633,S),N=Pc(i,35632,y);if(i.attachShader(p,M),i.attachShader(p,N),t.index0AttributeName!==void 0?i.bindAttribLocation(p,0,t.index0AttributeName):t.morphTargets===!0&&i.bindAttribLocation(p,0,"position"),i.linkProgram(p),r.debug.checkShaderErrors){let P=i.getProgramInfoLog(p).trim(),z=i.getShaderInfoLog(M).trim(),Y=i.getShaderInfoLog(N).trim(),ie=!0,q=!0;if(i.getProgramParameter(p,35714)===!1){ie=!1;let B=Lc(i,M,"vertex"),K=Lc(i,N,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(p,35715)+`

Program Info Log: `+P+`
`+B+`
`+K)}else P!==""?console.warn("THREE.WebGLProgram: Program Info Log:",P):(z===""||Y==="")&&(q=!1);q&&(this.diagnostics={runnable:ie,programLog:P,vertexShader:{log:z,prefix:f},fragmentShader:{log:Y,prefix:b}})}i.deleteShader(M),i.deleteShader(N);let k;this.getUniforms=function(){return k===void 0&&(k=new ds(i,p)),k};let x;return this.getAttributes=function(){return x===void 0&&(x=Qm(i,p)),x},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(p),this.program=void 0},this.name=t.shaderName,this.id=qm++,this.cacheKey=e,this.usedTimes=1,this.program=p,this.vertexShader=M,this.fragmentShader=N,this}var hg=0,Pa=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,n=e.fragmentShader,i=this._getShaderStage(t),s=this._getShaderStage(n),a=this._getShaderCacheForMaterial(e);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new La(e),t.set(e,n)),n}},La=class{constructor(e){this.id=hg++,this.code=e,this.usedTimes=0}};function ug(r,e,t,n,i,s,a){let o=new to,c=new Pa,h=[],u=i.isWebGL2,l=i.logarithmicDepthBuffer,d=i.vertexTextures,m=i.precision,_={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(x,P,z,Y,ie){let q=Y.fog,B=ie.geometry,K=x.isMeshStandardMaterial?Y.environment:null,re=(x.isMeshStandardMaterial?t:e).get(x.envMap||K),ue=re&&re.mapping===vo?re.image.height:null,Z=_[x.type];x.precision!==null&&(m=i.getMaxPrecision(x.precision),m!==x.precision&&console.warn("THREE.WebGLProgram.getParameters:",x.precision,"not supported, using",m,"instead."));let me=B.morphAttributes.position||B.morphAttributes.normal||B.morphAttributes.color,ae=me!==void 0?me.length:0,ee=0;B.morphAttributes.position!==void 0&&(ee=1),B.morphAttributes.normal!==void 0&&(ee=2),B.morphAttributes.color!==void 0&&(ee=3);let $,_e,pe,ve;if(Z){let ft=Vn[Z];$=ft.vertexShader,_e=ft.fragmentShader}else $=x.vertexShader,_e=x.fragmentShader,c.update(x),pe=c.getVertexShaderID(x),ve=c.getFragmentShaderID(x);let te=r.getRenderTarget(),Ze=x.alphaTest>0,Re=x.clearcoat>0,Be=x.iridescence>0;return{isWebGL2:u,shaderID:Z,shaderName:x.type,vertexShader:$,fragmentShader:_e,defines:x.defines,customVertexShaderID:pe,customFragmentShaderID:ve,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:m,instancing:ie.isInstancedMesh===!0,instancingColor:ie.isInstancedMesh===!0&&ie.instanceColor!==null,supportsVertexTextures:d,outputEncoding:te===null?r.outputEncoding:te.isXRRenderTarget===!0?te.texture.encoding:Ri,map:!!x.map,matcap:!!x.matcap,envMap:!!re,envMapMode:re&&re.mapping,envMapCubeUVHeight:ue,lightMap:!!x.lightMap,aoMap:!!x.aoMap,emissiveMap:!!x.emissiveMap,bumpMap:!!x.bumpMap,normalMap:!!x.normalMap,objectSpaceNormalMap:x.normalMapType===Pu,tangentSpaceNormalMap:x.normalMapType===eh,decodeVideoTexture:!!x.map&&x.map.isVideoTexture===!0&&x.map.encoding===_t,clearcoat:Re,clearcoatMap:Re&&!!x.clearcoatMap,clearcoatRoughnessMap:Re&&!!x.clearcoatRoughnessMap,clearcoatNormalMap:Re&&!!x.clearcoatNormalMap,iridescence:Be,iridescenceMap:Be&&!!x.iridescenceMap,iridescenceThicknessMap:Be&&!!x.iridescenceThicknessMap,displacementMap:!!x.displacementMap,roughnessMap:!!x.roughnessMap,metalnessMap:!!x.metalnessMap,specularMap:!!x.specularMap,specularIntensityMap:!!x.specularIntensityMap,specularColorMap:!!x.specularColorMap,opaque:x.transparent===!1&&x.blending===cs,alphaMap:!!x.alphaMap,alphaTest:Ze,gradientMap:!!x.gradientMap,sheen:x.sheen>0,sheenColorMap:!!x.sheenColorMap,sheenRoughnessMap:!!x.sheenRoughnessMap,transmission:x.transmission>0,transmissionMap:!!x.transmissionMap,thicknessMap:!!x.thicknessMap,combine:x.combine,vertexTangents:!!x.normalMap&&!!B.attributes.tangent,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!B.attributes.color&&B.attributes.color.itemSize===4,vertexUvs:!!x.map||!!x.bumpMap||!!x.normalMap||!!x.specularMap||!!x.alphaMap||!!x.emissiveMap||!!x.roughnessMap||!!x.metalnessMap||!!x.clearcoatMap||!!x.clearcoatRoughnessMap||!!x.clearcoatNormalMap||!!x.iridescenceMap||!!x.iridescenceThicknessMap||!!x.displacementMap||!!x.transmissionMap||!!x.thicknessMap||!!x.specularIntensityMap||!!x.specularColorMap||!!x.sheenColorMap||!!x.sheenRoughnessMap,uvsVertexOnly:!(x.map||x.bumpMap||x.normalMap||x.specularMap||x.alphaMap||x.emissiveMap||x.roughnessMap||x.metalnessMap||x.clearcoatNormalMap||x.iridescenceMap||x.iridescenceThicknessMap||x.transmission>0||x.transmissionMap||x.thicknessMap||x.specularIntensityMap||x.specularColorMap||x.sheen>0||x.sheenColorMap||x.sheenRoughnessMap)&&!!x.displacementMap,fog:!!q,useFog:x.fog===!0,fogExp2:q&&q.isFogExp2,flatShading:!!x.flatShading,sizeAttenuation:x.sizeAttenuation,logarithmicDepthBuffer:l,skinning:ie.isSkinnedMesh===!0,morphTargets:B.morphAttributes.position!==void 0,morphNormals:B.morphAttributes.normal!==void 0,morphColors:B.morphAttributes.color!==void 0,morphTargetsCount:ae,morphTextureStride:ee,numDirLights:P.directional.length,numPointLights:P.point.length,numSpotLights:P.spot.length,numSpotLightMaps:P.spotLightMap.length,numRectAreaLights:P.rectArea.length,numHemiLights:P.hemi.length,numDirLightShadows:P.directionalShadowMap.length,numPointLightShadows:P.pointShadowMap.length,numSpotLightShadows:P.spotShadowMap.length,numSpotLightShadowsWithMaps:P.numSpotLightShadowsWithMaps,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:x.dithering,shadowMapEnabled:r.shadowMap.enabled&&z.length>0,shadowMapType:r.shadowMap.type,toneMapping:x.toneMapped?r.toneMapping:Qn,physicallyCorrectLights:r.physicallyCorrectLights,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===fn,flipSided:x.side===An,useDepthPacking:!!x.depthPacking,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionDerivatives:x.extensions&&x.extensions.derivatives,extensionFragDepth:x.extensions&&x.extensions.fragDepth,extensionDrawBuffers:x.extensions&&x.extensions.drawBuffers,extensionShaderTextureLOD:x.extensions&&x.extensions.shaderTextureLOD,rendererExtensionFragDepth:u||n.has("EXT_frag_depth"),rendererExtensionDrawBuffers:u||n.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:u||n.has("EXT_shader_texture_lod"),customProgramCacheKey:x.customProgramCacheKey()}}function f(x){let P=[];if(x.shaderID?P.push(x.shaderID):(P.push(x.customVertexShaderID),P.push(x.customFragmentShaderID)),x.defines!==void 0)for(let z in x.defines)P.push(z),P.push(x.defines[z]);return x.isRawShaderMaterial===!1&&(b(P,x),C(P,x),P.push(r.outputEncoding)),P.push(x.customProgramCacheKey),P.join()}function b(x,P){x.push(P.precision),x.push(P.outputEncoding),x.push(P.envMapMode),x.push(P.envMapCubeUVHeight),x.push(P.combine),x.push(P.vertexUvs),x.push(P.fogExp2),x.push(P.sizeAttenuation),x.push(P.morphTargetsCount),x.push(P.morphAttributeCount),x.push(P.numDirLights),x.push(P.numPointLights),x.push(P.numSpotLights),x.push(P.numSpotLightMaps),x.push(P.numHemiLights),x.push(P.numRectAreaLights),x.push(P.numDirLightShadows),x.push(P.numPointLightShadows),x.push(P.numSpotLightShadows),x.push(P.numSpotLightShadowsWithMaps),x.push(P.shadowMapType),x.push(P.toneMapping),x.push(P.numClippingPlanes),x.push(P.numClipIntersection),x.push(P.depthPacking)}function C(x,P){o.disableAll(),P.isWebGL2&&o.enable(0),P.supportsVertexTextures&&o.enable(1),P.instancing&&o.enable(2),P.instancingColor&&o.enable(3),P.map&&o.enable(4),P.matcap&&o.enable(5),P.envMap&&o.enable(6),P.lightMap&&o.enable(7),P.aoMap&&o.enable(8),P.emissiveMap&&o.enable(9),P.bumpMap&&o.enable(10),P.normalMap&&o.enable(11),P.objectSpaceNormalMap&&o.enable(12),P.tangentSpaceNormalMap&&o.enable(13),P.clearcoat&&o.enable(14),P.clearcoatMap&&o.enable(15),P.clearcoatRoughnessMap&&o.enable(16),P.clearcoatNormalMap&&o.enable(17),P.iridescence&&o.enable(18),P.iridescenceMap&&o.enable(19),P.iridescenceThicknessMap&&o.enable(20),P.displacementMap&&o.enable(21),P.specularMap&&o.enable(22),P.roughnessMap&&o.enable(23),P.metalnessMap&&o.enable(24),P.gradientMap&&o.enable(25),P.alphaMap&&o.enable(26),P.alphaTest&&o.enable(27),P.vertexColors&&o.enable(28),P.vertexAlphas&&o.enable(29),P.vertexUvs&&o.enable(30),P.vertexTangents&&o.enable(31),P.uvsVertexOnly&&o.enable(32),x.push(o.mask),o.disableAll(),P.fog&&o.enable(0),P.useFog&&o.enable(1),P.flatShading&&o.enable(2),P.logarithmicDepthBuffer&&o.enable(3),P.skinning&&o.enable(4),P.morphTargets&&o.enable(5),P.morphNormals&&o.enable(6),P.morphColors&&o.enable(7),P.premultipliedAlpha&&o.enable(8),P.shadowMapEnabled&&o.enable(9),P.physicallyCorrectLights&&o.enable(10),P.doubleSided&&o.enable(11),P.flipSided&&o.enable(12),P.useDepthPacking&&o.enable(13),P.dithering&&o.enable(14),P.specularIntensityMap&&o.enable(15),P.specularColorMap&&o.enable(16),P.transmission&&o.enable(17),P.transmissionMap&&o.enable(18),P.thicknessMap&&o.enable(19),P.sheen&&o.enable(20),P.sheenColorMap&&o.enable(21),P.sheenRoughnessMap&&o.enable(22),P.decodeVideoTexture&&o.enable(23),P.opaque&&o.enable(24),x.push(o.mask)}function S(x){let P=_[x.type],z;if(P){let Y=Vn[P];z=id.clone(Y.uniforms)}else z=x.uniforms;return z}function y(x,P){let z;for(let Y=0,ie=h.length;Y<ie;Y++){let q=h[Y];if(q.cacheKey===P){z=q,++z.usedTimes;break}}return z===void 0&&(z=new cg(r,P,x,s),h.push(z)),z}function M(x){if(--x.usedTimes===0){let P=h.indexOf(x);h[P]=h[h.length-1],h.pop(),x.destroy()}}function N(x){c.remove(x)}function k(){c.dispose()}return{getParameters:p,getProgramCacheKey:f,getUniforms:S,acquireProgram:y,releaseProgram:M,releaseShaderCache:N,programs:h,dispose:k}}function dg(){let r=new WeakMap;function e(s){let a=r.get(s);return a===void 0&&(a={},r.set(s,a)),a}function t(s){r.delete(s)}function n(s,a,o){r.get(s)[a]=o}function i(){r=new WeakMap}return{get:e,remove:t,update:n,dispose:i}}function fg(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function Oc(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function zc(){let r=[],e=0,t=[],n=[],i=[];function s(){e=0,t.length=0,n.length=0,i.length=0}function a(l,d,m,_,p,f){let b=r[e];return b===void 0?(b={id:l.id,object:l,geometry:d,material:m,groupOrder:_,renderOrder:l.renderOrder,z:p,group:f},r[e]=b):(b.id=l.id,b.object=l,b.geometry=d,b.material=m,b.groupOrder=_,b.renderOrder=l.renderOrder,b.z=p,b.group=f),e++,b}function o(l,d,m,_,p,f){let b=a(l,d,m,_,p,f);m.transmission>0?n.push(b):m.transparent===!0?i.push(b):t.push(b)}function c(l,d,m,_,p,f){let b=a(l,d,m,_,p,f);m.transmission>0?n.unshift(b):m.transparent===!0?i.unshift(b):t.unshift(b)}function h(l,d){t.length>1&&t.sort(l||fg),n.length>1&&n.sort(d||Oc),i.length>1&&i.sort(d||Oc)}function u(){for(let l=e,d=r.length;l<d;l++){let m=r[l];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:n,transparent:i,init:s,push:o,unshift:c,finish:u,sort:h}}function pg(){let r=new WeakMap;function e(n,i){let s=r.get(n),a;return s===void 0?(a=new zc,r.set(n,[a])):i>=s.length?(a=new zc,s.push(a)):a=s[i],a}function t(){r=new WeakMap}return{get:e,dispose:t}}function mg(){let r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new R,color:new pt};break;case"SpotLight":t={position:new R,direction:new R,color:new pt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new R,color:new pt,distance:0,decay:0};break;case"HemisphereLight":t={direction:new R,skyColor:new pt,groundColor:new pt};break;case"RectAreaLight":t={color:new pt,position:new R,halfWidth:new R,halfHeight:new R};break}return r[e.id]=t,t}}}function gg(){let r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ve};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ve};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ve,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=t,t}}}var xg=0;function _g(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function yg(r,e){let t=new mg,n=gg(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0};for(let u=0;u<9;u++)i.probe.push(new R);let s=new R,a=new Tt,o=new Tt;function c(u,l){let d=0,m=0,_=0;for(let Y=0;Y<9;Y++)i.probe[Y].set(0,0,0);let p=0,f=0,b=0,C=0,S=0,y=0,M=0,N=0,k=0,x=0;u.sort(_g);let P=l!==!0?Math.PI:1;for(let Y=0,ie=u.length;Y<ie;Y++){let q=u[Y],B=q.color,K=q.intensity,re=q.distance,ue=q.shadow&&q.shadow.map?q.shadow.map.texture:null;if(q.isAmbientLight)d+=B.r*K*P,m+=B.g*K*P,_+=B.b*K*P;else if(q.isLightProbe)for(let Z=0;Z<9;Z++)i.probe[Z].addScaledVector(q.sh.coefficients[Z],K);else if(q.isDirectionalLight){let Z=t.get(q);if(Z.color.copy(q.color).multiplyScalar(q.intensity*P),q.castShadow){let me=q.shadow,ae=n.get(q);ae.shadowBias=me.bias,ae.shadowNormalBias=me.normalBias,ae.shadowRadius=me.radius,ae.shadowMapSize=me.mapSize,i.directionalShadow[p]=ae,i.directionalShadowMap[p]=ue,i.directionalShadowMatrix[p]=q.shadow.matrix,y++}i.directional[p]=Z,p++}else if(q.isSpotLight){let Z=t.get(q);Z.position.setFromMatrixPosition(q.matrixWorld),Z.color.copy(B).multiplyScalar(K*P),Z.distance=re,Z.coneCos=Math.cos(q.angle),Z.penumbraCos=Math.cos(q.angle*(1-q.penumbra)),Z.decay=q.decay,i.spot[b]=Z;let me=q.shadow;if(q.map&&(i.spotLightMap[k]=q.map,k++,me.updateMatrices(q),q.castShadow&&x++),i.spotLightMatrix[b]=me.matrix,q.castShadow){let ae=n.get(q);ae.shadowBias=me.bias,ae.shadowNormalBias=me.normalBias,ae.shadowRadius=me.radius,ae.shadowMapSize=me.mapSize,i.spotShadow[b]=ae,i.spotShadowMap[b]=ue,N++}b++}else if(q.isRectAreaLight){let Z=t.get(q);Z.color.copy(B).multiplyScalar(K),Z.halfWidth.set(q.width*.5,0,0),Z.halfHeight.set(0,q.height*.5,0),i.rectArea[C]=Z,C++}else if(q.isPointLight){let Z=t.get(q);if(Z.color.copy(q.color).multiplyScalar(q.intensity*P),Z.distance=q.distance,Z.decay=q.decay,q.castShadow){let me=q.shadow,ae=n.get(q);ae.shadowBias=me.bias,ae.shadowNormalBias=me.normalBias,ae.shadowRadius=me.radius,ae.shadowMapSize=me.mapSize,ae.shadowCameraNear=me.camera.near,ae.shadowCameraFar=me.camera.far,i.pointShadow[f]=ae,i.pointShadowMap[f]=ue,i.pointShadowMatrix[f]=q.shadow.matrix,M++}i.point[f]=Z,f++}else if(q.isHemisphereLight){let Z=t.get(q);Z.skyColor.copy(q.color).multiplyScalar(K*P),Z.groundColor.copy(q.groundColor).multiplyScalar(K*P),i.hemi[S]=Z,S++}}C>0&&(e.isWebGL2||r.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=ye.LTC_FLOAT_1,i.rectAreaLTC2=ye.LTC_FLOAT_2):r.has("OES_texture_half_float_linear")===!0?(i.rectAreaLTC1=ye.LTC_HALF_1,i.rectAreaLTC2=ye.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),i.ambient[0]=d,i.ambient[1]=m,i.ambient[2]=_;let z=i.hash;(z.directionalLength!==p||z.pointLength!==f||z.spotLength!==b||z.rectAreaLength!==C||z.hemiLength!==S||z.numDirectionalShadows!==y||z.numPointShadows!==M||z.numSpotShadows!==N||z.numSpotMaps!==k)&&(i.directional.length=p,i.spot.length=b,i.rectArea.length=C,i.point.length=f,i.hemi.length=S,i.directionalShadow.length=y,i.directionalShadowMap.length=y,i.pointShadow.length=M,i.pointShadowMap.length=M,i.spotShadow.length=N,i.spotShadowMap.length=N,i.directionalShadowMatrix.length=y,i.pointShadowMatrix.length=M,i.spotLightMatrix.length=N+k-x,i.spotLightMap.length=k,i.numSpotLightShadowsWithMaps=x,z.directionalLength=p,z.pointLength=f,z.spotLength=b,z.rectAreaLength=C,z.hemiLength=S,z.numDirectionalShadows=y,z.numPointShadows=M,z.numSpotShadows=N,z.numSpotMaps=k,i.version=xg++)}function h(u,l){let d=0,m=0,_=0,p=0,f=0,b=l.matrixWorldInverse;for(let C=0,S=u.length;C<S;C++){let y=u[C];if(y.isDirectionalLight){let M=i.directional[d];M.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),M.direction.sub(s),M.direction.transformDirection(b),d++}else if(y.isSpotLight){let M=i.spot[_];M.position.setFromMatrixPosition(y.matrixWorld),M.position.applyMatrix4(b),M.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),M.direction.sub(s),M.direction.transformDirection(b),_++}else if(y.isRectAreaLight){let M=i.rectArea[p];M.position.setFromMatrixPosition(y.matrixWorld),M.position.applyMatrix4(b),o.identity(),a.copy(y.matrixWorld),a.premultiply(b),o.extractRotation(a),M.halfWidth.set(y.width*.5,0,0),M.halfHeight.set(0,y.height*.5,0),M.halfWidth.applyMatrix4(o),M.halfHeight.applyMatrix4(o),p++}else if(y.isPointLight){let M=i.point[m];M.position.setFromMatrixPosition(y.matrixWorld),M.position.applyMatrix4(b),m++}else if(y.isHemisphereLight){let M=i.hemi[f];M.direction.setFromMatrixPosition(y.matrixWorld),M.direction.transformDirection(b),f++}}}return{setup:c,setupView:h,state:i}}function Fc(r,e){let t=new yg(r,e),n=[],i=[];function s(){n.length=0,i.length=0}function a(l){n.push(l)}function o(l){i.push(l)}function c(l){t.setup(n,l)}function h(l){t.setupView(n,l)}return{init:s,state:{lightsArray:n,shadowsArray:i,lights:t},setupLights:c,setupLightsView:h,pushLight:a,pushShadow:o}}function vg(r,e){let t=new WeakMap;function n(s,a=0){let o=t.get(s),c;return o===void 0?(c=new Fc(r,e),t.set(s,[c])):a>=o.length?(c=new Fc(r,e),o.push(c)):c=o[a],c}function i(){t=new WeakMap}return{get:n,dispose:i}}var Ra=class extends ni{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Eu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Ia=class extends ni{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.referencePosition=new R,this.nearDistance=1,this.farDistance=1e3,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.referencePosition.copy(e.referencePosition),this.nearDistance=e.nearDistance,this.farDistance=e.farDistance,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},bg=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Mg=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function wg(r,e,t){let n=new Zs,i=new Ve,s=new Ve,a=new Xt,o=new Ra({depthPacking:Cu}),c=new Ia,h={},u=t.maxTextureSize,l={0:An,1:fs,2:fn},d=new si({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ve},radius:{value:4}},vertexShader:bg,fragmentShader:Mg}),m=d.clone();m.defines.HORIZONTAL_PASS=1;let _=new zt;_.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let p=new ut(_,d),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=yo,this.render=function(y,M,N){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||y.length===0)return;let k=r.getRenderTarget(),x=r.getActiveCubeFace(),P=r.getActiveMipmapLevel(),z=r.state;z.setBlending(gi),z.buffers.color.setClear(1,1,1,1),z.buffers.depth.setTest(!0),z.setScissorTest(!1);for(let Y=0,ie=y.length;Y<ie;Y++){let q=y[Y],B=q.shadow;if(B===void 0){console.warn("THREE.WebGLShadowMap:",q,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;i.copy(B.mapSize);let K=B.getFrameExtents();if(i.multiply(K),s.copy(B.mapSize),(i.x>u||i.y>u)&&(i.x>u&&(s.x=Math.floor(u/K.x),i.x=s.x*K.x,B.mapSize.x=s.x),i.y>u&&(s.y=Math.floor(u/K.y),i.y=s.y*K.y,B.mapSize.y=s.y)),B.map===null){let ue=this.type!==Bs?{minFilter:dn,magFilter:dn}:{};B.map=new ti(i.x,i.y,ue),B.map.texture.name=q.name+".shadowMap",B.camera.updateProjectionMatrix()}r.setRenderTarget(B.map),r.clear();let re=B.getViewportCount();for(let ue=0;ue<re;ue++){let Z=B.getViewport(ue);a.set(s.x*Z.x,s.y*Z.y,s.x*Z.z,s.y*Z.w),z.viewport(a),B.updateMatrices(q,ue),n=B.getFrustum(),S(M,N,B.camera,q,this.type)}B.isPointLightShadow!==!0&&this.type===Bs&&b(B,N),B.needsUpdate=!1}f.needsUpdate=!1,r.setRenderTarget(k,x,P)};function b(y,M){let N=e.update(p);d.defines.VSM_SAMPLES!==y.blurSamples&&(d.defines.VSM_SAMPLES=y.blurSamples,m.defines.VSM_SAMPLES=y.blurSamples,d.needsUpdate=!0,m.needsUpdate=!0),y.mapPass===null&&(y.mapPass=new ti(i.x,i.y)),d.uniforms.shadow_pass.value=y.map.texture,d.uniforms.resolution.value=y.mapSize,d.uniforms.radius.value=y.radius,r.setRenderTarget(y.mapPass),r.clear(),r.renderBufferDirect(M,null,N,d,p,null),m.uniforms.shadow_pass.value=y.mapPass.texture,m.uniforms.resolution.value=y.mapSize,m.uniforms.radius.value=y.radius,r.setRenderTarget(y.map),r.clear(),r.renderBufferDirect(M,null,N,m,p,null)}function C(y,M,N,k,x,P){let z=null,Y=N.isPointLight===!0?y.customDistanceMaterial:y.customDepthMaterial;if(Y!==void 0?z=Y:z=N.isPointLight===!0?c:o,r.localClippingEnabled&&M.clipShadows===!0&&Array.isArray(M.clippingPlanes)&&M.clippingPlanes.length!==0||M.displacementMap&&M.displacementScale!==0||M.alphaMap&&M.alphaTest>0||M.map&&M.alphaTest>0){let ie=z.uuid,q=M.uuid,B=h[ie];B===void 0&&(B={},h[ie]=B);let K=B[q];K===void 0&&(K=z.clone(),B[q]=K),z=K}return z.visible=M.visible,z.wireframe=M.wireframe,P===Bs?z.side=M.shadowSide!==null?M.shadowSide:M.side:z.side=M.shadowSide!==null?M.shadowSide:l[M.side],z.alphaMap=M.alphaMap,z.alphaTest=M.alphaTest,z.map=M.map,z.clipShadows=M.clipShadows,z.clippingPlanes=M.clippingPlanes,z.clipIntersection=M.clipIntersection,z.displacementMap=M.displacementMap,z.displacementScale=M.displacementScale,z.displacementBias=M.displacementBias,z.wireframeLinewidth=M.wireframeLinewidth,z.linewidth=M.linewidth,N.isPointLight===!0&&z.isMeshDistanceMaterial===!0&&(z.referencePosition.setFromMatrixPosition(N.matrixWorld),z.nearDistance=k,z.farDistance=x),z}function S(y,M,N,k,x){if(y.visible===!1)return;if(y.layers.test(M.layers)&&(y.isMesh||y.isLine||y.isPoints)&&(y.castShadow||y.receiveShadow&&x===Bs)&&(!y.frustumCulled||n.intersectsObject(y))){y.modelViewMatrix.multiplyMatrices(N.matrixWorldInverse,y.matrixWorld);let Y=e.update(y),ie=y.material;if(Array.isArray(ie)){let q=Y.groups;for(let B=0,K=q.length;B<K;B++){let re=q[B],ue=ie[re.materialIndex];if(ue&&ue.visible){let Z=C(y,ue,k,N.near,N.far,x);r.renderBufferDirect(N,null,Y,Z,y,re)}}}else if(ie.visible){let q=C(y,ie,k,N.near,N.far,x);r.renderBufferDirect(N,null,Y,q,y,null)}}let z=y.children;for(let Y=0,ie=z.length;Y<ie;Y++)S(z[Y],M,N,k,x)}}function Sg(r,e,t){let n=t.isWebGL2;function i(){let F=!1,J=new Xt,de=null,Te=new Xt(0,0,0,0);return{setMask:function(Ne){de!==Ne&&!F&&(r.colorMask(Ne,Ne,Ne,Ne),de=Ne)},setLocked:function(Ne){F=Ne},setClear:function(Ne,ot,Nt,Ht,Hn){Hn===!0&&(Ne*=Ht,ot*=Ht,Nt*=Ht),J.set(Ne,ot,Nt,Ht),Te.equals(J)===!1&&(r.clearColor(Ne,ot,Nt,Ht),Te.copy(J))},reset:function(){F=!1,de=null,Te.set(-1,0,0,0)}}}function s(){let F=!1,J=null,de=null,Te=null;return{setTest:function(Ne){Ne?Ze(2929):Re(2929)},setMask:function(Ne){J!==Ne&&!F&&(r.depthMask(Ne),J=Ne)},setFunc:function(Ne){if(de!==Ne){switch(Ne){case Kh:r.depthFunc(512);break;case jh:r.depthFunc(519);break;case Qh:r.depthFunc(513);break;case pa:r.depthFunc(515);break;case eu:r.depthFunc(514);break;case tu:r.depthFunc(518);break;case nu:r.depthFunc(516);break;case iu:r.depthFunc(517);break;default:r.depthFunc(515)}de=Ne}},setLocked:function(Ne){F=Ne},setClear:function(Ne){Te!==Ne&&(r.clearDepth(Ne),Te=Ne)},reset:function(){F=!1,J=null,de=null,Te=null}}}function a(){let F=!1,J=null,de=null,Te=null,Ne=null,ot=null,Nt=null,Ht=null,Hn=null;return{setTest:function(it){F||(it?Ze(2960):Re(2960))},setMask:function(it){J!==it&&!F&&(r.stencilMask(it),J=it)},setFunc:function(it,Mn,pn){(de!==it||Te!==Mn||Ne!==pn)&&(r.stencilFunc(it,Mn,pn),de=it,Te=Mn,Ne=pn)},setOp:function(it,Mn,pn){(ot!==it||Nt!==Mn||Ht!==pn)&&(r.stencilOp(it,Mn,pn),ot=it,Nt=Mn,Ht=pn)},setLocked:function(it){F=it},setClear:function(it){Hn!==it&&(r.clearStencil(it),Hn=it)},reset:function(){F=!1,J=null,de=null,Te=null,Ne=null,ot=null,Nt=null,Ht=null,Hn=null}}}let o=new i,c=new s,h=new a,u=new WeakMap,l=new WeakMap,d={},m={},_=new WeakMap,p=[],f=null,b=!1,C=null,S=null,y=null,M=null,N=null,k=null,x=null,P=!1,z=null,Y=null,ie=null,q=null,B=null,K=r.getParameter(35661),re=!1,ue=0,Z=r.getParameter(7938);Z.indexOf("WebGL")!==-1?(ue=parseFloat(/^WebGL (\d)/.exec(Z)[1]),re=ue>=1):Z.indexOf("OpenGL ES")!==-1&&(ue=parseFloat(/^OpenGL ES (\d)/.exec(Z)[1]),re=ue>=2);let me=null,ae={},ee=r.getParameter(3088),$=r.getParameter(2978),_e=new Xt().fromArray(ee),pe=new Xt().fromArray($);function ve(F,J,de){let Te=new Uint8Array(4),Ne=r.createTexture();r.bindTexture(F,Ne),r.texParameteri(F,10241,9728),r.texParameteri(F,10240,9728);for(let ot=0;ot<de;ot++)r.texImage2D(J+ot,0,6408,1,1,0,6408,5121,Te);return Ne}let te={};te[3553]=ve(3553,3553,1),te[34067]=ve(34067,34069,6),o.setClear(0,0,0,1),c.setClear(1),h.setClear(0),Ze(2929),c.setFunc(pa),Pt(!1),qt(El),Ze(2884),Dt(gi);function Ze(F){d[F]!==!0&&(r.enable(F),d[F]=!0)}function Re(F){d[F]!==!1&&(r.disable(F),d[F]=!1)}function Be(F,J){return m[F]!==J?(r.bindFramebuffer(F,J),m[F]=J,n&&(F===36009&&(m[36160]=J),F===36160&&(m[36009]=J)),!0):!1}function Pe(F,J){let de=p,Te=!1;if(F)if(de=_.get(J),de===void 0&&(de=[],_.set(J,de)),F.isWebGLMultipleRenderTargets){let Ne=F.texture;if(de.length!==Ne.length||de[0]!==36064){for(let ot=0,Nt=Ne.length;ot<Nt;ot++)de[ot]=36064+ot;de.length=Ne.length,Te=!0}}else de[0]!==36064&&(de[0]=36064,Te=!0);else de[0]!==1029&&(de[0]=1029,Te=!0);Te&&(t.isWebGL2?r.drawBuffers(de):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(de))}function ft(F){return f!==F?(r.useProgram(F),f=F,!0):!1}let Je={[as]:32774,[Uh]:32778,[Vh]:32779};if(n)Je[Rl]=32775,Je[Il]=32776;else{let F=e.get("EXT_blend_minmax");F!==null&&(Je[Rl]=F.MIN_EXT,Je[Il]=F.MAX_EXT)}let Ce={[Gh]:0,[Hh]:1,[Wh]:768,[Jc]:770,[$h]:776,[Zh]:774,[qh]:772,[Xh]:769,[$c]:771,[Jh]:775,[Yh]:773};function Dt(F,J,de,Te,Ne,ot,Nt,Ht){if(F===gi){b===!0&&(Re(3042),b=!1);return}if(b===!1&&(Ze(3042),b=!0),F!==Bh){if(F!==C||Ht!==P){if((S!==as||N!==as)&&(r.blendEquation(32774),S=as,N=as),Ht)switch(F){case cs:r.blendFuncSeparate(1,771,1,771);break;case Cl:r.blendFunc(1,1);break;case Pl:r.blendFuncSeparate(0,769,0,1);break;case Ll:r.blendFuncSeparate(0,768,0,770);break;default:console.error("THREE.WebGLState: Invalid blending: ",F);break}else switch(F){case cs:r.blendFuncSeparate(770,771,1,771);break;case Cl:r.blendFunc(770,1);break;case Pl:r.blendFuncSeparate(0,769,0,1);break;case Ll:r.blendFunc(0,768);break;default:console.error("THREE.WebGLState: Invalid blending: ",F);break}y=null,M=null,k=null,x=null,C=F,P=Ht}return}Ne=Ne||J,ot=ot||de,Nt=Nt||Te,(J!==S||Ne!==N)&&(r.blendEquationSeparate(Je[J],Je[Ne]),S=J,N=Ne),(de!==y||Te!==M||ot!==k||Nt!==x)&&(r.blendFuncSeparate(Ce[de],Ce[Te],Ce[ot],Ce[Nt]),y=de,M=Te,k=ot,x=Nt),C=F,P=!1}function vt(F,J){F.side===fn?Re(2884):Ze(2884);let de=F.side===An;J&&(de=!de),Pt(de),F.blending===cs&&F.transparent===!1?Dt(gi):Dt(F.blending,F.blendEquation,F.blendSrc,F.blendDst,F.blendEquationAlpha,F.blendSrcAlpha,F.blendDstAlpha,F.premultipliedAlpha),c.setFunc(F.depthFunc),c.setTest(F.depthTest),c.setMask(F.depthWrite),o.setMask(F.colorWrite);let Te=F.stencilWrite;h.setTest(Te),Te&&(h.setMask(F.stencilWriteMask),h.setFunc(F.stencilFunc,F.stencilRef,F.stencilFuncMask),h.setOp(F.stencilFail,F.stencilZFail,F.stencilZPass)),gt(F.polygonOffset,F.polygonOffsetFactor,F.polygonOffsetUnits),F.alphaToCoverage===!0?Ze(32926):Re(32926)}function Pt(F){z!==F&&(F?r.frontFace(2304):r.frontFace(2305),z=F)}function qt(F){F!==zh?(Ze(2884),F!==Y&&(F===El?r.cullFace(1029):F===Fh?r.cullFace(1028):r.cullFace(1032))):Re(2884),Y=F}function St(F){F!==ie&&(re&&r.lineWidth(F),ie=F)}function gt(F,J,de){F?(Ze(32823),(q!==J||B!==de)&&(r.polygonOffset(J,de),q=J,B=de)):Re(32823)}function ln(F){F?Ze(3089):Re(3089)}function Yt(F){F===void 0&&(F=33984+K-1),me!==F&&(r.activeTexture(F),me=F)}function L(F,J,de){de===void 0&&(me===null?de=33984+K-1:de=me);let Te=ae[de];Te===void 0&&(Te={type:void 0,texture:void 0},ae[de]=Te),(Te.type!==F||Te.texture!==J)&&(me!==de&&(r.activeTexture(de),me=de),r.bindTexture(F,J||te[F]),Te.type=F,Te.texture=J)}function w(){let F=ae[me];F!==void 0&&F.type!==void 0&&(r.bindTexture(F.type,null),F.type=void 0,F.texture=void 0)}function j(){try{r.compressedTexImage2D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function le(){try{r.compressedTexImage3D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function ge(){try{r.texSubImage2D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function be(){try{r.texSubImage3D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function he(){try{r.compressedTexSubImage2D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function I(){try{r.compressedTexSubImage3D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function U(){try{r.texStorage2D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function Se(){try{r.texStorage3D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function Ae(){try{r.texImage2D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function Me(){try{r.texImage3D.apply(r,arguments)}catch(F){console.error("THREE.WebGLState:",F)}}function Oe(F){_e.equals(F)===!1&&(r.scissor(F.x,F.y,F.z,F.w),_e.copy(F))}function Ie(F){pe.equals(F)===!1&&(r.viewport(F.x,F.y,F.z,F.w),pe.copy(F))}function $e(F,J){let de=l.get(J);de===void 0&&(de=new WeakMap,l.set(J,de));let Te=de.get(F);Te===void 0&&(Te=r.getUniformBlockIndex(J,F.name),de.set(F,Te))}function rt(F,J){let Te=l.get(J).get(F);u.get(F)!==Te&&(r.uniformBlockBinding(J,Te,F.__bindingPointIndex),u.set(F,Te))}function dt(){r.disable(3042),r.disable(2884),r.disable(2929),r.disable(32823),r.disable(3089),r.disable(2960),r.disable(32926),r.blendEquation(32774),r.blendFunc(1,0),r.blendFuncSeparate(1,0,1,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(513),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(519,0,4294967295),r.stencilOp(7680,7680,7680),r.clearStencil(0),r.cullFace(1029),r.frontFace(2305),r.polygonOffset(0,0),r.activeTexture(33984),r.bindFramebuffer(36160,null),n===!0&&(r.bindFramebuffer(36009,null),r.bindFramebuffer(36008,null)),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),d={},me=null,ae={},m={},_=new WeakMap,p=[],f=null,b=!1,C=null,S=null,y=null,M=null,N=null,k=null,x=null,P=!1,z=null,Y=null,ie=null,q=null,B=null,_e.set(0,0,r.canvas.width,r.canvas.height),pe.set(0,0,r.canvas.width,r.canvas.height),o.reset(),c.reset(),h.reset()}return{buffers:{color:o,depth:c,stencil:h},enable:Ze,disable:Re,bindFramebuffer:Be,drawBuffers:Pe,useProgram:ft,setBlending:Dt,setMaterial:vt,setFlipSided:Pt,setCullFace:qt,setLineWidth:St,setPolygonOffset:gt,setScissorTest:ln,activeTexture:Yt,bindTexture:L,unbindTexture:w,compressedTexImage2D:j,compressedTexImage3D:le,texImage2D:Ae,texImage3D:Me,updateUBOMapping:$e,uniformBlockBinding:rt,texStorage2D:U,texStorage3D:Se,texSubImage2D:ge,texSubImage3D:be,compressedTexSubImage2D:he,compressedTexSubImage3D:I,scissor:Oe,viewport:Ie,reset:dt}}function Tg(r,e,t,n,i,s,a){let o=i.isWebGL2,c=i.maxTextures,h=i.maxCubemapSize,u=i.maxTextureSize,l=i.maxSamples,d=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator=="undefined"?!1:/OculusBrowser/g.test(navigator.userAgent),_=new WeakMap,p,f=new WeakMap,b=!1;try{b=typeof OffscreenCanvas!="undefined"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function C(L,w){return b?new OffscreenCanvas(L,w):qs("canvas")}function S(L,w,j,le){let ge=1;if((L.width>le||L.height>le)&&(ge=le/Math.max(L.width,L.height)),ge<1||w===!0)if(typeof HTMLImageElement!="undefined"&&L instanceof HTMLImageElement||typeof HTMLCanvasElement!="undefined"&&L instanceof HTMLCanvasElement||typeof ImageBitmap!="undefined"&&L instanceof ImageBitmap){let be=w?$r:Math.floor,he=be(ge*L.width),I=be(ge*L.height);p===void 0&&(p=C(he,I));let U=j?C(he,I):p;return U.width=he,U.height=I,U.getContext("2d").drawImage(L,0,0,he,I),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+L.width+"x"+L.height+") to ("+he+"x"+I+")."),U}else return"data"in L&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+L.width+"x"+L.height+")."),L;return L}function y(L){return ba(L.width)&&ba(L.height)}function M(L){return o?!1:L.wrapS!==On||L.wrapT!==On||L.minFilter!==dn&&L.minFilter!==Tn}function N(L,w){return L.generateMipmaps&&w&&L.minFilter!==dn&&L.minFilter!==Tn}function k(L){r.generateMipmap(L)}function x(L,w,j,le,ge=!1){if(o===!1)return w;if(L!==null){if(r[L]!==void 0)return r[L];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+L+"'")}let be=w;return w===6403&&(j===5126&&(be=33326),j===5131&&(be=33325),j===5121&&(be=33321)),w===33319&&(j===5126&&(be=33328),j===5131&&(be=33327),j===5121&&(be=33323)),w===6408&&(j===5126&&(be=34836),j===5131&&(be=34842),j===5121&&(be=le===_t&&ge===!1?35907:32856),j===32819&&(be=32854),j===32820&&(be=32855)),(be===33325||be===33326||be===33327||be===33328||be===34842||be===34836)&&e.get("EXT_color_buffer_float"),be}function P(L,w,j){return N(L,j)===!0||L.isFramebufferTexture&&L.minFilter!==dn&&L.minFilter!==Tn?Math.log2(Math.max(w.width,w.height))+1:L.mipmaps!==void 0&&L.mipmaps.length>0?L.mipmaps.length:L.isCompressedTexture&&Array.isArray(L.image)?w.mipmaps.length:1}function z(L){return L===dn||L===Dl||L===Nl?9728:9729}function Y(L){let w=L.target;w.removeEventListener("dispose",Y),q(w),w.isVideoTexture&&_.delete(w)}function ie(L){let w=L.target;w.removeEventListener("dispose",ie),K(w)}function q(L){let w=n.get(L);if(w.__webglInit===void 0)return;let j=L.source,le=f.get(j);if(le){let ge=le[w.__cacheKey];ge.usedTimes--,ge.usedTimes===0&&B(L),Object.keys(le).length===0&&f.delete(j)}n.remove(L)}function B(L){let w=n.get(L);r.deleteTexture(w.__webglTexture);let j=L.source,le=f.get(j);delete le[w.__cacheKey],a.memory.textures--}function K(L){let w=L.texture,j=n.get(L),le=n.get(w);if(le.__webglTexture!==void 0&&(r.deleteTexture(le.__webglTexture),a.memory.textures--),L.depthTexture&&L.depthTexture.dispose(),L.isWebGLCubeRenderTarget)for(let ge=0;ge<6;ge++)r.deleteFramebuffer(j.__webglFramebuffer[ge]),j.__webglDepthbuffer&&r.deleteRenderbuffer(j.__webglDepthbuffer[ge]);else{if(r.deleteFramebuffer(j.__webglFramebuffer),j.__webglDepthbuffer&&r.deleteRenderbuffer(j.__webglDepthbuffer),j.__webglMultisampledFramebuffer&&r.deleteFramebuffer(j.__webglMultisampledFramebuffer),j.__webglColorRenderbuffer)for(let ge=0;ge<j.__webglColorRenderbuffer.length;ge++)j.__webglColorRenderbuffer[ge]&&r.deleteRenderbuffer(j.__webglColorRenderbuffer[ge]);j.__webglDepthRenderbuffer&&r.deleteRenderbuffer(j.__webglDepthRenderbuffer)}if(L.isWebGLMultipleRenderTargets)for(let ge=0,be=w.length;ge<be;ge++){let he=n.get(w[ge]);he.__webglTexture&&(r.deleteTexture(he.__webglTexture),a.memory.textures--),n.remove(w[ge])}n.remove(w),n.remove(L)}let re=0;function ue(){re=0}function Z(){let L=re;return L>=c&&console.warn("THREE.WebGLTextures: Trying to use "+L+" texture units while this GPU supports only "+c),re+=1,L}function me(L){let w=[];return w.push(L.wrapS),w.push(L.wrapT),w.push(L.wrapR||0),w.push(L.magFilter),w.push(L.minFilter),w.push(L.anisotropy),w.push(L.internalFormat),w.push(L.format),w.push(L.type),w.push(L.generateMipmaps),w.push(L.premultiplyAlpha),w.push(L.flipY),w.push(L.unpackAlignment),w.push(L.encoding),w.join()}function ae(L,w){let j=n.get(L);if(L.isVideoTexture&&ln(L),L.isRenderTargetTexture===!1&&L.version>0&&j.__version!==L.version){let le=L.image;if(le===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(le.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Re(j,L,w);return}}t.bindTexture(3553,j.__webglTexture,33984+w)}function ee(L,w){let j=n.get(L);if(L.version>0&&j.__version!==L.version){Re(j,L,w);return}t.bindTexture(35866,j.__webglTexture,33984+w)}function $(L,w){let j=n.get(L);if(L.version>0&&j.__version!==L.version){Re(j,L,w);return}t.bindTexture(32879,j.__webglTexture,33984+w)}function _e(L,w){let j=n.get(L);if(L.version>0&&j.__version!==L.version){Be(j,L,w);return}t.bindTexture(34067,j.__webglTexture,33984+w)}let pe={[xa]:10497,[On]:33071,[_a]:33648},ve={[dn]:9728,[Dl]:9984,[Nl]:9986,[Tn]:9729,[uu]:9985,[bo]:9987};function te(L,w,j){if(j?(r.texParameteri(L,10242,pe[w.wrapS]),r.texParameteri(L,10243,pe[w.wrapT]),(L===32879||L===35866)&&r.texParameteri(L,32882,pe[w.wrapR]),r.texParameteri(L,10240,ve[w.magFilter]),r.texParameteri(L,10241,ve[w.minFilter])):(r.texParameteri(L,10242,33071),r.texParameteri(L,10243,33071),(L===32879||L===35866)&&r.texParameteri(L,32882,33071),(w.wrapS!==On||w.wrapT!==On)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),r.texParameteri(L,10240,z(w.magFilter)),r.texParameteri(L,10241,z(w.minFilter)),w.minFilter!==dn&&w.minFilter!==Tn&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),e.has("EXT_texture_filter_anisotropic")===!0){let le=e.get("EXT_texture_filter_anisotropic");if(w.type===Ei&&e.has("OES_texture_float_linear")===!1||o===!1&&w.type===Ws&&e.has("OES_texture_half_float_linear")===!1)return;(w.anisotropy>1||n.get(w).__currentAnisotropy)&&(r.texParameterf(L,le.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(w.anisotropy,i.getMaxAnisotropy())),n.get(w).__currentAnisotropy=w.anisotropy)}}function Ze(L,w){let j=!1;L.__webglInit===void 0&&(L.__webglInit=!0,w.addEventListener("dispose",Y));let le=w.source,ge=f.get(le);ge===void 0&&(ge={},f.set(le,ge));let be=me(w);if(be!==L.__cacheKey){ge[be]===void 0&&(ge[be]={texture:r.createTexture(),usedTimes:0},a.memory.textures++,j=!0),ge[be].usedTimes++;let he=ge[L.__cacheKey];he!==void 0&&(ge[L.__cacheKey].usedTimes--,he.usedTimes===0&&B(w)),L.__cacheKey=be,L.__webglTexture=ge[be].texture}return j}function Re(L,w,j){let le=3553;(w.isDataArrayTexture||w.isCompressedArrayTexture)&&(le=35866),w.isData3DTexture&&(le=32879);let ge=Ze(L,w),be=w.source;t.bindTexture(le,L.__webglTexture,33984+j);let he=n.get(be);if(be.version!==he.__version||ge===!0){t.activeTexture(33984+j),r.pixelStorei(37440,w.flipY),r.pixelStorei(37441,w.premultiplyAlpha),r.pixelStorei(3317,w.unpackAlignment),r.pixelStorei(37443,0);let I=M(w)&&y(w.image)===!1,U=S(w.image,I,!1,u);U=Yt(w,U);let Se=y(U)||o,Ae=s.convert(w.format,w.encoding),Me=s.convert(w.type),Oe=x(w.internalFormat,Ae,Me,w.encoding,w.isVideoTexture);te(le,w,Se);let Ie,$e=w.mipmaps,rt=o&&w.isVideoTexture!==!0,dt=he.__version===void 0||ge===!0,F=P(w,U,Se);if(w.isDepthTexture)Oe=6402,o?w.type===Ei?Oe=36012:w.type===Ai?Oe=33190:w.type===hs?Oe=35056:Oe=33189:w.type===Ei&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),w.format===Ci&&Oe===6402&&w.type!==Qc&&w.type!==Ai&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),w.type=Ai,Me=s.convert(w.type)),w.format===gs&&Oe===6402&&(Oe=34041,w.type!==hs&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),w.type=hs,Me=s.convert(w.type))),dt&&(rt?t.texStorage2D(3553,1,Oe,U.width,U.height):t.texImage2D(3553,0,Oe,U.width,U.height,0,Ae,Me,null));else if(w.isDataTexture)if($e.length>0&&Se){rt&&dt&&t.texStorage2D(3553,F,Oe,$e[0].width,$e[0].height);for(let J=0,de=$e.length;J<de;J++)Ie=$e[J],rt?t.texSubImage2D(3553,J,0,0,Ie.width,Ie.height,Ae,Me,Ie.data):t.texImage2D(3553,J,Oe,Ie.width,Ie.height,0,Ae,Me,Ie.data);w.generateMipmaps=!1}else rt?(dt&&t.texStorage2D(3553,F,Oe,U.width,U.height),t.texSubImage2D(3553,0,0,0,U.width,U.height,Ae,Me,U.data)):t.texImage2D(3553,0,Oe,U.width,U.height,0,Ae,Me,U.data);else if(w.isCompressedTexture)if(w.isCompressedArrayTexture){rt&&dt&&t.texStorage3D(35866,F,Oe,$e[0].width,$e[0].height,U.depth);for(let J=0,de=$e.length;J<de;J++)Ie=$e[J],w.format!==zn?Ae!==null?rt?t.compressedTexSubImage3D(35866,J,0,0,0,Ie.width,Ie.height,U.depth,Ae,Ie.data,0,0):t.compressedTexImage3D(35866,J,Oe,Ie.width,Ie.height,U.depth,0,Ie.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):rt?t.texSubImage3D(35866,J,0,0,0,Ie.width,Ie.height,U.depth,Ae,Me,Ie.data):t.texImage3D(35866,J,Oe,Ie.width,Ie.height,U.depth,0,Ae,Me,Ie.data)}else{rt&&dt&&t.texStorage2D(3553,F,Oe,$e[0].width,$e[0].height);for(let J=0,de=$e.length;J<de;J++)Ie=$e[J],w.format!==zn?Ae!==null?rt?t.compressedTexSubImage2D(3553,J,0,0,Ie.width,Ie.height,Ae,Ie.data):t.compressedTexImage2D(3553,J,Oe,Ie.width,Ie.height,0,Ie.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):rt?t.texSubImage2D(3553,J,0,0,Ie.width,Ie.height,Ae,Me,Ie.data):t.texImage2D(3553,J,Oe,Ie.width,Ie.height,0,Ae,Me,Ie.data)}else if(w.isDataArrayTexture)rt?(dt&&t.texStorage3D(35866,F,Oe,U.width,U.height,U.depth),t.texSubImage3D(35866,0,0,0,0,U.width,U.height,U.depth,Ae,Me,U.data)):t.texImage3D(35866,0,Oe,U.width,U.height,U.depth,0,Ae,Me,U.data);else if(w.isData3DTexture)rt?(dt&&t.texStorage3D(32879,F,Oe,U.width,U.height,U.depth),t.texSubImage3D(32879,0,0,0,0,U.width,U.height,U.depth,Ae,Me,U.data)):t.texImage3D(32879,0,Oe,U.width,U.height,U.depth,0,Ae,Me,U.data);else if(w.isFramebufferTexture){if(dt)if(rt)t.texStorage2D(3553,F,Oe,U.width,U.height);else{let J=U.width,de=U.height;for(let Te=0;Te<F;Te++)t.texImage2D(3553,Te,Oe,J,de,0,Ae,Me,null),J>>=1,de>>=1}}else if($e.length>0&&Se){rt&&dt&&t.texStorage2D(3553,F,Oe,$e[0].width,$e[0].height);for(let J=0,de=$e.length;J<de;J++)Ie=$e[J],rt?t.texSubImage2D(3553,J,0,0,Ae,Me,Ie):t.texImage2D(3553,J,Oe,Ae,Me,Ie);w.generateMipmaps=!1}else rt?(dt&&t.texStorage2D(3553,F,Oe,U.width,U.height),t.texSubImage2D(3553,0,0,0,Ae,Me,U)):t.texImage2D(3553,0,Oe,Ae,Me,U);N(w,Se)&&k(le),he.__version=be.version,w.onUpdate&&w.onUpdate(w)}L.__version=w.version}function Be(L,w,j){if(w.image.length!==6)return;let le=Ze(L,w),ge=w.source;t.bindTexture(34067,L.__webglTexture,33984+j);let be=n.get(ge);if(ge.version!==be.__version||le===!0){t.activeTexture(33984+j),r.pixelStorei(37440,w.flipY),r.pixelStorei(37441,w.premultiplyAlpha),r.pixelStorei(3317,w.unpackAlignment),r.pixelStorei(37443,0);let he=w.isCompressedTexture||w.image[0].isCompressedTexture,I=w.image[0]&&w.image[0].isDataTexture,U=[];for(let J=0;J<6;J++)!he&&!I?U[J]=S(w.image[J],!1,!0,h):U[J]=I?w.image[J].image:w.image[J],U[J]=Yt(w,U[J]);let Se=U[0],Ae=y(Se)||o,Me=s.convert(w.format,w.encoding),Oe=s.convert(w.type),Ie=x(w.internalFormat,Me,Oe,w.encoding),$e=o&&w.isVideoTexture!==!0,rt=be.__version===void 0||le===!0,dt=P(w,Se,Ae);te(34067,w,Ae);let F;if(he){$e&&rt&&t.texStorage2D(34067,dt,Ie,Se.width,Se.height);for(let J=0;J<6;J++){F=U[J].mipmaps;for(let de=0;de<F.length;de++){let Te=F[de];w.format!==zn?Me!==null?$e?t.compressedTexSubImage2D(34069+J,de,0,0,Te.width,Te.height,Me,Te.data):t.compressedTexImage2D(34069+J,de,Ie,Te.width,Te.height,0,Te.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):$e?t.texSubImage2D(34069+J,de,0,0,Te.width,Te.height,Me,Oe,Te.data):t.texImage2D(34069+J,de,Ie,Te.width,Te.height,0,Me,Oe,Te.data)}}}else{F=w.mipmaps,$e&&rt&&(F.length>0&&dt++,t.texStorage2D(34067,dt,Ie,U[0].width,U[0].height));for(let J=0;J<6;J++)if(I){$e?t.texSubImage2D(34069+J,0,0,0,U[J].width,U[J].height,Me,Oe,U[J].data):t.texImage2D(34069+J,0,Ie,U[J].width,U[J].height,0,Me,Oe,U[J].data);for(let de=0;de<F.length;de++){let Ne=F[de].image[J].image;$e?t.texSubImage2D(34069+J,de+1,0,0,Ne.width,Ne.height,Me,Oe,Ne.data):t.texImage2D(34069+J,de+1,Ie,Ne.width,Ne.height,0,Me,Oe,Ne.data)}}else{$e?t.texSubImage2D(34069+J,0,0,0,Me,Oe,U[J]):t.texImage2D(34069+J,0,Ie,Me,Oe,U[J]);for(let de=0;de<F.length;de++){let Te=F[de];$e?t.texSubImage2D(34069+J,de+1,0,0,Me,Oe,Te.image[J]):t.texImage2D(34069+J,de+1,Ie,Me,Oe,Te.image[J])}}}N(w,Ae)&&k(34067),be.__version=ge.version,w.onUpdate&&w.onUpdate(w)}L.__version=w.version}function Pe(L,w,j,le,ge){let be=s.convert(j.format,j.encoding),he=s.convert(j.type),I=x(j.internalFormat,be,he,j.encoding);n.get(w).__hasExternalTextures||(ge===32879||ge===35866?t.texImage3D(ge,0,I,w.width,w.height,w.depth,0,be,he,null):t.texImage2D(ge,0,I,w.width,w.height,0,be,he,null)),t.bindFramebuffer(36160,L),gt(w)?d.framebufferTexture2DMultisampleEXT(36160,le,ge,n.get(j).__webglTexture,0,St(w)):(ge===3553||ge>=34069&&ge<=34074)&&r.framebufferTexture2D(36160,le,ge,n.get(j).__webglTexture,0),t.bindFramebuffer(36160,null)}function ft(L,w,j){if(r.bindRenderbuffer(36161,L),w.depthBuffer&&!w.stencilBuffer){let le=33189;if(j||gt(w)){let ge=w.depthTexture;ge&&ge.isDepthTexture&&(ge.type===Ei?le=36012:ge.type===Ai&&(le=33190));let be=St(w);gt(w)?d.renderbufferStorageMultisampleEXT(36161,be,le,w.width,w.height):r.renderbufferStorageMultisample(36161,be,le,w.width,w.height)}else r.renderbufferStorage(36161,le,w.width,w.height);r.framebufferRenderbuffer(36160,36096,36161,L)}else if(w.depthBuffer&&w.stencilBuffer){let le=St(w);j&&gt(w)===!1?r.renderbufferStorageMultisample(36161,le,35056,w.width,w.height):gt(w)?d.renderbufferStorageMultisampleEXT(36161,le,35056,w.width,w.height):r.renderbufferStorage(36161,34041,w.width,w.height),r.framebufferRenderbuffer(36160,33306,36161,L)}else{let le=w.isWebGLMultipleRenderTargets===!0?w.texture:[w.texture];for(let ge=0;ge<le.length;ge++){let be=le[ge],he=s.convert(be.format,be.encoding),I=s.convert(be.type),U=x(be.internalFormat,he,I,be.encoding),Se=St(w);j&&gt(w)===!1?r.renderbufferStorageMultisample(36161,Se,U,w.width,w.height):gt(w)?d.renderbufferStorageMultisampleEXT(36161,Se,U,w.width,w.height):r.renderbufferStorage(36161,U,w.width,w.height)}}r.bindRenderbuffer(36161,null)}function Je(L,w){if(w&&w.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(36160,L),!(w.depthTexture&&w.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(w.depthTexture).__webglTexture||w.depthTexture.image.width!==w.width||w.depthTexture.image.height!==w.height)&&(w.depthTexture.image.width=w.width,w.depthTexture.image.height=w.height,w.depthTexture.needsUpdate=!0),ae(w.depthTexture,0);let le=n.get(w.depthTexture).__webglTexture,ge=St(w);if(w.depthTexture.format===Ci)gt(w)?d.framebufferTexture2DMultisampleEXT(36160,36096,3553,le,0,ge):r.framebufferTexture2D(36160,36096,3553,le,0);else if(w.depthTexture.format===gs)gt(w)?d.framebufferTexture2DMultisampleEXT(36160,33306,3553,le,0,ge):r.framebufferTexture2D(36160,33306,3553,le,0);else throw new Error("Unknown depthTexture format")}function Ce(L){let w=n.get(L),j=L.isWebGLCubeRenderTarget===!0;if(L.depthTexture&&!w.__autoAllocateDepthBuffer){if(j)throw new Error("target.depthTexture not supported in Cube render targets");Je(w.__webglFramebuffer,L)}else if(j){w.__webglDepthbuffer=[];for(let le=0;le<6;le++)t.bindFramebuffer(36160,w.__webglFramebuffer[le]),w.__webglDepthbuffer[le]=r.createRenderbuffer(),ft(w.__webglDepthbuffer[le],L,!1)}else t.bindFramebuffer(36160,w.__webglFramebuffer),w.__webglDepthbuffer=r.createRenderbuffer(),ft(w.__webglDepthbuffer,L,!1);t.bindFramebuffer(36160,null)}function Dt(L,w,j){let le=n.get(L);w!==void 0&&Pe(le.__webglFramebuffer,L,L.texture,36064,3553),j!==void 0&&Ce(L)}function vt(L){let w=L.texture,j=n.get(L),le=n.get(w);L.addEventListener("dispose",ie),L.isWebGLMultipleRenderTargets!==!0&&(le.__webglTexture===void 0&&(le.__webglTexture=r.createTexture()),le.__version=w.version,a.memory.textures++);let ge=L.isWebGLCubeRenderTarget===!0,be=L.isWebGLMultipleRenderTargets===!0,he=y(L)||o;if(ge){j.__webglFramebuffer=[];for(let I=0;I<6;I++)j.__webglFramebuffer[I]=r.createFramebuffer()}else{if(j.__webglFramebuffer=r.createFramebuffer(),be)if(i.drawBuffers){let I=L.texture;for(let U=0,Se=I.length;U<Se;U++){let Ae=n.get(I[U]);Ae.__webglTexture===void 0&&(Ae.__webglTexture=r.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&L.samples>0&&gt(L)===!1){let I=be?w:[w];j.__webglMultisampledFramebuffer=r.createFramebuffer(),j.__webglColorRenderbuffer=[],t.bindFramebuffer(36160,j.__webglMultisampledFramebuffer);for(let U=0;U<I.length;U++){let Se=I[U];j.__webglColorRenderbuffer[U]=r.createRenderbuffer(),r.bindRenderbuffer(36161,j.__webglColorRenderbuffer[U]);let Ae=s.convert(Se.format,Se.encoding),Me=s.convert(Se.type),Oe=x(Se.internalFormat,Ae,Me,Se.encoding,L.isXRRenderTarget===!0),Ie=St(L);r.renderbufferStorageMultisample(36161,Ie,Oe,L.width,L.height),r.framebufferRenderbuffer(36160,36064+U,36161,j.__webglColorRenderbuffer[U])}r.bindRenderbuffer(36161,null),L.depthBuffer&&(j.__webglDepthRenderbuffer=r.createRenderbuffer(),ft(j.__webglDepthRenderbuffer,L,!0)),t.bindFramebuffer(36160,null)}}if(ge){t.bindTexture(34067,le.__webglTexture),te(34067,w,he);for(let I=0;I<6;I++)Pe(j.__webglFramebuffer[I],L,w,36064,34069+I);N(w,he)&&k(34067),t.unbindTexture()}else if(be){let I=L.texture;for(let U=0,Se=I.length;U<Se;U++){let Ae=I[U],Me=n.get(Ae);t.bindTexture(3553,Me.__webglTexture),te(3553,Ae,he),Pe(j.__webglFramebuffer,L,Ae,36064+U,3553),N(Ae,he)&&k(3553)}t.unbindTexture()}else{let I=3553;(L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(o?I=L.isWebGL3DRenderTarget?32879:35866:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(I,le.__webglTexture),te(I,w,he),Pe(j.__webglFramebuffer,L,w,36064,I),N(w,he)&&k(I),t.unbindTexture()}L.depthBuffer&&Ce(L)}function Pt(L){let w=y(L)||o,j=L.isWebGLMultipleRenderTargets===!0?L.texture:[L.texture];for(let le=0,ge=j.length;le<ge;le++){let be=j[le];if(N(be,w)){let he=L.isWebGLCubeRenderTarget?34067:3553,I=n.get(be).__webglTexture;t.bindTexture(he,I),k(he),t.unbindTexture()}}}function qt(L){if(o&&L.samples>0&&gt(L)===!1){let w=L.isWebGLMultipleRenderTargets?L.texture:[L.texture],j=L.width,le=L.height,ge=16384,be=[],he=L.stencilBuffer?33306:36096,I=n.get(L),U=L.isWebGLMultipleRenderTargets===!0;if(U)for(let Se=0;Se<w.length;Se++)t.bindFramebuffer(36160,I.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(36160,36064+Se,36161,null),t.bindFramebuffer(36160,I.__webglFramebuffer),r.framebufferTexture2D(36009,36064+Se,3553,null,0);t.bindFramebuffer(36008,I.__webglMultisampledFramebuffer),t.bindFramebuffer(36009,I.__webglFramebuffer);for(let Se=0;Se<w.length;Se++){be.push(36064+Se),L.depthBuffer&&be.push(he);let Ae=I.__ignoreDepthValues!==void 0?I.__ignoreDepthValues:!1;if(Ae===!1&&(L.depthBuffer&&(ge|=256),L.stencilBuffer&&(ge|=1024)),U&&r.framebufferRenderbuffer(36008,36064,36161,I.__webglColorRenderbuffer[Se]),Ae===!0&&(r.invalidateFramebuffer(36008,[he]),r.invalidateFramebuffer(36009,[he])),U){let Me=n.get(w[Se]).__webglTexture;r.framebufferTexture2D(36009,36064,3553,Me,0)}r.blitFramebuffer(0,0,j,le,0,0,j,le,ge,9728),m&&r.invalidateFramebuffer(36008,be)}if(t.bindFramebuffer(36008,null),t.bindFramebuffer(36009,null),U)for(let Se=0;Se<w.length;Se++){t.bindFramebuffer(36160,I.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(36160,36064+Se,36161,I.__webglColorRenderbuffer[Se]);let Ae=n.get(w[Se]).__webglTexture;t.bindFramebuffer(36160,I.__webglFramebuffer),r.framebufferTexture2D(36009,36064+Se,3553,Ae,0)}t.bindFramebuffer(36009,I.__webglMultisampledFramebuffer)}}function St(L){return Math.min(l,L.samples)}function gt(L){let w=n.get(L);return o&&L.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&w.__useRenderToTexture!==!1}function ln(L){let w=a.render.frame;_.get(L)!==w&&(_.set(L,w),L.update())}function Yt(L,w){let j=L.encoding,le=L.format,ge=L.type;return L.isCompressedTexture===!0||L.isVideoTexture===!0||L.format===va||j!==Ri&&(j===_t?o===!1?e.has("EXT_sRGB")===!0&&le===zn?(L.format=va,L.minFilter=Tn,L.generateMipmaps=!1):w=Kr.sRGBToLinear(w):(le!==zn||ge!==Li)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture encoding:",j)),w}this.allocateTextureUnit=Z,this.resetTextureUnits=ue,this.setTexture2D=ae,this.setTexture2DArray=ee,this.setTexture3D=$,this.setTextureCube=_e,this.rebindTextures=Dt,this.setupRenderTarget=vt,this.updateRenderTargetMipmap=Pt,this.updateMultisampleRenderTarget=qt,this.setupDepthRenderbuffer=Ce,this.setupFrameBufferTexture=Pe,this.useMultisampledRTT=gt}function Ag(r,e,t){let n=t.isWebGL2;function i(s,a=null){let o;if(s===Li)return 5121;if(s===mu)return 32819;if(s===gu)return 32820;if(s===du)return 5120;if(s===fu)return 5122;if(s===Qc)return 5123;if(s===pu)return 5124;if(s===Ai)return 5125;if(s===Ei)return 5126;if(s===Ws)return n?5131:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(s===xu)return 6406;if(s===zn)return 6408;if(s===yu)return 6409;if(s===vu)return 6410;if(s===Ci)return 6402;if(s===gs)return 34041;if(s===_u)return console.warn("THREE.WebGLRenderer: THREE.RGBFormat has been removed. Use THREE.RGBAFormat instead. https://github.com/mrdoob/three.js/pull/23228"),6408;if(s===va)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(s===bu)return 6403;if(s===Mu)return 36244;if(s===wu)return 33319;if(s===Su)return 33320;if(s===Tu)return 36249;if(s===No||s===Oo||s===zo||s===Fo)if(a===_t)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(s===No)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Oo)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===zo)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Fo)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(s===No)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Oo)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===zo)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Fo)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Ol||s===zl||s===Fl||s===kl)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(s===Ol)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===zl)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Fl)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===kl)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Au)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Bl||s===Ul)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(s===Bl)return a===_t?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(s===Ul)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Vl||s===Gl||s===Hl||s===Wl||s===Xl||s===ql||s===Yl||s===Zl||s===Jl||s===$l||s===Kl||s===jl||s===Ql||s===ec)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(s===Vl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Gl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Hl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Wl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Xl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===ql)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Yl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Zl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Jl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===$l)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Kl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===jl)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Ql)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===ec)return a===_t?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===tc)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(s===tc)return a===_t?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT}else return null;return s===hs?n?34042:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):r[s]!==void 0?r[s]:null}return{convert:i}}var Da=class extends rn{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},on=class extends Jt{constructor(){super(),this.isGroup=!0,this.type="Group"}},Eg={type:"move"},Hs=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new on,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new on,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new R,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new R),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new on,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new R,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new R),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let i=null,s=null,a=null,o=this._targetRay,c=this._grip,h=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(h&&e.hand){a=!0;for(let p of e.hand.values()){let f=t.getJointPose(p,n),b=this._getHandJoint(h,p);f!==null&&(b.matrix.fromArray(f.transform.matrix),b.matrix.decompose(b.position,b.rotation,b.scale),b.jointRadius=f.radius),b.visible=f!==null}let u=h.joints["index-finger-tip"],l=h.joints["thumb-tip"],d=u.position.distanceTo(l.position),m=.02,_=.005;h.inputState.pinching&&d>m+_?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!h.inputState.pinching&&d<=m-_&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(i=t.getPose(e.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Eg)))}return o!==null&&(o.visible=i!==null),c!==null&&(c.visible=s!==null),h!==null&&(h.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new on;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},Na=class extends an{constructor(e,t,n,i,s,a,o,c,h,u){if(u=u!==void 0?u:Ci,u!==Ci&&u!==gs)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&u===Ci&&(n=Ai),n===void 0&&u===gs&&(n=hs),super(null,i,s,a,o,c,u,n,h),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:dn,this.minFilter=c!==void 0?c:dn,this.flipY=!1,this.generateMipmaps=!1}},Oa=class extends Gn{constructor(e,t){super();let n=this,i=null,s=1,a=null,o="local-floor",c=null,h=null,u=null,l=null,d=null,m=null,_=t.getContextAttributes(),p=null,f=null,b=[],C=[],S=new Set,y=new Map,M=new rn;M.layers.enable(1),M.viewport=new Xt;let N=new rn;N.layers.enable(2),N.viewport=new Xt;let k=[M,N],x=new Da;x.layers.enable(1),x.layers.enable(2);let P=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ee){let $=b[ee];return $===void 0&&($=new Hs,b[ee]=$),$.getTargetRaySpace()},this.getControllerGrip=function(ee){let $=b[ee];return $===void 0&&($=new Hs,b[ee]=$),$.getGripSpace()},this.getHand=function(ee){let $=b[ee];return $===void 0&&($=new Hs,b[ee]=$),$.getHandSpace()};function Y(ee){let $=C.indexOf(ee.inputSource);if($===-1)return;let _e=b[$];_e!==void 0&&_e.dispatchEvent({type:ee.type,data:ee.inputSource})}function ie(){i.removeEventListener("select",Y),i.removeEventListener("selectstart",Y),i.removeEventListener("selectend",Y),i.removeEventListener("squeeze",Y),i.removeEventListener("squeezestart",Y),i.removeEventListener("squeezeend",Y),i.removeEventListener("end",ie),i.removeEventListener("inputsourceschange",q);for(let ee=0;ee<b.length;ee++){let $=C[ee];$!==null&&(C[ee]=null,b[ee].disconnect($))}P=null,z=null,e.setRenderTarget(p),d=null,l=null,u=null,i=null,f=null,ae.stop(),n.isPresenting=!1,n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ee){s=ee,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ee){o=ee,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(ee){c=ee},this.getBaseLayer=function(){return l!==null?l:d},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return i},this.setSession=async function(ee){if(i=ee,i!==null){if(p=e.getRenderTarget(),i.addEventListener("select",Y),i.addEventListener("selectstart",Y),i.addEventListener("selectend",Y),i.addEventListener("squeeze",Y),i.addEventListener("squeezestart",Y),i.addEventListener("squeezeend",Y),i.addEventListener("end",ie),i.addEventListener("inputsourceschange",q),_.xrCompatible!==!0&&await t.makeXRCompatible(),i.renderState.layers===void 0||e.capabilities.isWebGL2===!1){let $={antialias:i.renderState.layers===void 0?_.antialias:!0,alpha:_.alpha,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:s};d=new XRWebGLLayer(i,t,$),i.updateRenderState({baseLayer:d}),f=new ti(d.framebufferWidth,d.framebufferHeight,{format:zn,type:Li,encoding:e.outputEncoding,stencilBuffer:_.stencil})}else{let $=null,_e=null,pe=null;_.depth&&(pe=_.stencil?35056:33190,$=_.stencil?gs:Ci,_e=_.stencil?hs:Ai);let ve={colorFormat:32856,depthFormat:pe,scaleFactor:s};u=new XRWebGLBinding(i,t),l=u.createProjectionLayer(ve),i.updateRenderState({layers:[l]}),f=new ti(l.textureWidth,l.textureHeight,{format:zn,type:Li,depthTexture:new Na(l.textureWidth,l.textureHeight,_e,void 0,void 0,void 0,void 0,void 0,void 0,$),stencilBuffer:_.stencil,encoding:e.outputEncoding,samples:_.antialias?4:0});let te=e.properties.get(f);te.__ignoreDepthValues=l.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(1),c=null,a=await i.requestReferenceSpace(o),ae.setContext(i),ae.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}};function q(ee){for(let $=0;$<ee.removed.length;$++){let _e=ee.removed[$],pe=C.indexOf(_e);pe>=0&&(C[pe]=null,b[pe].disconnect(_e))}for(let $=0;$<ee.added.length;$++){let _e=ee.added[$],pe=C.indexOf(_e);if(pe===-1){for(let te=0;te<b.length;te++)if(te>=C.length){C.push(_e),pe=te;break}else if(C[te]===null){C[te]=_e,pe=te;break}if(pe===-1)break}let ve=b[pe];ve&&ve.connect(_e)}}let B=new R,K=new R;function re(ee,$,_e){B.setFromMatrixPosition($.matrixWorld),K.setFromMatrixPosition(_e.matrixWorld);let pe=B.distanceTo(K),ve=$.projectionMatrix.elements,te=_e.projectionMatrix.elements,Ze=ve[14]/(ve[10]-1),Re=ve[14]/(ve[10]+1),Be=(ve[9]+1)/ve[5],Pe=(ve[9]-1)/ve[5],ft=(ve[8]-1)/ve[0],Je=(te[8]+1)/te[0],Ce=Ze*ft,Dt=Ze*Je,vt=pe/(-ft+Je),Pt=vt*-ft;$.matrixWorld.decompose(ee.position,ee.quaternion,ee.scale),ee.translateX(Pt),ee.translateZ(vt),ee.matrixWorld.compose(ee.position,ee.quaternion,ee.scale),ee.matrixWorldInverse.copy(ee.matrixWorld).invert();let qt=Ze+vt,St=Re+vt,gt=Ce-Pt,ln=Dt+(pe-Pt),Yt=Be*Re/St*qt,L=Pe*Re/St*qt;ee.projectionMatrix.makePerspective(gt,ln,Yt,L,qt,St)}function ue(ee,$){$===null?ee.matrixWorld.copy(ee.matrix):ee.matrixWorld.multiplyMatrices($.matrixWorld,ee.matrix),ee.matrixWorldInverse.copy(ee.matrixWorld).invert()}this.updateCamera=function(ee){if(i===null)return;x.near=N.near=M.near=ee.near,x.far=N.far=M.far=ee.far,(P!==x.near||z!==x.far)&&(i.updateRenderState({depthNear:x.near,depthFar:x.far}),P=x.near,z=x.far);let $=ee.parent,_e=x.cameras;ue(x,$);for(let ve=0;ve<_e.length;ve++)ue(_e[ve],$);x.matrixWorld.decompose(x.position,x.quaternion,x.scale),ee.matrix.copy(x.matrix),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale);let pe=ee.children;for(let ve=0,te=pe.length;ve<te;ve++)pe[ve].updateMatrixWorld(!0);_e.length===2?re(x,M,N):x.projectionMatrix.copy(M.projectionMatrix)},this.getCamera=function(){return x},this.getFoveation=function(){if(l!==null)return l.fixedFoveation;if(d!==null)return d.fixedFoveation},this.setFoveation=function(ee){l!==null&&(l.fixedFoveation=ee),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=ee)},this.getPlanes=function(){return S};let Z=null;function me(ee,$){if(h=$.getViewerPose(c||a),m=$,h!==null){let _e=h.views;d!==null&&(e.setRenderTargetFramebuffer(f,d.framebuffer),e.setRenderTarget(f));let pe=!1;_e.length!==x.cameras.length&&(x.cameras.length=0,pe=!0);for(let ve=0;ve<_e.length;ve++){let te=_e[ve],Ze=null;if(d!==null)Ze=d.getViewport(te);else{let Be=u.getViewSubImage(l,te);Ze=Be.viewport,ve===0&&(e.setRenderTargetTextures(f,Be.colorTexture,l.ignoreDepthValues?void 0:Be.depthStencilTexture),e.setRenderTarget(f))}let Re=k[ve];Re===void 0&&(Re=new rn,Re.layers.enable(ve),Re.viewport=new Xt,k[ve]=Re),Re.matrix.fromArray(te.transform.matrix),Re.projectionMatrix.fromArray(te.projectionMatrix),Re.viewport.set(Ze.x,Ze.y,Ze.width,Ze.height),ve===0&&x.matrix.copy(Re.matrix),pe===!0&&x.cameras.push(Re)}}for(let _e=0;_e<b.length;_e++){let pe=C[_e],ve=b[_e];pe!==null&&ve!==void 0&&ve.update(pe,$,c||a)}if(Z&&Z(ee,$),$.detectedPlanes){n.dispatchEvent({type:"planesdetected",data:$.detectedPlanes});let _e=null;for(let pe of S)$.detectedPlanes.has(pe)||(_e===null&&(_e=[]),_e.push(pe));if(_e!==null)for(let pe of _e)S.delete(pe),y.delete(pe),n.dispatchEvent({type:"planeremoved",data:pe});for(let pe of $.detectedPlanes)if(!S.has(pe))S.add(pe),y.set(pe,$.lastChangedTime),n.dispatchEvent({type:"planeadded",data:pe});else{let ve=y.get(pe);pe.lastChangedTime>ve&&(y.set(pe,pe.lastChangedTime),n.dispatchEvent({type:"planechanged",data:pe}))}}m=null}let ae=new sh;ae.setAnimationLoop(me),this.setAnimationLoop=function(ee){Z=ee},this.dispose=function(){}}};function Cg(r,e){function t(p,f){f.color.getRGB(p.fogColor.value,ih(r)),f.isFog?(p.fogNear.value=f.near,p.fogFar.value=f.far):f.isFogExp2&&(p.fogDensity.value=f.density)}function n(p,f,b,C,S){f.isMeshBasicMaterial||f.isMeshLambertMaterial?i(p,f):f.isMeshToonMaterial?(i(p,f),u(p,f)):f.isMeshPhongMaterial?(i(p,f),h(p,f)):f.isMeshStandardMaterial?(i(p,f),l(p,f),f.isMeshPhysicalMaterial&&d(p,f,S)):f.isMeshMatcapMaterial?(i(p,f),m(p,f)):f.isMeshDepthMaterial?i(p,f):f.isMeshDistanceMaterial?(i(p,f),_(p,f)):f.isMeshNormalMaterial?i(p,f):f.isLineBasicMaterial?(s(p,f),f.isLineDashedMaterial&&a(p,f)):f.isPointsMaterial?o(p,f,b,C):f.isSpriteMaterial?c(p,f):f.isShadowMaterial?(p.color.value.copy(f.color),p.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function i(p,f){p.opacity.value=f.opacity,f.color&&p.diffuse.value.copy(f.color),f.emissive&&p.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(p.map.value=f.map),f.alphaMap&&(p.alphaMap.value=f.alphaMap),f.bumpMap&&(p.bumpMap.value=f.bumpMap,p.bumpScale.value=f.bumpScale,f.side===An&&(p.bumpScale.value*=-1)),f.displacementMap&&(p.displacementMap.value=f.displacementMap,p.displacementScale.value=f.displacementScale,p.displacementBias.value=f.displacementBias),f.emissiveMap&&(p.emissiveMap.value=f.emissiveMap),f.normalMap&&(p.normalMap.value=f.normalMap,p.normalScale.value.copy(f.normalScale),f.side===An&&p.normalScale.value.negate()),f.specularMap&&(p.specularMap.value=f.specularMap),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);let b=e.get(f).envMap;if(b&&(p.envMap.value=b,p.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=f.reflectivity,p.ior.value=f.ior,p.refractionRatio.value=f.refractionRatio),f.lightMap){p.lightMap.value=f.lightMap;let y=r.physicallyCorrectLights!==!0?Math.PI:1;p.lightMapIntensity.value=f.lightMapIntensity*y}f.aoMap&&(p.aoMap.value=f.aoMap,p.aoMapIntensity.value=f.aoMapIntensity);let C;f.map?C=f.map:f.specularMap?C=f.specularMap:f.displacementMap?C=f.displacementMap:f.normalMap?C=f.normalMap:f.bumpMap?C=f.bumpMap:f.roughnessMap?C=f.roughnessMap:f.metalnessMap?C=f.metalnessMap:f.alphaMap?C=f.alphaMap:f.emissiveMap?C=f.emissiveMap:f.clearcoatMap?C=f.clearcoatMap:f.clearcoatNormalMap?C=f.clearcoatNormalMap:f.clearcoatRoughnessMap?C=f.clearcoatRoughnessMap:f.iridescenceMap?C=f.iridescenceMap:f.iridescenceThicknessMap?C=f.iridescenceThicknessMap:f.specularIntensityMap?C=f.specularIntensityMap:f.specularColorMap?C=f.specularColorMap:f.transmissionMap?C=f.transmissionMap:f.thicknessMap?C=f.thicknessMap:f.sheenColorMap?C=f.sheenColorMap:f.sheenRoughnessMap&&(C=f.sheenRoughnessMap),C!==void 0&&(C.isWebGLRenderTarget&&(C=C.texture),C.matrixAutoUpdate===!0&&C.updateMatrix(),p.uvTransform.value.copy(C.matrix));let S;f.aoMap?S=f.aoMap:f.lightMap&&(S=f.lightMap),S!==void 0&&(S.isWebGLRenderTarget&&(S=S.texture),S.matrixAutoUpdate===!0&&S.updateMatrix(),p.uv2Transform.value.copy(S.matrix))}function s(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity}function a(p,f){p.dashSize.value=f.dashSize,p.totalSize.value=f.dashSize+f.gapSize,p.scale.value=f.scale}function o(p,f,b,C){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.size.value=f.size*b,p.scale.value=C*.5,f.map&&(p.map.value=f.map),f.alphaMap&&(p.alphaMap.value=f.alphaMap),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);let S;f.map?S=f.map:f.alphaMap&&(S=f.alphaMap),S!==void 0&&(S.matrixAutoUpdate===!0&&S.updateMatrix(),p.uvTransform.value.copy(S.matrix))}function c(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.rotation.value=f.rotation,f.map&&(p.map.value=f.map),f.alphaMap&&(p.alphaMap.value=f.alphaMap),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);let b;f.map?b=f.map:f.alphaMap&&(b=f.alphaMap),b!==void 0&&(b.matrixAutoUpdate===!0&&b.updateMatrix(),p.uvTransform.value.copy(b.matrix))}function h(p,f){p.specular.value.copy(f.specular),p.shininess.value=Math.max(f.shininess,1e-4)}function u(p,f){f.gradientMap&&(p.gradientMap.value=f.gradientMap)}function l(p,f){p.roughness.value=f.roughness,p.metalness.value=f.metalness,f.roughnessMap&&(p.roughnessMap.value=f.roughnessMap),f.metalnessMap&&(p.metalnessMap.value=f.metalnessMap),e.get(f).envMap&&(p.envMapIntensity.value=f.envMapIntensity)}function d(p,f,b){p.ior.value=f.ior,f.sheen>0&&(p.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),p.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(p.sheenColorMap.value=f.sheenColorMap),f.sheenRoughnessMap&&(p.sheenRoughnessMap.value=f.sheenRoughnessMap)),f.clearcoat>0&&(p.clearcoat.value=f.clearcoat,p.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(p.clearcoatMap.value=f.clearcoatMap),f.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap),f.clearcoatNormalMap&&(p.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),p.clearcoatNormalMap.value=f.clearcoatNormalMap,f.side===An&&p.clearcoatNormalScale.value.negate())),f.iridescence>0&&(p.iridescence.value=f.iridescence,p.iridescenceIOR.value=f.iridescenceIOR,p.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(p.iridescenceMap.value=f.iridescenceMap),f.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=f.iridescenceThicknessMap)),f.transmission>0&&(p.transmission.value=f.transmission,p.transmissionSamplerMap.value=b.texture,p.transmissionSamplerSize.value.set(b.width,b.height),f.transmissionMap&&(p.transmissionMap.value=f.transmissionMap),p.thickness.value=f.thickness,f.thicknessMap&&(p.thicknessMap.value=f.thicknessMap),p.attenuationDistance.value=f.attenuationDistance,p.attenuationColor.value.copy(f.attenuationColor)),p.specularIntensity.value=f.specularIntensity,p.specularColor.value.copy(f.specularColor),f.specularIntensityMap&&(p.specularIntensityMap.value=f.specularIntensityMap),f.specularColorMap&&(p.specularColorMap.value=f.specularColorMap)}function m(p,f){f.matcap&&(p.matcap.value=f.matcap)}function _(p,f){p.referencePosition.value.copy(f.referencePosition),p.nearDistance.value=f.nearDistance,p.farDistance.value=f.farDistance}return{refreshFogUniforms:t,refreshMaterialUniforms:n}}function Pg(r,e,t,n){let i={},s={},a=[],o=t.isWebGL2?r.getParameter(35375):0;function c(C,S){let y=S.program;n.uniformBlockBinding(C,y)}function h(C,S){let y=i[C.id];y===void 0&&(_(C),y=u(C),i[C.id]=y,C.addEventListener("dispose",f));let M=S.program;n.updateUBOMapping(C,M);let N=e.render.frame;s[C.id]!==N&&(d(C),s[C.id]=N)}function u(C){let S=l();C.__bindingPointIndex=S;let y=r.createBuffer(),M=C.__size,N=C.usage;return r.bindBuffer(35345,y),r.bufferData(35345,M,N),r.bindBuffer(35345,null),r.bindBufferBase(35345,S,y),y}function l(){for(let C=0;C<o;C++)if(a.indexOf(C)===-1)return a.push(C),C;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(C){let S=i[C.id],y=C.uniforms,M=C.__cache;r.bindBuffer(35345,S);for(let N=0,k=y.length;N<k;N++){let x=y[N];if(m(x,N,M)===!0){let P=x.value,z=x.__offset;typeof P=="number"?(x.__data[0]=P,r.bufferSubData(35345,z,x.__data)):(x.value.isMatrix3?(x.__data[0]=x.value.elements[0],x.__data[1]=x.value.elements[1],x.__data[2]=x.value.elements[2],x.__data[3]=x.value.elements[0],x.__data[4]=x.value.elements[3],x.__data[5]=x.value.elements[4],x.__data[6]=x.value.elements[5],x.__data[7]=x.value.elements[0],x.__data[8]=x.value.elements[6],x.__data[9]=x.value.elements[7],x.__data[10]=x.value.elements[8],x.__data[11]=x.value.elements[0]):P.toArray(x.__data),r.bufferSubData(35345,z,x.__data))}}r.bindBuffer(35345,null)}function m(C,S,y){let M=C.value;if(y[S]===void 0)return typeof M=="number"?y[S]=M:y[S]=M.clone(),!0;if(typeof M=="number"){if(y[S]!==M)return y[S]=M,!0}else{let N=y[S];if(N.equals(M)===!1)return N.copy(M),!0}return!1}function _(C){let S=C.uniforms,y=0,M=16,N=0;for(let k=0,x=S.length;k<x;k++){let P=S[k],z=p(P);if(P.__data=new Float32Array(z.storage/Float32Array.BYTES_PER_ELEMENT),P.__offset=y,k>0){N=y%M;let Y=M-N;N!==0&&Y-z.boundary<0&&(y+=M-N,P.__offset=y)}y+=z.storage}return N=y%M,N>0&&(y+=M-N),C.__size=y,C.__cache={},this}function p(C){let S=C.value,y={boundary:0,storage:0};return typeof S=="number"?(y.boundary=4,y.storage=4):S.isVector2?(y.boundary=8,y.storage=8):S.isVector3||S.isColor?(y.boundary=16,y.storage=12):S.isVector4?(y.boundary=16,y.storage=16):S.isMatrix3?(y.boundary=48,y.storage=48):S.isMatrix4?(y.boundary=64,y.storage=64):S.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",S),y}function f(C){let S=C.target;S.removeEventListener("dispose",f);let y=a.indexOf(S.__bindingPointIndex);a.splice(y,1),r.deleteBuffer(i[S.id]),delete i[S.id],delete s[S.id]}function b(){for(let C in i)r.deleteBuffer(i[C]);a=[],i={},s={}}return{bind:c,update:h,dispose:b}}function Lg(){let r=qs("canvas");return r.style.display="block",r}function tl(r={}){this.isWebGLRenderer=!0;let e=r.canvas!==void 0?r.canvas:Lg(),t=r.context!==void 0?r.context:null,n=r.depth!==void 0?r.depth:!0,i=r.stencil!==void 0?r.stencil:!0,s=r.antialias!==void 0?r.antialias:!1,a=r.premultipliedAlpha!==void 0?r.premultipliedAlpha:!0,o=r.preserveDrawingBuffer!==void 0?r.preserveDrawingBuffer:!1,c=r.powerPreference!==void 0?r.powerPreference:"default",h=r.failIfMajorPerformanceCaveat!==void 0?r.failIfMajorPerformanceCaveat:!1,u;t!==null?u=t.getContextAttributes().alpha:u=r.alpha!==void 0?r.alpha:!1;let l=null,d=null,m=[],_=[];this.domElement=e,this.debug={checkShaderErrors:!0},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.outputEncoding=Ri,this.physicallyCorrectLights=!1,this.toneMapping=Qn,this.toneMappingExposure=1;let p=this,f=!1,b=0,C=0,S=null,y=-1,M=null,N=new Xt,k=new Xt,x=null,P=e.width,z=e.height,Y=1,ie=null,q=null,B=new Xt(0,0,P,z),K=new Xt(0,0,P,z),re=!1,ue=new Zs,Z=!1,me=!1,ae=null,ee=new Tt,$=new Ve,_e=new R,pe={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function ve(){return S===null?Y:1}let te=t;function Ze(A,H){for(let Q=0;Q<A.length;Q++){let V=A[Q],ne=e.getContext(V,H);if(ne!==null)return ne}return null}try{let A={alpha:!0,depth:n,stencil:i,antialias:s,premultipliedAlpha:a,preserveDrawingBuffer:o,powerPreference:c,failIfMajorPerformanceCaveat:h};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Ka}`),e.addEventListener("webglcontextlost",Oe,!1),e.addEventListener("webglcontextrestored",Ie,!1),e.addEventListener("webglcontextcreationerror",$e,!1),te===null){let H=["webgl2","webgl","experimental-webgl"];if(p.isWebGL1Renderer===!0&&H.shift(),te=Ze(H,A),te===null)throw Ze(H)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}te.getShaderPrecisionFormat===void 0&&(te.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let Re,Be,Pe,ft,Je,Ce,Dt,vt,Pt,qt,St,gt,ln,Yt,L,w,j,le,ge,be,he,I,U,Se;function Ae(){Re=new Kp(te),Be=new Xp(te,Re,r),Re.init(Be),I=new Ag(te,Re,Be),Pe=new Sg(te,Re,Be),ft=new em,Je=new dg,Ce=new Tg(te,Re,Pe,Je,Be,I,ft),Dt=new Yp(p),vt=new $p(p),Pt=new ld(te,Be),U=new Hp(te,Re,Pt,Be),qt=new jp(te,Pt,ft,U),St=new sm(te,qt,Pt,ft),ge=new im(te,Be,Ce),w=new qp(Je),gt=new ug(p,Dt,vt,Re,Be,U,w),ln=new Cg(p,Je),Yt=new pg,L=new vg(Re,Be),le=new Gp(p,Dt,vt,Pe,St,u,a),j=new wg(p,St,Be),Se=new Pg(te,ft,Be,Pe),be=new Wp(te,Re,ft,Be),he=new Qp(te,Re,ft,Be),ft.programs=gt.programs,p.capabilities=Be,p.extensions=Re,p.properties=Je,p.renderLists=Yt,p.shadowMap=j,p.state=Pe,p.info=ft}Ae();let Me=new Oa(p,te);this.xr=Me,this.getContext=function(){return te},this.getContextAttributes=function(){return te.getContextAttributes()},this.forceContextLoss=function(){let A=Re.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){let A=Re.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return Y},this.setPixelRatio=function(A){A!==void 0&&(Y=A,this.setSize(P,z,!1))},this.getSize=function(A){return A.set(P,z)},this.setSize=function(A,H,Q){if(Me.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}P=A,z=H,e.width=Math.floor(A*Y),e.height=Math.floor(H*Y),Q!==!1&&(e.style.width=A+"px",e.style.height=H+"px"),this.setViewport(0,0,A,H)},this.getDrawingBufferSize=function(A){return A.set(P*Y,z*Y).floor()},this.setDrawingBufferSize=function(A,H,Q){P=A,z=H,Y=Q,e.width=Math.floor(A*Q),e.height=Math.floor(H*Q),this.setViewport(0,0,A,H)},this.getCurrentViewport=function(A){return A.copy(N)},this.getViewport=function(A){return A.copy(B)},this.setViewport=function(A,H,Q,V){A.isVector4?B.set(A.x,A.y,A.z,A.w):B.set(A,H,Q,V),Pe.viewport(N.copy(B).multiplyScalar(Y).floor())},this.getScissor=function(A){return A.copy(K)},this.setScissor=function(A,H,Q,V){A.isVector4?K.set(A.x,A.y,A.z,A.w):K.set(A,H,Q,V),Pe.scissor(k.copy(K).multiplyScalar(Y).floor())},this.getScissorTest=function(){return re},this.setScissorTest=function(A){Pe.setScissorTest(re=A)},this.setOpaqueSort=function(A){ie=A},this.setTransparentSort=function(A){q=A},this.getClearColor=function(A){return A.copy(le.getClearColor())},this.setClearColor=function(){le.setClearColor.apply(le,arguments)},this.getClearAlpha=function(){return le.getClearAlpha()},this.setClearAlpha=function(){le.setClearAlpha.apply(le,arguments)},this.clear=function(A=!0,H=!0,Q=!0){let V=0;A&&(V|=16384),H&&(V|=256),Q&&(V|=1024),te.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Oe,!1),e.removeEventListener("webglcontextrestored",Ie,!1),e.removeEventListener("webglcontextcreationerror",$e,!1),Yt.dispose(),L.dispose(),Je.dispose(),Dt.dispose(),vt.dispose(),St.dispose(),U.dispose(),Se.dispose(),gt.dispose(),Me.dispose(),Me.removeEventListener("sessionstart",Te),Me.removeEventListener("sessionend",Ne),ae&&(ae.dispose(),ae=null),ot.stop()};function Oe(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),f=!0}function Ie(){console.log("THREE.WebGLRenderer: Context Restored."),f=!1;let A=ft.autoReset,H=j.enabled,Q=j.autoUpdate,V=j.needsUpdate,ne=j.type;Ae(),ft.autoReset=A,j.enabled=H,j.autoUpdate=Q,j.needsUpdate=V,j.type=ne}function $e(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function rt(A){let H=A.target;H.removeEventListener("dispose",rt),dt(H)}function dt(A){F(A),Je.remove(A)}function F(A){let H=Je.get(A).programs;H!==void 0&&(H.forEach(function(Q){gt.releaseProgram(Q)}),A.isShaderMaterial&&gt.releaseShaderCache(A))}this.renderBufferDirect=function(A,H,Q,V,ne,ke){H===null&&(H=pe);let Ge=ne.isMesh&&ne.matrixWorld.determinant()<0,je=or(A,H,Q,V,ne);Pe.setMaterial(V,Ge);let Qe=Q.index,tt=1;V.wireframe===!0&&(Qe=qt.getWireframeAttribute(Q),tt=2);let He=Q.drawRange,st=Q.attributes.position,Lt=He.start*tt,Qt=(He.start+He.count)*tt;ke!==null&&(Lt=Math.max(Lt,ke.start*tt),Qt=Math.min(Qt,(ke.start+ke.count)*tt)),Qe!==null?(Lt=Math.max(Lt,0),Qt=Math.min(Qt,Qe.count)):st!=null&&(Lt=Math.max(Lt,0),Qt=Math.min(Qt,st.count));let Pn=Qt-Lt;if(Pn<0||Pn===1/0)return;U.setup(ne,V,je,Q,Qe);let kn,Rt=be;if(Qe!==null&&(kn=Pt.get(Qe),Rt=he,Rt.setIndex(kn)),ne.isMesh)V.wireframe===!0?(Pe.setLineWidth(V.wireframeLinewidth*ve()),Rt.setMode(1)):Rt.setMode(4);else if(ne.isLine){let at=V.linewidth;at===void 0&&(at=1),Pe.setLineWidth(at*ve()),ne.isLineSegments?Rt.setMode(1):ne.isLineLoop?Rt.setMode(2):Rt.setMode(3)}else ne.isPoints?Rt.setMode(0):ne.isSprite&&Rt.setMode(4);if(ne.isInstancedMesh)Rt.renderInstances(Lt,Pn,ne.count);else if(Q.isInstancedBufferGeometry){let at=Q._maxInstanceCount!==void 0?Q._maxInstanceCount:1/0,Zt=Math.min(Q.instanceCount,at);Rt.renderInstances(Lt,Pn,Zt)}else Rt.render(Lt,Pn)},this.compile=function(A,H){function Q(V,ne,ke){V.transparent===!0&&V.side===fn?(V.side=An,V.needsUpdate=!0,pn(V,ne,ke),V.side=fs,V.needsUpdate=!0,pn(V,ne,ke),V.side=fn):pn(V,ne,ke)}d=L.get(A),d.init(),_.push(d),A.traverseVisible(function(V){V.isLight&&V.layers.test(H.layers)&&(d.pushLight(V),V.castShadow&&d.pushShadow(V))}),d.setupLights(p.physicallyCorrectLights),A.traverse(function(V){let ne=V.material;if(ne)if(Array.isArray(ne))for(let ke=0;ke<ne.length;ke++){let Ge=ne[ke];Q(Ge,A,V)}else Q(ne,A,V)}),_.pop(),d=null};let J=null;function de(A){J&&J(A)}function Te(){ot.stop()}function Ne(){ot.start()}let ot=new sh;ot.setAnimationLoop(de),typeof self!="undefined"&&ot.setContext(self),this.setAnimationLoop=function(A){J=A,Me.setAnimationLoop(A),A===null?ot.stop():ot.start()},Me.addEventListener("sessionstart",Te),Me.addEventListener("sessionend",Ne),this.render=function(A,H){if(H!==void 0&&H.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(f===!0)return;A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),H.parent===null&&H.matrixWorldAutoUpdate===!0&&H.updateMatrixWorld(),Me.enabled===!0&&Me.isPresenting===!0&&(Me.cameraAutoUpdate===!0&&Me.updateCamera(H),H=Me.getCamera()),A.isScene===!0&&A.onBeforeRender(p,A,H,S),d=L.get(A,_.length),d.init(),_.push(d),ee.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),ue.setFromProjectionMatrix(ee),me=this.localClippingEnabled,Z=w.init(this.clippingPlanes,me,H),l=Yt.get(A,m.length),l.init(),m.push(l),Nt(A,H,0,p.sortObjects),l.finish(),p.sortObjects===!0&&l.sort(ie,q),Z===!0&&w.beginShadows();let Q=d.state.shadowsArray;if(j.render(Q,A,H),Z===!0&&w.endShadows(),this.info.autoReset===!0&&this.info.reset(),le.render(l,A),d.setupLights(p.physicallyCorrectLights),H.isArrayCamera){let V=H.cameras;for(let ne=0,ke=V.length;ne<ke;ne++){let Ge=V[ne];Ht(l,A,Ge,Ge.viewport)}}else Ht(l,A,H);S!==null&&(Ce.updateMultisampleRenderTarget(S),Ce.updateRenderTargetMipmap(S)),A.isScene===!0&&A.onAfterRender(p,A,H),U.resetDefaultState(),y=-1,M=null,_.pop(),_.length>0?d=_[_.length-1]:d=null,m.pop(),m.length>0?l=m[m.length-1]:l=null};function Nt(A,H,Q,V){if(A.visible===!1)return;if(A.layers.test(H.layers)){if(A.isGroup)Q=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(H);else if(A.isLight)d.pushLight(A),A.castShadow&&d.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||ue.intersectsSprite(A)){V&&_e.setFromMatrixPosition(A.matrixWorld).applyMatrix4(ee);let Ge=St.update(A),je=A.material;je.visible&&l.push(A,Ge,je,Q,_e.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(A.isSkinnedMesh&&A.skeleton.frame!==ft.render.frame&&(A.skeleton.update(),A.skeleton.frame=ft.render.frame),!A.frustumCulled||ue.intersectsObject(A))){V&&_e.setFromMatrixPosition(A.matrixWorld).applyMatrix4(ee);let Ge=St.update(A),je=A.material;if(Array.isArray(je)){let Qe=Ge.groups;for(let tt=0,He=Qe.length;tt<He;tt++){let st=Qe[tt],Lt=je[st.materialIndex];Lt&&Lt.visible&&l.push(A,Ge,Lt,Q,_e.z,st)}}else je.visible&&l.push(A,Ge,je,Q,_e.z,null)}}let ke=A.children;for(let Ge=0,je=ke.length;Ge<je;Ge++)Nt(ke[Ge],H,Q,V)}function Ht(A,H,Q,V){let ne=A.opaque,ke=A.transmissive,Ge=A.transparent;d.setupLightsView(Q),ke.length>0&&Hn(ne,H,Q),V&&Pe.viewport(N.copy(V)),ne.length>0&&it(ne,H,Q),ke.length>0&&it(ke,H,Q),Ge.length>0&&it(Ge,H,Q),Pe.buffers.depth.setTest(!0),Pe.buffers.depth.setMask(!0),Pe.buffers.color.setMask(!0),Pe.setPolygonOffset(!1)}function Hn(A,H,Q){let V=Be.isWebGL2;ae===null&&(ae=new ti(1,1,{generateMipmaps:!0,type:Re.has("EXT_color_buffer_half_float")?Ws:Li,minFilter:bo,samples:V&&s===!0?4:0})),p.getDrawingBufferSize($),V?ae.setSize($.x,$.y):ae.setSize($r($.x),$r($.y));let ne=p.getRenderTarget();p.setRenderTarget(ae),p.clear();let ke=p.toneMapping;p.toneMapping=Qn,it(A,H,Q),p.toneMapping=ke,Ce.updateMultisampleRenderTarget(ae),Ce.updateRenderTargetMipmap(ae),p.setRenderTarget(ne)}function it(A,H,Q){let V=H.isScene===!0?H.overrideMaterial:null;for(let ne=0,ke=A.length;ne<ke;ne++){let Ge=A[ne],je=Ge.object,Qe=Ge.geometry,tt=V===null?Ge.material:V,He=Ge.group;je.layers.test(Q.layers)&&Mn(je,H,Q,Qe,tt,He)}}function Mn(A,H,Q,V,ne,ke){A.onBeforeRender(p,H,Q,V,ne,ke),A.modelViewMatrix.multiplyMatrices(Q.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),ne.onBeforeRender(p,H,Q,V,A,ke),ne.transparent===!0&&ne.side===fn?(ne.side=An,ne.needsUpdate=!0,p.renderBufferDirect(Q,H,V,ne,A,ke),ne.side=fs,ne.needsUpdate=!0,p.renderBufferDirect(Q,H,V,ne,A,ke),ne.side=fn):p.renderBufferDirect(Q,H,V,ne,A,ke),A.onAfterRender(p,H,Q,V,ne,ke)}function pn(A,H,Q){H.isScene!==!0&&(H=pe);let V=Je.get(A),ne=d.state.lights,ke=d.state.shadowsArray,Ge=ne.state.version,je=gt.getParameters(A,ne.state,ke,H,Q),Qe=gt.getProgramCacheKey(je),tt=V.programs;V.environment=A.isMeshStandardMaterial?H.environment:null,V.fog=H.fog,V.envMap=(A.isMeshStandardMaterial?vt:Dt).get(A.envMap||V.environment),tt===void 0&&(A.addEventListener("dispose",rt),tt=new Map,V.programs=tt);let He=tt.get(Qe);if(He!==void 0){if(V.currentProgram===He&&V.lightsStateVersion===Ge)return Ss(A,je),He}else je.uniforms=gt.getUniforms(A),A.onBuild(Q,je,p),A.onBeforeCompile(je,p),He=gt.acquireProgram(je,Qe),tt.set(Qe,He),V.uniforms=je.uniforms;let st=V.uniforms;(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(st.clippingPlanes=w.uniform),Ss(A,je),V.needsLights=ar(A),V.lightsStateVersion=Ge,V.needsLights&&(st.ambientLightColor.value=ne.state.ambient,st.lightProbe.value=ne.state.probe,st.directionalLights.value=ne.state.directional,st.directionalLightShadows.value=ne.state.directionalShadow,st.spotLights.value=ne.state.spot,st.spotLightShadows.value=ne.state.spotShadow,st.rectAreaLights.value=ne.state.rectArea,st.ltc_1.value=ne.state.rectAreaLTC1,st.ltc_2.value=ne.state.rectAreaLTC2,st.pointLights.value=ne.state.point,st.pointLightShadows.value=ne.state.pointShadow,st.hemisphereLights.value=ne.state.hemi,st.directionalShadowMap.value=ne.state.directionalShadowMap,st.directionalShadowMatrix.value=ne.state.directionalShadowMatrix,st.spotShadowMap.value=ne.state.spotShadowMap,st.spotLightMatrix.value=ne.state.spotLightMatrix,st.spotLightMap.value=ne.state.spotLightMap,st.pointShadowMap.value=ne.state.pointShadowMap,st.pointShadowMatrix.value=ne.state.pointShadowMatrix);let Lt=He.getUniforms(),Qt=ds.seqWithValue(Lt.seq,st);return V.currentProgram=He,V.uniformsList=Qt,He}function Ss(A,H){let Q=Je.get(A);Q.outputEncoding=H.outputEncoding,Q.instancing=H.instancing,Q.skinning=H.skinning,Q.morphTargets=H.morphTargets,Q.morphNormals=H.morphNormals,Q.morphColors=H.morphColors,Q.morphTargetsCount=H.morphTargetsCount,Q.numClippingPlanes=H.numClippingPlanes,Q.numIntersection=H.numClipIntersection,Q.vertexAlphas=H.vertexAlphas,Q.vertexTangents=H.vertexTangents,Q.toneMapping=H.toneMapping}function or(A,H,Q,V,ne){H.isScene!==!0&&(H=pe),Ce.resetTextureUnits();let ke=H.fog,Ge=V.isMeshStandardMaterial?H.environment:null,je=S===null?p.outputEncoding:S.isXRRenderTarget===!0?S.texture.encoding:Ri,Qe=(V.isMeshStandardMaterial?vt:Dt).get(V.envMap||Ge),tt=V.vertexColors===!0&&!!Q.attributes.color&&Q.attributes.color.itemSize===4,He=!!V.normalMap&&!!Q.attributes.tangent,st=!!Q.morphAttributes.position,Lt=!!Q.morphAttributes.normal,Qt=!!Q.morphAttributes.color,Pn=V.toneMapped?p.toneMapping:Qn,kn=Q.morphAttributes.position||Q.morphAttributes.normal||Q.morphAttributes.color,Rt=kn!==void 0?kn.length:0,at=Je.get(V),Zt=d.state.lights;if(Z===!0&&(me===!0||A!==M)){let bt=A===M&&V.id===y;w.setState(V,A,bt)}let xt=!1;V.version===at.__version?(at.needsLights&&at.lightsStateVersion!==Zt.state.version||at.outputEncoding!==je||ne.isInstancedMesh&&at.instancing===!1||!ne.isInstancedMesh&&at.instancing===!0||ne.isSkinnedMesh&&at.skinning===!1||!ne.isSkinnedMesh&&at.skinning===!0||at.envMap!==Qe||V.fog===!0&&at.fog!==ke||at.numClippingPlanes!==void 0&&(at.numClippingPlanes!==w.numPlanes||at.numIntersection!==w.numIntersection)||at.vertexAlphas!==tt||at.vertexTangents!==He||at.morphTargets!==st||at.morphNormals!==Lt||at.morphColors!==Qt||at.toneMapping!==Pn||Be.isWebGL2===!0&&at.morphTargetsCount!==Rt)&&(xt=!0):(xt=!0,at.__version=V.version);let Wn=at.currentProgram;xt===!0&&(Wn=pn(V,H,ne));let lr=!1,xi=!1,_i=!1,Ft=Wn.getUniforms(),Bn=at.uniforms;if(Pe.useProgram(Wn.program)&&(lr=!0,xi=!0,_i=!0),V.id!==y&&(y=V.id,xi=!0),lr||M!==A){if(Ft.setValue(te,"projectionMatrix",A.projectionMatrix),Be.logarithmicDepthBuffer&&Ft.setValue(te,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),M!==A&&(M=A,xi=!0,_i=!0),V.isShaderMaterial||V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshStandardMaterial||V.envMap){let bt=Ft.map.cameraPosition;bt!==void 0&&bt.setValue(te,_e.setFromMatrixPosition(A.matrixWorld))}(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&Ft.setValue(te,"isOrthographic",A.isOrthographicCamera===!0),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial||V.isShadowMaterial||ne.isSkinnedMesh)&&Ft.setValue(te,"viewMatrix",A.matrixWorldInverse)}if(ne.isSkinnedMesh){Ft.setOptional(te,ne,"bindMatrix"),Ft.setOptional(te,ne,"bindMatrixInverse");let bt=ne.skeleton;bt&&(Be.floatVertexTextures?(bt.boneTexture===null&&bt.computeBoneTexture(),Ft.setValue(te,"boneTexture",bt.boneTexture,Ce),Ft.setValue(te,"boneTextureSize",bt.boneTextureSize)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}let Ts=Q.morphAttributes;if((Ts.position!==void 0||Ts.normal!==void 0||Ts.color!==void 0&&Be.isWebGL2===!0)&&ge.update(ne,Q,V,Wn),(xi||at.receiveShadow!==ne.receiveShadow)&&(at.receiveShadow=ne.receiveShadow,Ft.setValue(te,"receiveShadow",ne.receiveShadow)),V.isMeshGouraudMaterial&&V.envMap!==null&&(Bn.envMap.value=Qe,Bn.flipEnvMap.value=Qe.isCubeTexture&&Qe.isRenderTargetTexture===!1?-1:1),xi&&(Ft.setValue(te,"toneMappingExposure",p.toneMappingExposure),at.needsLights&&To(Bn,_i),ke&&V.fog===!0&&ln.refreshFogUniforms(Bn,ke),ln.refreshMaterialUniforms(Bn,V,Y,z,ae),ds.upload(te,at.uniformsList,Bn,Ce)),V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(ds.upload(te,at.uniformsList,Bn,Ce),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&Ft.setValue(te,"center",ne.center),Ft.setValue(te,"modelViewMatrix",ne.modelViewMatrix),Ft.setValue(te,"normalMatrix",ne.normalMatrix),Ft.setValue(te,"modelMatrix",ne.matrixWorld),V.isShaderMaterial||V.isRawShaderMaterial){let bt=V.uniformsGroups;for(let Ln=0,Xn=bt.length;Ln<Xn;Ln++)if(Be.isWebGL2){let cr=bt[Ln];Se.update(cr,Wn),Se.bind(cr,Wn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Wn}function To(A,H){A.ambientLightColor.needsUpdate=H,A.lightProbe.needsUpdate=H,A.directionalLights.needsUpdate=H,A.directionalLightShadows.needsUpdate=H,A.pointLights.needsUpdate=H,A.pointLightShadows.needsUpdate=H,A.spotLights.needsUpdate=H,A.spotLightShadows.needsUpdate=H,A.rectAreaLights.needsUpdate=H,A.hemisphereLights.needsUpdate=H}function ar(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return b},this.getActiveMipmapLevel=function(){return C},this.getRenderTarget=function(){return S},this.setRenderTargetTextures=function(A,H,Q){Je.get(A.texture).__webglTexture=H,Je.get(A.depthTexture).__webglTexture=Q;let V=Je.get(A);V.__hasExternalTextures=!0,V.__hasExternalTextures&&(V.__autoAllocateDepthBuffer=Q===void 0,V.__autoAllocateDepthBuffer||Re.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),V.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(A,H){let Q=Je.get(A);Q.__webglFramebuffer=H,Q.__useDefaultFramebuffer=H===void 0},this.setRenderTarget=function(A,H=0,Q=0){S=A,b=H,C=Q;let V=!0,ne=null,ke=!1,Ge=!1;if(A){let Qe=Je.get(A);Qe.__useDefaultFramebuffer!==void 0?(Pe.bindFramebuffer(36160,null),V=!1):Qe.__webglFramebuffer===void 0?Ce.setupRenderTarget(A):Qe.__hasExternalTextures&&Ce.rebindTextures(A,Je.get(A.texture).__webglTexture,Je.get(A.depthTexture).__webglTexture);let tt=A.texture;(tt.isData3DTexture||tt.isDataArrayTexture||tt.isCompressedArrayTexture)&&(Ge=!0);let He=Je.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(ne=He[H],ke=!0):Be.isWebGL2&&A.samples>0&&Ce.useMultisampledRTT(A)===!1?ne=Je.get(A).__webglMultisampledFramebuffer:ne=He,N.copy(A.viewport),k.copy(A.scissor),x=A.scissorTest}else N.copy(B).multiplyScalar(Y).floor(),k.copy(K).multiplyScalar(Y).floor(),x=re;if(Pe.bindFramebuffer(36160,ne)&&Be.drawBuffers&&V&&Pe.drawBuffers(A,ne),Pe.viewport(N),Pe.scissor(k),Pe.setScissorTest(x),ke){let Qe=Je.get(A.texture);te.framebufferTexture2D(36160,36064,34069+H,Qe.__webglTexture,Q)}else if(Ge){let Qe=Je.get(A.texture),tt=H||0;te.framebufferTextureLayer(36160,36064,Qe.__webglTexture,Q||0,tt)}y=-1},this.readRenderTargetPixels=function(A,H,Q,V,ne,ke,Ge){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let je=Je.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Ge!==void 0&&(je=je[Ge]),je){Pe.bindFramebuffer(36160,je);try{let Qe=A.texture,tt=Qe.format,He=Qe.type;if(tt!==zn&&I.convert(tt)!==te.getParameter(35739)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let st=He===Ws&&(Re.has("EXT_color_buffer_half_float")||Be.isWebGL2&&Re.has("EXT_color_buffer_float"));if(He!==Li&&I.convert(He)!==te.getParameter(35738)&&!(He===Ei&&(Be.isWebGL2||Re.has("OES_texture_float")||Re.has("WEBGL_color_buffer_float")))&&!st){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}H>=0&&H<=A.width-V&&Q>=0&&Q<=A.height-ne&&te.readPixels(H,Q,V,ne,I.convert(tt),I.convert(He),ke)}finally{let Qe=S!==null?Je.get(S).__webglFramebuffer:null;Pe.bindFramebuffer(36160,Qe)}}},this.copyFramebufferToTexture=function(A,H,Q=0){let V=Math.pow(2,-Q),ne=Math.floor(H.image.width*V),ke=Math.floor(H.image.height*V);Ce.setTexture2D(H,0),te.copyTexSubImage2D(3553,Q,0,0,A.x,A.y,ne,ke),Pe.unbindTexture()},this.copyTextureToTexture=function(A,H,Q,V=0){let ne=H.image.width,ke=H.image.height,Ge=I.convert(Q.format),je=I.convert(Q.type);Ce.setTexture2D(Q,0),te.pixelStorei(37440,Q.flipY),te.pixelStorei(37441,Q.premultiplyAlpha),te.pixelStorei(3317,Q.unpackAlignment),H.isDataTexture?te.texSubImage2D(3553,V,A.x,A.y,ne,ke,Ge,je,H.image.data):H.isCompressedTexture?te.compressedTexSubImage2D(3553,V,A.x,A.y,H.mipmaps[0].width,H.mipmaps[0].height,Ge,H.mipmaps[0].data):te.texSubImage2D(3553,V,A.x,A.y,Ge,je,H.image),V===0&&Q.generateMipmaps&&te.generateMipmap(3553),Pe.unbindTexture()},this.copyTextureToTexture3D=function(A,H,Q,V,ne=0){if(p.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let ke=A.max.x-A.min.x+1,Ge=A.max.y-A.min.y+1,je=A.max.z-A.min.z+1,Qe=I.convert(V.format),tt=I.convert(V.type),He;if(V.isData3DTexture)Ce.setTexture3D(V,0),He=32879;else if(V.isDataArrayTexture)Ce.setTexture2DArray(V,0),He=35866;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}te.pixelStorei(37440,V.flipY),te.pixelStorei(37441,V.premultiplyAlpha),te.pixelStorei(3317,V.unpackAlignment);let st=te.getParameter(3314),Lt=te.getParameter(32878),Qt=te.getParameter(3316),Pn=te.getParameter(3315),kn=te.getParameter(32877),Rt=Q.isCompressedTexture?Q.mipmaps[0]:Q.image;te.pixelStorei(3314,Rt.width),te.pixelStorei(32878,Rt.height),te.pixelStorei(3316,A.min.x),te.pixelStorei(3315,A.min.y),te.pixelStorei(32877,A.min.z),Q.isDataTexture||Q.isData3DTexture?te.texSubImage3D(He,ne,H.x,H.y,H.z,ke,Ge,je,Qe,tt,Rt.data):Q.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),te.compressedTexSubImage3D(He,ne,H.x,H.y,H.z,ke,Ge,je,Qe,Rt.data)):te.texSubImage3D(He,ne,H.x,H.y,H.z,ke,Ge,je,Qe,tt,Rt),te.pixelStorei(3314,st),te.pixelStorei(32878,Lt),te.pixelStorei(3316,Qt),te.pixelStorei(3315,Pn),te.pixelStorei(32877,kn),ne===0&&V.generateMipmaps&&te.generateMipmap(He),Pe.unbindTexture()},this.initTexture=function(A){A.isCubeTexture?Ce.setTextureCube(A,0):A.isData3DTexture?Ce.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?Ce.setTexture2DArray(A,0):Ce.setTexture2D(A,0),Pe.unbindTexture()},this.resetState=function(){b=0,C=0,S=null,Pe.reset(),U.reset()},typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}var za=class extends tl{};za.prototype.isWebGL1Renderer=!0;var lo=class extends Jt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.backgroundIntensity=this.backgroundIntensity),t}get autoUpdate(){return console.warn("THREE.Scene: autoUpdate was renamed to matrixWorldAutoUpdate in r144."),this.matrixWorldAutoUpdate}set autoUpdate(e){console.warn("THREE.Scene: autoUpdate was renamed to matrixWorldAutoUpdate in r144."),this.matrixWorldAutoUpdate=e}},co=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=ya,this.updateRange={offset:0,count:-1},this.version=0,this.uuid=ei()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let i=0,s=this.stride;i<s;i++)this.array[e+i]=t.array[n+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ei()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ei()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},tn=new R,Js=class r{constructor(e,t,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=i===!0}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)tn.fromBufferAttribute(this,t),tn.applyMatrix4(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)tn.fromBufferAttribute(this,t),tn.applyNormalMatrix(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)tn.fromBufferAttribute(this,t),tn.transformDirection(e),this.setXYZ(t,tn.x,tn.y,tn.z);return this}setX(e,t){return this.normalized&&(t=wt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=wt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=wt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=wt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=jn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=jn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=jn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=jn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array),i=wt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=wt(t,this.array),n=wt(n,this.array),i=wt(i,this.array),s=wt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return new jt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new r(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},ys=class extends ni{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new pt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},is,Os=new R,ss=new R,rs=new R,os=new Ve,zs=new Ve,ch=new Tt,Ur=new R,Fs=new R,Vr=new R,kc=new Ve,ua=new Ve,Bc=new Ve,$s=class extends Jt{constructor(e){if(super(),this.isSprite=!0,this.type="Sprite",is===void 0){is=new zt;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new co(t,5);is.setIndex([0,1,2,0,2,3]),is.setAttribute("position",new Js(n,3,0,!1)),is.setAttribute("uv",new Js(n,2,3,!1))}this.geometry=is,this.material=e!==void 0?e:new ys,this.center=new Ve(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),ss.setFromMatrixScale(this.matrixWorld),ch.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),rs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&ss.multiplyScalar(-rs.z);let n=this.material.rotation,i,s;n!==0&&(s=Math.cos(n),i=Math.sin(n));let a=this.center;Gr(Ur.set(-.5,-.5,0),rs,a,ss,i,s),Gr(Fs.set(.5,-.5,0),rs,a,ss,i,s),Gr(Vr.set(.5,.5,0),rs,a,ss,i,s),kc.set(0,0),ua.set(1,0),Bc.set(1,1);let o=e.ray.intersectTriangle(Ur,Fs,Vr,!1,Os);if(o===null&&(Gr(Fs.set(-.5,.5,0),rs,a,ss,i,s),ua.set(0,1),o=e.ray.intersectTriangle(Ur,Vr,Fs,!1,Os),o===null))return;let c=e.ray.origin.distanceTo(Os);c<e.near||c>e.far||t.push({distance:c,point:Os.clone(),uv:us.getUV(Os,Ur,Fs,Vr,kc,ua,Bc,new Ve),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function Gr(r,e,t,n,i,s){os.subVectors(r,t).addScalar(.5).multiply(n),i!==void 0?(zs.x=s*os.x-i*os.y,zs.y=i*os.x+s*os.y):zs.copy(os),r.copy(e),r.x+=zs.x,r.y+=zs.y,r.applyMatrix4(ch)}var Ks=class extends jt{constructor(e,t,n,i=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Uc=new Tt,Vc=new Tt,Hr=[],Rg=new Tt,ks=new ut,vs=class extends ut{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Ks(new Float32Array(n*16),16),this.instanceColor=null,this.count=n,this.frustumCulled=!1;for(let i=0;i<n;i++)this.setMatrixAt(i,Rg)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){let n=this.matrixWorld,i=this.count;if(ks.geometry=this.geometry,ks.material=this.material,ks.material!==void 0)for(let s=0;s<i;s++){this.getMatrixAt(s,Uc),Vc.multiplyMatrices(n,Uc),ks.matrixWorld=Vc,ks.raycast(e,Hr);for(let a=0,o=Hr.length;a<o;a++){let c=Hr[a];c.instanceId=s,c.object=this,t.push(c)}Hr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Ks(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}},bs=class extends ni{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new pt(16777215),this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Gc=new R,Hc=new R,Wc=new Tt,da=new eo,Wr=new xs,Fa=class extends Jt{constructor(e=new zt,t=new bs){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let i=1,s=t.count;i<s;i++)Gc.fromBufferAttribute(t,i-1),Hc.fromBufferAttribute(t,i),n[i]=n[i-1],n[i]+=Gc.distanceTo(Hc);e.setAttribute("lineDistance",new mt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let n=this.geometry,i=this.matrixWorld,s=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Wr.copy(n.boundingSphere),Wr.applyMatrix4(i),Wr.radius+=s,e.ray.intersectsSphere(Wr)===!1)return;Wc.copy(i).invert(),da.copy(e.ray).applyMatrix4(Wc);let o=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=o*o,h=new R,u=new R,l=new R,d=new R,m=this.isLineSegments?2:1,_=n.index,f=n.attributes.position;if(_!==null){let b=Math.max(0,a.start),C=Math.min(_.count,a.start+a.count);for(let S=b,y=C-1;S<y;S+=m){let M=_.getX(S),N=_.getX(S+1);if(h.fromBufferAttribute(f,M),u.fromBufferAttribute(f,N),da.distanceSqToSegment(h,u,d,l)>c)continue;d.applyMatrix4(this.matrixWorld);let x=e.ray.origin.distanceTo(d);x<e.near||x>e.far||t.push({distance:x,point:l.clone().applyMatrix4(this.matrixWorld),index:S,face:null,faceIndex:null,object:this})}}else{let b=Math.max(0,a.start),C=Math.min(f.count,a.start+a.count);for(let S=b,y=C-1;S<y;S+=m){if(h.fromBufferAttribute(f,S),u.fromBufferAttribute(f,S+1),da.distanceSqToSegment(h,u,d,l)>c)continue;d.applyMatrix4(this.matrixWorld);let N=e.ray.origin.distanceTo(d);N<e.near||N>e.far||t.push({distance:N,point:l.clone().applyMatrix4(this.matrixWorld),index:S,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=i.length;s<a;s++){let o=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}},Xc=new R,qc=new R,js=class extends Fa{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let i=0,s=t.count;i<s;i+=2)Xc.fromBufferAttribute(t,i),qc.fromBufferAttribute(t,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Xc.distanceTo(qc);e.setAttribute("lineDistance",new mt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var Qs=class extends an{constructor(e,t,n,i,s,a,o,c,h){super(e,t,n,i,s,a,o,c,h),this.isCanvasTexture=!0,this.needsUpdate=!0}};var er=class r extends zt{constructor(e=1,t=8,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:i},t=Math.max(3,t);let s=[],a=[],o=[],c=[],h=new R,u=new Ve;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let l=0,d=3;l<=t;l++,d+=3){let m=n+l/t*i;h.x=e*Math.cos(m),h.y=e*Math.sin(m),a.push(h.x,h.y,h.z),o.push(0,0,1),u.x=(a[d]/e+1)/2,u.y=(a[d+1]/e+1)/2,c.push(u.x,u.y)}for(let l=1;l<=t;l++)s.push(l,l+1,0);this.setIndex(s),this.setAttribute("position",new mt(a,3)),this.setAttribute("normal",new mt(o,3)),this.setAttribute("uv",new mt(c,2))}static fromJSON(e){return new r(e.radius,e.segments,e.thetaStart,e.thetaLength)}},vn=class r extends zt{constructor(e=1,t=1,n=1,i=8,s=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:i,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:c};let h=this;i=Math.floor(i),s=Math.floor(s);let u=[],l=[],d=[],m=[],_=0,p=[],f=n/2,b=0;C(),a===!1&&(e>0&&S(!0),t>0&&S(!1)),this.setIndex(u),this.setAttribute("position",new mt(l,3)),this.setAttribute("normal",new mt(d,3)),this.setAttribute("uv",new mt(m,2));function C(){let y=new R,M=new R,N=0,k=(t-e)/n;for(let x=0;x<=s;x++){let P=[],z=x/s,Y=z*(t-e)+e;for(let ie=0;ie<=i;ie++){let q=ie/i,B=q*c+o,K=Math.sin(B),re=Math.cos(B);M.x=Y*K,M.y=-z*n+f,M.z=Y*re,l.push(M.x,M.y,M.z),y.set(K,k,re).normalize(),d.push(y.x,y.y,y.z),m.push(q,1-z),P.push(_++)}p.push(P)}for(let x=0;x<i;x++)for(let P=0;P<s;P++){let z=p[P][x],Y=p[P+1][x],ie=p[P+1][x+1],q=p[P][x+1];u.push(z,Y,q),u.push(Y,ie,q),N+=6}h.addGroup(b,N,0),b+=N}function S(y){let M=_,N=new Ve,k=new R,x=0,P=y===!0?e:t,z=y===!0?1:-1;for(let ie=1;ie<=i;ie++)l.push(0,f*z,0),d.push(0,z,0),m.push(.5,.5),_++;let Y=_;for(let ie=0;ie<=i;ie++){let B=ie/i*c+o,K=Math.cos(B),re=Math.sin(B);k.x=P*re,k.y=f*z,k.z=P*K,l.push(k.x,k.y,k.z),d.push(0,z,0),N.x=K*.5+.5,N.y=re*.5*z+.5,m.push(N.x,N.y),_++}for(let ie=0;ie<i;ie++){let q=M+ie,B=Y+ie;y===!0?u.push(B,B+1,q):u.push(B+1,B,q),x+=3}h.addGroup(b,x,y===!0?1:2),b+=x}}static fromJSON(e){return new r(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},ho=class r extends vn{constructor(e=1,t=1,n=8,i=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,n,i,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:i,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new r(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},ka=class r extends zt{constructor(e=[],t=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:i};let s=[],a=[];o(i),h(n),u(),this.setAttribute("position",new mt(s,3)),this.setAttribute("normal",new mt(s.slice(),3)),this.setAttribute("uv",new mt(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(C){let S=new R,y=new R,M=new R;for(let N=0;N<t.length;N+=3)m(t[N+0],S),m(t[N+1],y),m(t[N+2],M),c(S,y,M,C)}function c(C,S,y,M){let N=M+1,k=[];for(let x=0;x<=N;x++){k[x]=[];let P=C.clone().lerp(y,x/N),z=S.clone().lerp(y,x/N),Y=N-x;for(let ie=0;ie<=Y;ie++)ie===0&&x===N?k[x][ie]=P:k[x][ie]=P.clone().lerp(z,ie/Y)}for(let x=0;x<N;x++)for(let P=0;P<2*(N-x)-1;P++){let z=Math.floor(P/2);P%2===0?(d(k[x][z+1]),d(k[x+1][z]),d(k[x][z])):(d(k[x][z+1]),d(k[x+1][z+1]),d(k[x+1][z]))}}function h(C){let S=new R;for(let y=0;y<s.length;y+=3)S.x=s[y+0],S.y=s[y+1],S.z=s[y+2],S.normalize().multiplyScalar(C),s[y+0]=S.x,s[y+1]=S.y,s[y+2]=S.z}function u(){let C=new R;for(let S=0;S<s.length;S+=3){C.x=s[S+0],C.y=s[S+1],C.z=s[S+2];let y=f(C)/2/Math.PI+.5,M=b(C)/Math.PI+.5;a.push(y,1-M)}_(),l()}function l(){for(let C=0;C<a.length;C+=6){let S=a[C+0],y=a[C+2],M=a[C+4],N=Math.max(S,y,M),k=Math.min(S,y,M);N>.9&&k<.1&&(S<.2&&(a[C+0]+=1),y<.2&&(a[C+2]+=1),M<.2&&(a[C+4]+=1))}}function d(C){s.push(C.x,C.y,C.z)}function m(C,S){let y=C*3;S.x=e[y+0],S.y=e[y+1],S.z=e[y+2]}function _(){let C=new R,S=new R,y=new R,M=new R,N=new Ve,k=new Ve,x=new Ve;for(let P=0,z=0;P<s.length;P+=9,z+=6){C.set(s[P+0],s[P+1],s[P+2]),S.set(s[P+3],s[P+4],s[P+5]),y.set(s[P+6],s[P+7],s[P+8]),N.set(a[z+0],a[z+1]),k.set(a[z+2],a[z+3]),x.set(a[z+4],a[z+5]),M.copy(C).add(S).add(y).divideScalar(3);let Y=f(M);p(N,z+0,C,Y),p(k,z+2,S,Y),p(x,z+4,y,Y)}}function p(C,S,y,M){M<0&&C.x===1&&(a[S]=C.x-1),y.x===0&&y.z===0&&(a[S]=M/2/Math.PI+.5)}function f(C){return Math.atan2(C.z,-C.x)}function b(C){return Math.atan2(-C.y,Math.sqrt(C.x*C.x+C.z*C.z))}}static fromJSON(e){return new r(e.vertices,e.indices,e.radius,e.details)}};var uo=class r extends ka{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new r(e.radius,e.detail)}};var tr=class r extends zt{constructor(e=.5,t=1,n=8,i=1,s=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:i,thetaStart:s,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);let o=[],c=[],h=[],u=[],l=e,d=(t-e)/i,m=new R,_=new Ve;for(let p=0;p<=i;p++){for(let f=0;f<=n;f++){let b=s+f/n*a;m.x=l*Math.cos(b),m.y=l*Math.sin(b),c.push(m.x,m.y,m.z),h.push(0,0,1),_.x=(m.x/t+1)/2,_.y=(m.y/t+1)/2,u.push(_.x,_.y)}l+=d}for(let p=0;p<i;p++){let f=p*(n+1);for(let b=0;b<n;b++){let C=b+f,S=C,y=C+n+1,M=C+n+2,N=C+1;o.push(S,y,N),o.push(y,M,N)}}this.setIndex(o),this.setAttribute("position",new mt(c,3)),this.setAttribute("normal",new mt(h,3)),this.setAttribute("uv",new mt(u,2))}static fromJSON(e){return new r(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}};var nr=class r extends zt{constructor(e=1,t=.4,n=8,i=6,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);let a=[],o=[],c=[],h=[],u=new R,l=new R,d=new R;for(let m=0;m<=n;m++)for(let _=0;_<=i;_++){let p=_/i*s,f=m/n*Math.PI*2;l.x=(e+t*Math.cos(f))*Math.cos(p),l.y=(e+t*Math.cos(f))*Math.sin(p),l.z=t*Math.sin(f),o.push(l.x,l.y,l.z),u.x=e*Math.cos(p),u.y=e*Math.sin(p),d.subVectors(l,u).normalize(),c.push(d.x,d.y,d.z),h.push(_/i),h.push(m/n)}for(let m=1;m<=n;m++)for(let _=1;_<=i;_++){let p=(i+1)*m+_-1,f=(i+1)*(m-1)+_-1,b=(i+1)*(m-1)+_,C=(i+1)*m+_;a.push(p,f,C),a.push(f,b,C)}this.setIndex(a),this.setAttribute("position",new mt(o,3)),this.setAttribute("normal",new mt(c,3)),this.setAttribute("uv",new mt(h,2))}static fromJSON(e){return new r(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}};var En=class extends ni{constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new pt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new pt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=eh,this.normalScale=new Ve(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};function mi(r,e,t){return hh(r)?new r.constructor(r.subarray(e,t!==void 0?t:r.length)):r.slice(e,t)}function Xr(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function hh(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}var Ms=class{constructor(e,t,n,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,i=t[n],s=t[n-1];n:{e:{let a;t:{i:if(!(e<i)){for(let o=n+2;;){if(i===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(s=i,i=t[++n],e<i)break e}a=t.length;break t}if(!(e>=s)){let o=t[1];e<o&&(n=2,s=o);for(let c=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===c)break;if(i=s,s=t[--n-1],e>=s)break e}a=n,n=0;break t}break n}for(;n<a;){let o=n+a>>>1;e<t[o]?a=o:n=o+1}if(i=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,i)}return this.interpolate_(n,s,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i;for(let a=0;a!==i;++a)t[a]=n[s+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Ba=class extends Ms{constructor(e,t,n,i){super(e,t,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:nc,endingEnd:nc}}intervalChanged_(e,t,n){let i=this.parameterPositions,s=e-2,a=e+1,o=i[s],c=i[a];if(o===void 0)switch(this.getSettings_().endingStart){case ic:s=e,o=2*t-n;break;case sc:s=i.length-2,o=t+i[s]-i[s+1];break;default:s=e,o=n}if(c===void 0)switch(this.getSettings_().endingEnd){case ic:a=e,c=2*n-t;break;case sc:a=1,c=n+i[1]-i[0];break;default:a=e-1,c=t}let h=(n-t)*.5,u=this.valueSize;this._weightPrev=h/(t-o),this._weightNext=h/(c-n),this._offsetPrev=s*u,this._offsetNext=a*u}interpolate_(e,t,n,i){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,h=c-o,u=this._offsetPrev,l=this._offsetNext,d=this._weightPrev,m=this._weightNext,_=(n-t)/(i-t),p=_*_,f=p*_,b=-d*f+2*d*p-d*_,C=(1+d)*f+(-1.5-2*d)*p+(-.5+d)*_+1,S=(-1-m)*f+(1.5+m)*p+.5*_,y=m*f-m*p;for(let M=0;M!==o;++M)s[M]=b*a[u+M]+C*a[h+M]+S*a[c+M]+y*a[l+M];return s}},Ua=class extends Ms{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=e*o,h=c-o,u=(n-t)/(i-t),l=1-u;for(let d=0;d!==o;++d)s[d]=a[h+d]*l+a[c+d]*u;return s}},Va=class extends Ms{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e){return this.copySampleValue_(e-1)}},Fn=class{constructor(e,t,n,i){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Xr(t,this.TimeBufferType),this.values=Xr(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Xr(e.times,Array),values:Xr(e.values,Array)};let i=e.getInterpolation();i!==e.DefaultInterpolation&&(n.interpolation=i)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Va(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Ua(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Ba(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case Yr:t=this.InterpolantFactoryMethodDiscrete;break;case Zr:t=this.InterpolantFactoryMethodLinear;break;case ko:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Yr;case this.InterpolantFactoryMethodLinear:return Zr;case this.InterpolantFactoryMethodSmooth:return ko}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]*=e}return this}trim(e,t){let n=this.times,i=n.length,s=0,a=i-1;for(;s!==i&&n[s]<e;)++s;for(;a!==-1&&n[a]>t;)--a;if(++a,s!==0||a!==i){s>=a&&(a=Math.max(a,1),s=a-1);let o=this.getValueSize();this.times=mi(n,s,a),this.values=mi(this.values,s*o,a*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,i=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==s;o++){let c=n[o];if(typeof c=="number"&&isNaN(c)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,c),e=!1;break}if(a!==null&&a>c){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,c,a),e=!1;break}a=c}if(i!==void 0&&hh(i))for(let o=0,c=i.length;o!==c;++o){let h=i[o];if(isNaN(h)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,h),e=!1;break}}return e}optimize(){let e=mi(this.times),t=mi(this.values),n=this.getValueSize(),i=this.getInterpolation()===ko,s=e.length-1,a=1;for(let o=1;o<s;++o){let c=!1,h=e[o],u=e[o+1];if(h!==u&&(o!==1||h!==e[0]))if(i)c=!0;else{let l=o*n,d=l-n,m=l+n;for(let _=0;_!==n;++_){let p=t[l+_];if(p!==t[d+_]||p!==t[m+_]){c=!0;break}}}if(c){if(o!==a){e[a]=e[o];let l=o*n,d=a*n;for(let m=0;m!==n;++m)t[d+m]=t[l+m]}++a}}if(s>0){e[a]=e[s];for(let o=s*n,c=a*n,h=0;h!==n;++h)t[c+h]=t[o+h];++a}return a!==e.length?(this.times=mi(e,0,a),this.values=mi(t,0,a*n)):(this.times=e,this.values=t),this}clone(){let e=mi(this.times,0),t=mi(this.values,0),n=this.constructor,i=new n(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};Fn.prototype.TimeBufferType=Float32Array;Fn.prototype.ValueBufferType=Float32Array;Fn.prototype.DefaultInterpolation=Zr;var Di=class extends Fn{};Di.prototype.ValueTypeName="bool";Di.prototype.ValueBufferType=Array;Di.prototype.DefaultInterpolation=Yr;Di.prototype.InterpolantFactoryMethodLinear=void 0;Di.prototype.InterpolantFactoryMethodSmooth=void 0;var Ga=class extends Fn{};Ga.prototype.ValueTypeName="color";var Ha=class extends Fn{};Ha.prototype.ValueTypeName="number";var Wa=class extends Ms{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){let s=this.resultBuffer,a=this.sampleValues,o=this.valueSize,c=(n-t)/(i-t),h=e*o;for(let u=h+o;h!==u;h+=4)yn.slerpFlat(s,0,a,h-o,a,h,c);return s}},ir=class extends Fn{InterpolantFactoryMethodLinear(e){return new Wa(this.times,this.values,this.getValueSize(),e)}};ir.prototype.ValueTypeName="quaternion";ir.prototype.DefaultInterpolation=Zr;ir.prototype.InterpolantFactoryMethodSmooth=void 0;var Ni=class extends Fn{};Ni.prototype.ValueTypeName="string";Ni.prototype.ValueBufferType=Array;Ni.prototype.DefaultInterpolation=Yr;Ni.prototype.InterpolantFactoryMethodLinear=void 0;Ni.prototype.InterpolantFactoryMethodSmooth=void 0;var Xa=class extends Fn{};Xa.prototype.ValueTypeName="vector";var fo={enabled:!1,files:{},add:function(r,e){this.enabled!==!1&&(this.files[r]=e)},get:function(r){if(this.enabled!==!1)return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}},qa=class{constructor(e,t,n){let i=this,s=!1,a=0,o=0,c,h=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(u){o++,s===!1&&i.onStart!==void 0&&i.onStart(u,a,o),s=!0},this.itemEnd=function(u){a++,i.onProgress!==void 0&&i.onProgress(u,a,o),a===o&&(s=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(u){i.onError!==void 0&&i.onError(u)},this.resolveURL=function(u){return c?c(u):u},this.setURLModifier=function(u){return c=u,this},this.addHandler=function(u,l){return h.push(u,l),this},this.removeHandler=function(u){let l=h.indexOf(u);return l!==-1&&h.splice(l,2),this},this.getHandler=function(u){for(let l=0,d=h.length;l<d;l+=2){let m=h[l],_=h[l+1];if(m.global&&(m.lastIndex=0),m.test(u))return _}return null}}},Ig=new qa,sr=class{constructor(e){this.manager=e!==void 0?e:Ig,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let n=this;return new Promise(function(i,s){n.load(e,i,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};var Ya=class extends sr{constructor(e){super(e)}load(e,t,n,i){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=this,a=fo.get(e);if(a!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0),a;let o=qs("img");function c(){u(),fo.add(e,this),t&&t(this),s.manager.itemEnd(e)}function h(l){u(),i&&i(l),s.manager.itemError(e),s.manager.itemEnd(e)}function u(){o.removeEventListener("load",c,!1),o.removeEventListener("error",h,!1)}return o.addEventListener("load",c,!1),o.addEventListener("error",h,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(o.crossOrigin=this.crossOrigin),s.manager.itemStart(e),o.src=e,o}};var po=class extends sr{constructor(e){super(e)}load(e,t,n,i){let s=new an,a=new Ya(this.manager);return a.setCrossOrigin(this.crossOrigin),a.setPath(this.path),a.load(e,function(o){s.image=o,s.needsUpdate=!0,t!==void 0&&t(s)},n,i),s}},mo=class extends Jt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new pt(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}},go=class extends mo{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Jt.DefaultUp),this.updateMatrix(),this.groundColor=new pt(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},fa=new Tt,Yc=new R,Zc=new R,Za=class{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ve(512,512),this.map=null,this.mapPass=null,this.matrix=new Tt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Zs,this._frameExtents=new Ve(1,1),this._viewportCount=1,this._viewports=[new Xt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,n=this.matrix;Yc.setFromMatrixPosition(e.matrixWorld),t.position.copy(Yc),Zc.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Zc),t.updateMatrixWorld(),fa.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(fa),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(fa)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}};var Ja=class extends Za{constructor(){super(new oo(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},xo=class extends mo{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Jt.DefaultUp),this.updateMatrix(),this.target=new Jt,this.shadow=new Ja}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var _o=class extends sr{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap=="undefined"&&console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch=="undefined"&&console.warn("THREE.ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"}}setOptions(e){return this.options=e,this}load(e,t,n,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=this,a=fo.get(e);if(a!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(a),s.manager.itemEnd(e)},0),a;let o={};o.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",o.headers=this.requestHeader,fetch(e,o).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign(s.options,{colorSpaceConversion:"none"}))}).then(function(c){fo.add(e,c),t&&t(c),s.manager.itemEnd(e)}).catch(function(c){i&&i(c),s.manager.itemError(e),s.manager.itemEnd(e)}),s.manager.itemStart(e)}};var nl="\\[\\]\\.:\\/",Dg=new RegExp("["+nl+"]","g"),il="[^"+nl+"]",Ng="[^"+nl.replace("\\.","")+"]",Og=/((?:WC+[\/:])*)/.source.replace("WC",il),zg=/(WCOD+)?/.source.replace("WCOD",Ng),Fg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",il),kg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",il),Bg=new RegExp("^"+Og+zg+Fg+kg+"$"),Ug=["material","materials","bones","map"],$a=class{constructor(e,t,n){let i=n||Ct.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,s=n.length;i!==s;++i)n[i].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},Ct=class r{constructor(e,t,n){this.path=t,this.parsedPath=n||r.parseTrackName(t),this.node=r.findNode(e,this.parsedPath.nodeName)||e,this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new r.Composite(e,t,n):new r(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Dg,"")}static parseTrackName(e){let t=Bg.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let s=n.nodeName.substring(i+1);Ug.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(s){for(let a=0;a<s.length;a++){let o=s[a];if(o.name===t||o.uuid===t)return o;let c=n(o.children);if(c)return c}return null},i=n(e.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)e[t++]=n[i]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,i=t.propertyName,s=t.propertyIndex;if(e||(e=r.findNode(this.rootNode,t.nodeName)||this.rootNode,this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.error("THREE.PropertyBinding: Trying to update node for track: "+this.path+" but it wasn't found.");return}if(n){let h=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let u=0;u<e.length;u++)if(e[u].name===h){h=u;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(h!==void 0){if(e[h]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[h]}}let a=e[i];if(a===void 0){let h=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+h+"."+i+" but it wasn't found.",e);return}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(s!==void 0){if(i==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}c=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=s}else a.fromArray!==void 0&&a.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(c=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Ct.Composite=$a;Ct.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Ct.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Ct.prototype.GetterByBindingType=[Ct.prototype._getValue_direct,Ct.prototype._getValue_array,Ct.prototype._getValue_arrayElement,Ct.prototype._getValue_toArray];Ct.prototype.SetterByBindingTypeAndVersioning=[[Ct.prototype._setValue_direct,Ct.prototype._setValue_direct_setNeedsUpdate,Ct.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_array,Ct.prototype._setValue_array_setNeedsUpdate,Ct.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_arrayElement,Ct.prototype._setValue_arrayElement_setNeedsUpdate,Ct.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_fromArray,Ct.prototype._setValue_fromArray_setNeedsUpdate,Ct.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Xg=new Float32Array(1);var rr=class{constructor(e=1,t=0,n=0){return this.radius=e,this.phi=t,this.theta=n,this}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(sn(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__!="undefined"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ka}}));typeof window!="undefined"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ka);var uh={type:"change"},sl={type:"start"},dh={type:"end"},wo=class extends Gn{constructor(e,t){super(),this.object=e,this.domElement=t,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new R,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Oi.ROTATE,MIDDLE:Oi.DOLLY,RIGHT:Oi.PAN},this.touches={ONE:zi.ROTATE,TWO:zi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return o.phi},this.getAzimuthalAngle=function(){return o.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(I){I.addEventListener("keydown",Yt),this._domElementKeyEvents=I},this.saveState=function(){n.target0.copy(n.target),n.position0.copy(n.object.position),n.zoom0=n.object.zoom},this.reset=function(){n.target.copy(n.target0),n.object.position.copy(n.position0),n.object.zoom=n.zoom0,n.object.updateProjectionMatrix(),n.dispatchEvent(uh),n.update(),s=i.NONE},this.update=function(){let I=new R,U=new yn().setFromUnitVectors(e.up,new R(0,1,0)),Se=U.clone().invert(),Ae=new R,Me=new yn,Oe=2*Math.PI;return function(){let $e=n.object.position;I.copy($e).sub(n.target),I.applyQuaternion(U),o.setFromVector3(I),n.autoRotate&&s===i.NONE&&P(k()),n.enableDamping?(o.theta+=c.theta*n.dampingFactor,o.phi+=c.phi*n.dampingFactor):(o.theta+=c.theta,o.phi+=c.phi);let rt=n.minAzimuthAngle,dt=n.maxAzimuthAngle;return isFinite(rt)&&isFinite(dt)&&(rt<-Math.PI?rt+=Oe:rt>Math.PI&&(rt-=Oe),dt<-Math.PI?dt+=Oe:dt>Math.PI&&(dt-=Oe),rt<=dt?o.theta=Math.max(rt,Math.min(dt,o.theta)):o.theta=o.theta>(rt+dt)/2?Math.max(rt,o.theta):Math.min(dt,o.theta)),o.phi=Math.max(n.minPolarAngle,Math.min(n.maxPolarAngle,o.phi)),o.makeSafe(),o.radius*=h,o.radius=Math.max(n.minDistance,Math.min(n.maxDistance,o.radius)),n.enableDamping===!0?n.target.addScaledVector(u,n.dampingFactor):n.target.add(u),I.setFromSpherical(o),I.applyQuaternion(Se),$e.copy(n.target).add(I),n.object.lookAt(n.target),n.enableDamping===!0?(c.theta*=1-n.dampingFactor,c.phi*=1-n.dampingFactor,u.multiplyScalar(1-n.dampingFactor)):(c.set(0,0,0),u.set(0,0,0)),h=1,l||Ae.distanceToSquared(n.object.position)>a||8*(1-Me.dot(n.object.quaternion))>a?(n.dispatchEvent(uh),Ae.copy(n.object.position),Me.copy(n.object.quaternion),l=!1,!0):!1}}(),this.dispose=function(){n.domElement.removeEventListener("contextmenu",j),n.domElement.removeEventListener("pointerdown",Dt),n.domElement.removeEventListener("pointercancel",qt),n.domElement.removeEventListener("wheel",ln),n.domElement.removeEventListener("pointermove",vt),n.domElement.removeEventListener("pointerup",Pt),n._domElementKeyEvents!==null&&n._domElementKeyEvents.removeEventListener("keydown",Yt)};let n=this,i={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},s=i.NONE,a=1e-6,o=new rr,c=new rr,h=1,u=new R,l=!1,d=new Ve,m=new Ve,_=new Ve,p=new Ve,f=new Ve,b=new Ve,C=new Ve,S=new Ve,y=new Ve,M=[],N={};function k(){return 2*Math.PI/60/60*n.autoRotateSpeed}function x(){return Math.pow(.95,n.zoomSpeed)}function P(I){c.theta-=I}function z(I){c.phi-=I}let Y=function(){let I=new R;return function(Se,Ae){I.setFromMatrixColumn(Ae,0),I.multiplyScalar(-Se),u.add(I)}}(),ie=function(){let I=new R;return function(Se,Ae){n.screenSpacePanning===!0?I.setFromMatrixColumn(Ae,1):(I.setFromMatrixColumn(Ae,0),I.crossVectors(n.object.up,I)),I.multiplyScalar(Se),u.add(I)}}(),q=function(){let I=new R;return function(Se,Ae){let Me=n.domElement;if(n.object.isPerspectiveCamera){let Oe=n.object.position;I.copy(Oe).sub(n.target);let Ie=I.length();Ie*=Math.tan(n.object.fov/2*Math.PI/180),Y(2*Se*Ie/Me.clientHeight,n.object.matrix),ie(2*Ae*Ie/Me.clientHeight,n.object.matrix)}else n.object.isOrthographicCamera?(Y(Se*(n.object.right-n.object.left)/n.object.zoom/Me.clientWidth,n.object.matrix),ie(Ae*(n.object.top-n.object.bottom)/n.object.zoom/Me.clientHeight,n.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),n.enablePan=!1)}}();function B(I){n.object.isPerspectiveCamera?h/=I:n.object.isOrthographicCamera?(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom*I)),n.object.updateProjectionMatrix(),l=!0):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function K(I){n.object.isPerspectiveCamera?h*=I:n.object.isOrthographicCamera?(n.object.zoom=Math.max(n.minZoom,Math.min(n.maxZoom,n.object.zoom/I)),n.object.updateProjectionMatrix(),l=!0):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),n.enableZoom=!1)}function re(I){d.set(I.clientX,I.clientY)}function ue(I){C.set(I.clientX,I.clientY)}function Z(I){p.set(I.clientX,I.clientY)}function me(I){m.set(I.clientX,I.clientY),_.subVectors(m,d).multiplyScalar(n.rotateSpeed);let U=n.domElement;P(2*Math.PI*_.x/U.clientHeight),z(2*Math.PI*_.y/U.clientHeight),d.copy(m),n.update()}function ae(I){S.set(I.clientX,I.clientY),y.subVectors(S,C),y.y>0?B(x()):y.y<0&&K(x()),C.copy(S),n.update()}function ee(I){f.set(I.clientX,I.clientY),b.subVectors(f,p).multiplyScalar(n.panSpeed),q(b.x,b.y),p.copy(f),n.update()}function $(I){I.deltaY<0?K(x()):I.deltaY>0&&B(x()),n.update()}function _e(I){let U=!1;switch(I.code){case n.keys.UP:I.ctrlKey||I.metaKey||I.shiftKey?z(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):q(0,n.keyPanSpeed),U=!0;break;case n.keys.BOTTOM:I.ctrlKey||I.metaKey||I.shiftKey?z(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):q(0,-n.keyPanSpeed),U=!0;break;case n.keys.LEFT:I.ctrlKey||I.metaKey||I.shiftKey?P(2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):q(n.keyPanSpeed,0),U=!0;break;case n.keys.RIGHT:I.ctrlKey||I.metaKey||I.shiftKey?P(-2*Math.PI*n.rotateSpeed/n.domElement.clientHeight):q(-n.keyPanSpeed,0),U=!0;break}U&&(I.preventDefault(),n.update())}function pe(){if(M.length===1)d.set(M[0].pageX,M[0].pageY);else{let I=.5*(M[0].pageX+M[1].pageX),U=.5*(M[0].pageY+M[1].pageY);d.set(I,U)}}function ve(){if(M.length===1)p.set(M[0].pageX,M[0].pageY);else{let I=.5*(M[0].pageX+M[1].pageX),U=.5*(M[0].pageY+M[1].pageY);p.set(I,U)}}function te(){let I=M[0].pageX-M[1].pageX,U=M[0].pageY-M[1].pageY,Se=Math.sqrt(I*I+U*U);C.set(0,Se)}function Ze(){n.enableZoom&&te(),n.enablePan&&ve()}function Re(){n.enableZoom&&te(),n.enableRotate&&pe()}function Be(I){if(M.length==1)m.set(I.pageX,I.pageY);else{let Se=he(I),Ae=.5*(I.pageX+Se.x),Me=.5*(I.pageY+Se.y);m.set(Ae,Me)}_.subVectors(m,d).multiplyScalar(n.rotateSpeed);let U=n.domElement;P(2*Math.PI*_.x/U.clientHeight),z(2*Math.PI*_.y/U.clientHeight),d.copy(m)}function Pe(I){if(M.length===1)f.set(I.pageX,I.pageY);else{let U=he(I),Se=.5*(I.pageX+U.x),Ae=.5*(I.pageY+U.y);f.set(Se,Ae)}b.subVectors(f,p).multiplyScalar(n.panSpeed),q(b.x,b.y),p.copy(f)}function ft(I){let U=he(I),Se=I.pageX-U.x,Ae=I.pageY-U.y,Me=Math.sqrt(Se*Se+Ae*Ae);S.set(0,Me),y.set(0,Math.pow(S.y/C.y,n.zoomSpeed)),B(y.y),C.copy(S)}function Je(I){n.enableZoom&&ft(I),n.enablePan&&Pe(I)}function Ce(I){n.enableZoom&&ft(I),n.enableRotate&&Be(I)}function Dt(I){n.enabled!==!1&&(M.length===0&&(n.domElement.setPointerCapture(I.pointerId),n.domElement.addEventListener("pointermove",vt),n.domElement.addEventListener("pointerup",Pt)),le(I),I.pointerType==="touch"?L(I):St(I))}function vt(I){n.enabled!==!1&&(I.pointerType==="touch"?w(I):gt(I))}function Pt(I){ge(I),M.length===0&&(n.domElement.releasePointerCapture(I.pointerId),n.domElement.removeEventListener("pointermove",vt),n.domElement.removeEventListener("pointerup",Pt)),n.dispatchEvent(dh),s=i.NONE}function qt(I){ge(I)}function St(I){let U;switch(I.button){case 0:U=n.mouseButtons.LEFT;break;case 1:U=n.mouseButtons.MIDDLE;break;case 2:U=n.mouseButtons.RIGHT;break;default:U=-1}switch(U){case Oi.DOLLY:if(n.enableZoom===!1)return;ue(I),s=i.DOLLY;break;case Oi.ROTATE:if(I.ctrlKey||I.metaKey||I.shiftKey){if(n.enablePan===!1)return;Z(I),s=i.PAN}else{if(n.enableRotate===!1)return;re(I),s=i.ROTATE}break;case Oi.PAN:if(I.ctrlKey||I.metaKey||I.shiftKey){if(n.enableRotate===!1)return;re(I),s=i.ROTATE}else{if(n.enablePan===!1)return;Z(I),s=i.PAN}break;default:s=i.NONE}s!==i.NONE&&n.dispatchEvent(sl)}function gt(I){switch(s){case i.ROTATE:if(n.enableRotate===!1)return;me(I);break;case i.DOLLY:if(n.enableZoom===!1)return;ae(I);break;case i.PAN:if(n.enablePan===!1)return;ee(I);break}}function ln(I){n.enabled===!1||n.enableZoom===!1||s!==i.NONE||(I.preventDefault(),n.dispatchEvent(sl),$(I),n.dispatchEvent(dh))}function Yt(I){n.enabled===!1||n.enablePan===!1||_e(I)}function L(I){switch(be(I),M.length){case 1:switch(n.touches.ONE){case zi.ROTATE:if(n.enableRotate===!1)return;pe(),s=i.TOUCH_ROTATE;break;case zi.PAN:if(n.enablePan===!1)return;ve(),s=i.TOUCH_PAN;break;default:s=i.NONE}break;case 2:switch(n.touches.TWO){case zi.DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Ze(),s=i.TOUCH_DOLLY_PAN;break;case zi.DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;Re(),s=i.TOUCH_DOLLY_ROTATE;break;default:s=i.NONE}break;default:s=i.NONE}s!==i.NONE&&n.dispatchEvent(sl)}function w(I){switch(be(I),s){case i.TOUCH_ROTATE:if(n.enableRotate===!1)return;Be(I),n.update();break;case i.TOUCH_PAN:if(n.enablePan===!1)return;Pe(I),n.update();break;case i.TOUCH_DOLLY_PAN:if(n.enableZoom===!1&&n.enablePan===!1)return;Je(I),n.update();break;case i.TOUCH_DOLLY_ROTATE:if(n.enableZoom===!1&&n.enableRotate===!1)return;Ce(I),n.update();break;default:s=i.NONE}}function j(I){n.enabled!==!1&&I.preventDefault()}function le(I){M.push(I)}function ge(I){delete N[I.pointerId];for(let U=0;U<M.length;U++)if(M[U].pointerId==I.pointerId){M.splice(U,1);return}}function be(I){let U=N[I.pointerId];U===void 0&&(U=new Ve,N[I.pointerId]=U),U.set(I.pageX,I.pageY)}function he(I){let U=I.pointerId===M[0].pointerId?M[1]:M[0];return N[U.pointerId]}n.domElement.addEventListener("contextmenu",j),n.domElement.addEventListener("pointerdown",Dt),n.domElement.addEventListener("pointercancel",qt),n.domElement.addEventListener("wheel",ln,{passive:!1}),this.update()}};function ph(r,e=!1){let t=r[0].index!==null,n=new Set(Object.keys(r[0].attributes)),i=new Set(Object.keys(r[0].morphAttributes)),s={},a={},o=r[0].morphTargetsRelative,c=new zt,h=0;for(let u=0;u<r.length;++u){let l=r[u],d=0;if(t!==(l.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let m in l.attributes){if(!n.has(m))return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+'. All geometries must have compatible attributes; make sure "'+m+'" attribute exists among all geometries, or in none of them.'),null;s[m]===void 0&&(s[m]=[]),s[m].push(l.attributes[m]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+". Make sure all geometries have the same number of attributes."),null;if(o!==l.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let m in l.morphAttributes){if(!i.has(m))return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+".  .morphAttributes must be consistent throughout all geometries."),null;a[m]===void 0&&(a[m]=[]),a[m].push(l.morphAttributes[m])}if(e){let m;if(t)m=l.index.count;else if(l.attributes.position!==void 0)m=l.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed with geometry at index "+u+". The geometry must have either an index or a position attribute"),null;c.addGroup(h,m,u),h+=m}}if(t){let u=0,l=[];for(let d=0;d<r.length;++d){let m=r[d].index;for(let _=0;_<m.count;++_)l.push(m.getX(_)+u);u+=r[d].attributes.position.count}c.setIndex(l)}for(let u in s){let l=fh(s[u]);if(!l)return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed while trying to merge the "+u+" attribute."),null;c.setAttribute(u,l)}for(let u in a){let l=a[u][0].length;if(l===0)break;c.morphAttributes=c.morphAttributes||{},c.morphAttributes[u]=[];for(let d=0;d<l;++d){let m=[];for(let p=0;p<a[u].length;++p)m.push(a[u][p][d]);let _=fh(m);if(!_)return console.error("THREE.BufferGeometryUtils: .mergeBufferGeometries() failed while trying to merge the "+u+" morphAttribute."),null;c.morphAttributes[u].push(_)}}return c}function fh(r){let e,t,n,i=0;for(let o=0;o<r.length;++o){let c=r[o];if(c.isInterleavedBufferAttribute)return console.error("THREE.BufferGeometryUtils: .mergeBufferAttributes() failed. InterleavedBufferAttributes are not supported."),null;if(e===void 0&&(e=c.array.constructor),e!==c.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeBufferAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=c.itemSize),t!==c.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeBufferAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=c.normalized),n!==c.normalized)return console.error("THREE.BufferGeometryUtils: .mergeBufferAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;i+=c.array.length}let s=new e(i),a=0;for(let o=0;o<r.length;++o)s.set(r[o].array,a),a+=r[o].array.length;return new jt(s,t,n)}var Fi=[{key:"\u0421\u043A\u043B\u0435\u0439\u043A\u0430 (SW)",short:"\u0421\u043A\u043B\u0435\u0439\u043A\u0430",color:"#D3922A",mode:"stick",what:"\u0442\u0451\u043C\u043D\u044B\u0439 \u043D\u0435\u043F\u0440\u043E\u0432\u0430\u0440, \u0448\u043F\u0438\u043B\u044C\u043A\u0430 \u0441 \u043D\u0430\u043A\u043B\u043E\u043D\u043E\u043C"},{key:"\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442",short:"\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442",color:"#CF4339",mode:"missing",what:"\u043F\u0443\u0441\u0442\u043E\u0435 \u043C\u0435\u0441\u0442\u043E, \u043A\u043E\u043D\u0442\u0443\u0440 \u0448\u043F\u0438\u043B\u044C\u043A\u0438"},{key:"\u0421\u043B\u043E\u043C\u0430\u043D\u0430 \u043F\u043E \u0440\u0435\u0437\u044C\u0431\u0435",short:"\u0421\u043B\u043E\u043C\u0430\u043D\u0430 \u043F\u043E \u0440\u0435\u0437\u044C\u0431\u0435",color:"#7652C4",mode:"broken",what:"\u043E\u0431\u0440\u044B\u0432 \u043F\u043E \u0440\u0435\u0437\u044C\u0431\u0435, \u043A\u0443\u0441\u043E\u043A \u0440\u044F\u0434\u043E\u043C"},{key:"\u041F\u043E\u0433\u043D\u0443\u0442\u0430",short:"\u041F\u043E\u0433\u043D\u0443\u0442\u0430",color:"#0E9C82",mode:"bent",what:"\u0441\u0442\u0435\u0440\u0436\u0435\u043D\u044C \u0438\u0437\u043E\u0433\u043D\u0443\u0442"},{key:"\u0421\u043E\u0440\u0432\u0430\u043D\u0430 (\u0441\u0432\u0430\u0440\u043A\u0430 \u043E\u043A)",short:"\u0421\u043E\u0440\u0432\u0430\u043D\u0430",color:"#3570BF",mode:"torn",what:"\u0441\u043E\u0440\u0432\u0430\u043D\u0430, \u043F\u044F\u0442\u043D\u043E \u0441\u0432\u0430\u0440\u043A\u0438 \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C"},{key:"\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E",short:"\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E",color:"#8A8F97",mode:"unknown",what:"\u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u0430"}],oi=Object.fromEntries(Fi.map(r=>[r.key,r])),oe=r=>document.getElementById(r),fe=(r,e,t)=>{let n=document.createElement(r);return e&&(n.className=e),t!==void 0&&(n.textContent=t),n},So=r=>r.slice(8,10)+"."+r.slice(5,7),Cn=r=>(r===0?"0":r<1?r.toLocaleString("ru-RU",{maximumSignificantDigits:2}):r.toLocaleString("ru-RU",{maximumFractionDigits:1}))+"%",mh=r=>r.body_no||"?"+r.date,Vg="http://www.w3.org/2000/svg",$t=(r,e,t)=>{let n=document.createElementNS(Vg,r);for(let i in e)n.setAttribute(i,e[i]);return t&&t.appendChild(n),n},yt=r=>String(r).replace(/\B(?=(\d{3})+(?!\d))/g,"\xA0"),gh=matchMedia("(prefers-reduced-motion: reduce)").matches,bn=matchMedia("(pointer: coarse)").matches||Math.min(screen.width,screen.height)<700;async function Gg(){let r,e,t;try{[r,e,t]=await Promise.all(["views.json","defects.json","body.json"].map(g=>fetch(g).then(v=>v.json())))}catch{oe("loading").textContent="\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0434\u0430\u043D\u043D\u044B\u0435 (views.json, defects.json). \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 \u0447\u0435\u0440\u0435\u0437 \u0432\u0435\u0431-\u0441\u0435\u0440\u0432\u0435\u0440, \u043D\u0435 \u043A\u0430\u043A \u0444\u0430\u0439\u043B.";return}let n={...r,rows:e.rows,body:t.body,tex:t.tex,walls:t.walls||{},dims:t.dims,volume:e.volume||{},volumeAll:e.volumeAll||{},volumeModelTotal:e.volumeModelTotal||{},stationStuds:{}},i=e.stationStuds||{};new Set([...Object.keys(t.stations||{}),...Object.keys(i)]).forEach(g=>{n.stationStuds[g]={...(t.stations||{})[g],...i[g]}});let s=[...new Set(n.rows.map(g=>g.week).concat(Object.keys(n.volumeAll),Object.values(n.volume).flatMap(g=>Object.keys(g))))].sort(),a=g=>{let v=(n.volume[l.model]||{})[g];return v>0?v:0},o="stud-map.drawOp",c="stud-map.zones",h=()=>{try{return localStorage.getItem(c)!=="0"}catch{return!0}},u=()=>{try{let g=parseFloat(localStorage.getItem(o));return g>=0&&g<=1?g:1}catch{return 1}},l={model:"A13T",view:null,week:"all",cats:new Set(Fi.map(g=>g.key)),ghost:!0,selected:null,mode:"body",drawOp:u(),trendMode:"n",trendScope:"model",zone:null,showZones:h(),trendHidden:new Set},d=n.rows.map(g=>g.date).sort();oe("period")&&(oe("period").textContent=So(d[0])+"\u2013"+So(d[d.length-1])+"."+d[0].slice(0,4));let m=g=>l.week==="all"||g.week===l.week,_=()=>n.rows.filter(g=>g.model===l.model),p=g=>n.views.filter(v=>v.model===g);function f(g){let v=new Set(g.studs.map(T=>T.no)),E=new Map;for(let T of n.rows)T.model!==g.model||T.stud_no==null||!v.has(T.stud_no)||!m(T)||!l.cats.has(T.category)||(E.has(T.stud_no)||E.set(T.stud_no,[]),E.get(T.stud_no).push(T));return E}let b=g=>{let v=0;return f(g).forEach(E=>E.forEach(T=>{v+=T.studs})),v},C=g=>{let v={},E=0;g.forEach(D=>{v[D.category]=(v[D.category]||0)+D.studs,E+=D.studs});let T=Object.keys(v).sort((D,O)=>v[O]-v[D])[0];return{n:E,byCat:v,top:T}},S=(g,v)=>g.img+"-"+(v?"2048":"1200")+".webp",y=null;try{if(y=new tl({antialias:!bn&&(devicePixelRatio||1)<1.5,powerPreference:"high-performance"}),!y.getContext())throw new Error("no gl")}catch{y=null}let M=!!y;M||(l.mode="2d",oe("mode3d").disabled=!0,oe("mode3d").title="\u042D\u0442\u043E\u0442 \u0431\u0440\u0430\u0443\u0437\u0435\u0440 \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442 3D (WebGL)");let N=oe("scene"),k,x,P,z,Y,ie=null,q=100,B=66,K=0,re=null,ue=!1,Z=()=>{!ue&&M&&l.mode!=="2d"&&!K&&(K=requestAnimationFrame(ve))},me=new R,ae=new R,ee=0,$=0,_e=0,pe=!1;function ve(g){K=0;let v=!1;if(!pe){try{v=te(g)}catch(E){ue=!1,re=null,_e++<3&&console.error("[3D] \u043E\u0448\u0438\u0431\u043A\u0430 \u043A\u0430\u0434\u0440\u0430",E),v=!1}finally{ue=!1}v&&Z()}}function te(g){let v=!1;if($++,re)try{re(g),v=!0}catch(D){throw re=null,D}ue=!0;let E=P.update();if(ue=!1,E){let D=x.position.distanceTo(P.target)*2*Math.tan(Qa.degToRad(x.fov)/2)/Math.max(1,y.domElement.clientHeight);Math.max(x.position.distanceTo(me),P.target.distanceTo(ae))>D*.25?(ee=0,v=!0):++ee<3&&(v=!0)}me.copy(x.position),ae.copy(P.target),v||Je(),Pe(g,v);let T=l.mode==="body"?34:58;for(let D of Y.children)D.userData.label&&(D.visible=D.userData.n>=2||D.userData.no===l.selected||x.position.distanceTo(D.position)<T);return y.render(k,x),Nt(),v}let Ze=0,Re=0,Be=0;function Pe(g,v){if(!v){Re=0,Be=0;return}Re&&(Be=g-Re>30?Be+1:Math.max(0,Be-2),Be>24&&Ze>1&&(Ze=Math.max(1,Ze-.25),y.setPixelRatio(Ze),y.setSize(N.clientWidth,N.clientHeight,!1),Be=0)),Re=g}let ft=0;function Je(){bn||!Ge.length||ft||(ft=setTimeout(()=>{ft=0,K||je()},250))}let Ce={};if(M){Ze=Math.min(devicePixelRatio||1,bn?1.5:2),y.setPixelRatio(Ze),y.outputEncoding=_t,y.shadowMap.enabled=!bn,y.shadowMap.type=yo,y.shadowMap.autoUpdate=!1,N.appendChild(y.domElement);let g=0;y.domElement.addEventListener("webglcontextlost",v=>{v.preventDefault(),pe=!0,K&&cancelAnimationFrame(K),K=0,re=null,oe("loading").hidden=!1,oe("loading").textContent="\u0412\u0438\u0434\u0435\u043E\u043A\u0430\u0440\u0442\u0430 \u0441\u0431\u0440\u043E\u0441\u0438\u043B\u0430 3D \u2014 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u044E\u2026",clearTimeout(g),g=setTimeout(()=>{pe&&(oe("loading").textContent="3D \u043D\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B\u043E\u0441\u044C \u2014 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0443 (F5). \u0420\u0435\u0436\u0438\u043C \xAB2D\xBB \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0431\u0435\u0437 \u0432\u0438\u0434\u0435\u043E\u043A\u0430\u0440\u0442\u044B.")},5e3)}),y.domElement.addEventListener("webglcontextrestored",()=>{pe=!1,clearTimeout(g),oe("loading").hidden=!0,H(),Z()}),k=new lo,k.background=new pt("#EFEBE4"),x=new rn(34,1,.5,2e3),P=new wo(x,y.domElement),P.enableDamping=!gh,P.dampingFactor=.14,P.maxPolarAngle=Math.PI*.47,P.minDistance=6,P.maxDistance=260,P.screenSpacePanning=!0,P.addEventListener("change",Z),k.add(new go(16777215,14275270,.85)),z=new xo(16777215,.75),z.position.set(-40,90,45),z.castShadow=!bn,z.shadow.mapSize.set(1024,1024),z.shadow.bias=-5e-4,k.add(z),Y=new on,k.add(Y),Object.assign(Ce,{copper:new En({color:12876360,metalness:.75,roughness:.32}),steel:new En({color:11844033,metalness:.7,roughness:.3}),burn:new En({color:3812906,metalness:.2,roughness:.9}),weld:new En({color:14343650,metalness:.95,roughness:.18}),hole:new Ut({color:1842204}),miss:new Ut({color:oi.\u041E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442.color,wireframe:!0,transparent:!0,opacity:.55}),ghostCopper:new En({color:13214335,metalness:.3,roughness:.6,transparent:!0,opacity:.55}),ghostSteel:new En({color:12106946,metalness:.3,roughness:.6,transparent:!0,opacity:.55}),ring:new Ut({transparent:!0,opacity:.85,depthWrite:!1}),halo:new Ut({transparent:!0,opacity:.16,depthWrite:!1}),sel:new Ut({color:2906762,transparent:!0,opacity:.95,depthWrite:!1})})}let Dt={coarse:{h:2.4,r:.26,thread:.22,tube:.07,base:"collar"},coarselong:{h:3,r:.22,thread:.22,tube:.06,base:"collar"},fine:{h:2.1,r:.25,thread:.12,tube:.04,base:"none"},short:{h:1.2,r:.3,thread:.18,tube:.06,base:"collar"},hexbolt:{h:1.6,r:.24,thread:.14,tube:.045,base:"hex"},flangebolt:{h:2.4,r:.24,thread:.14,tube:.045,base:"flange"},pin:{h:2,r:.26,thread:0,base:"flange"},pinshort:{h:1.3,r:.3,thread:0,base:"flange"},pintall:{h:2.8,r:.24,thread:0,base:"flange"},pinstep:{h:2.6,r:.24,thread:0,base:"flange",step:!0}};function vt(g,v,E,T){let D=new on,O=new ut(new vn(g.r,g.r,E,T?10:16),Ce[v]);if(O.position.y=E/2,D.add(O),g.step&&!T){let W=new ut(new vn(g.r*.72,g.r*.72,E*.35,16),Ce[v]);W.position.y=E*.82,D.add(W),O.scale.y=.65,O.position.y=E*.325}if(g.thread&&!T)for(let W=g.thread;W<E-.05;W+=g.thread){let G=new ut(new nr(g.r+g.tube*.2,g.tube,5,16),Ce[v]);G.rotation.x=Math.PI/2,G.position.y=W,D.add(G)}return D}function Pt(g,v){let E=new on;if(g.base==="collar"){let T=new ut(new vn(g.r*1.55,g.r*1.75,.16,18),Ce[v]);T.position.y=.08,E.add(T)}if(g.base==="hex"){let T=new ut(new vn(g.r*2.3,g.r*2.3,.38,6),Ce[v]);T.position.y=.19,E.add(T)}if(g.base==="flange"){let T=new ut(new vn(g.r*2.2,g.r*2.3,.18,20),Ce[v]);T.position.y=.09,E.add(T)}return E}function qt(g,v){let E=n.parts[g]||{kind:"coarse",metal:"copper"},T=Dt[E.kind]||Dt.coarse,D=E.metal==="steel"?"steel":"copper",O=new on,W=T.base==="hex"?.38:T.base==="none"?0:.16;if(v==="ghost"){let se=E.metal==="steel"?"ghostSteel":"ghostCopper";O.add(Pt(T,se));let xe=vt(T,se,T.h*.75,!0);return xe.position.y=W,O.add(xe),O.scale.setScalar(.7),O}if(v==="missing"){O.add(Pt(T,"miss"));let se=vt(T,"miss",T.h,!0);se.position.y=W,O.add(se);let xe=new ut(new er(T.r*1.1,16),Ce.hole);return xe.rotation.x=-Math.PI/2,xe.position.y=.02,O.add(xe),O}if(v==="torn"){let se=new ut(new vn(T.r*1.9,T.r*2.1,.08,20),Ce.weld);se.position.y=.04,O.add(se);let xe=new ut(new vn(T.r*.9,T.r,.22,7),Ce[D]);return xe.position.y=.15,O.add(xe),O}if(O.add(Pt(T,D)),v==="broken"){let se=T.h*.42,xe=vt(T,D,se);xe.position.y=W,O.add(xe);let Ue=new ut(new ho(T.r*1.02,T.r*1.1,7,1,!0),Ce[D]);Ue.position.y=W+se+T.r*.3,Ue.rotation.y=.6,Ue.scale.y=.6,O.add(Ue);let ze=vt(T,D,T.h*.5);return ze.rotation.z=Math.PI/2,ze.position.set(T.h*.75,T.r,.45),O.add(ze),O}if(v==="bent"){let se=vt(T,D,T.h*.45);se.position.y=W,O.add(se);let xe=vt(T,D,T.h*.55);return xe.position.y=W+T.h*.45,xe.rotation.z=-.75,O.add(xe),O}let G=vt(T,D,T.h);if(G.position.y=W,O.add(G),v==="stick"){let se=new ut(new uo(T.r*2.1,1),Ce.burn);se.scale.set(1,.32,1),se.position.y=.1,O.add(se),G.rotation.z=.24,G.rotation.x=.1}return O}let St=new Map;function gt(g,v){let E=g+"|"+v;if(St.has(E))return St.get(E);let T=qt(g,v);T.updateMatrixWorld(!0);let D=new Map;T.traverse(W=>{if(!W.isMesh)return;let G=Object.keys(Ce).find(xe=>Ce[xe]===W.material),se=W.geometry.clone();se.applyMatrix4(W.matrixWorld),se.index&&(se=se.toNonIndexed()),["uv","uv2"].forEach(xe=>se.deleteAttribute(xe)),D.has(G)||D.set(G,[]),D.get(G).push(se),W.geometry.dispose()});let O=[...D].map(([W,G])=>({mk:W,geo:ph(G)}));return ln(D),St.set(E,O),O}function ln(g){g.forEach(v=>v.forEach(E=>E.dispose()))}let Yt=new Map;function L(g,v,E){let T=g+"|"+v+"|"+E,D=Yt.get(T);if(!D){let W=document.createElement("canvas");W.width=256,W.height=112;let G=W.getContext("2d");G.fillStyle="rgba(255,255,255,0.95)",G.strokeStyle=E,G.lineWidth=6;let se=26;G.beginPath(),G.moveTo(se,4),G.arcTo(252,4,252,108,se),G.arcTo(252,108,4,108,se),G.arcTo(4,108,4,4,se),G.arcTo(4,4,252,4,se),G.closePath(),G.fill(),G.stroke(),G.fillStyle="#22262B",G.font='600 50px "IBM Plex Mono", monospace',G.textBaseline="middle",G.fillText(String(g),22,58),G.fillStyle=E,G.beginPath(),G.arc(206,56,34,0,Math.PI*2),G.fill(),G.fillStyle="#fff",G.font='800 40px "Manrope", sans-serif',G.textAlign="center",G.fillText(String(v),206,58);let xe=new Qs(W);xe.encoding=_t,D=new ys({map:xe,depthTest:!1,sizeAttenuation:!1}),Yt.set(T,D)}let O=new $s(D);return O.scale.set(.05,.0219,1),O.renderOrder=10,O}let w=M?new tr(.86,1,36):null,j=M?new er(1,36):null,le=M?new ut(new tr(.92,1,48),Ce.sel):null;le&&(le.visible=!1);let ge=new R(0,1,0),be=new R(0,0,1),he=10,I=.5,U=[],Se=g=>new R((g[0]-.5)*q,.31,(g[1]-.5)*B);function Ae(){Y.children.slice().forEach(g=>{Y.remove(g),g.isInstancedMesh&&g.dispose()})}function Me(){if(l.mode==="body")return Ft(l.model).map(E=>({s:{no:E.no,part:E.part,pts:E.pts},places:E.pts.map(T=>({pos:new R(T[0]*he,T[1]*he,T[2]*he),nrm:new R(T[3],T[4],T[5]).normalize()}))}));let g=l.view;return g?g.studs.map(v=>({s:v,places:v.pts.map(E=>({pos:Se(E),nrm:ge.clone()}))})):[]}function Oe(){let g=new Map;for(let v of n.rows)v.model!==l.model||v.stud_no==null||!m(v)||!l.cats.has(v.category)||(g.has(v.stud_no)||g.set(v.stud_no,[]),g.get(v.stud_no).push(v));return g}function Ie(){U=[];let g=l.mode==="body",v=Me();if(!v.length&&!g)return;let E=g?Oe():f(l.view),T=g?I:1,D=new Map,O=[],W=[];if(v.forEach(({s:ze,places:ce})=>{let Xe=C(E.get(ze.no)||[]);if(!Xe.n&&!l.ghost)return;let We=oi[Xe.top]||oi["\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"];ce.forEach(({pos:lt,nrm:et})=>{let ct=lt.clone().addScaledVector(et,1.4*T);U.push({s:ze,n:Xe.n,byCat:Xe.byCat,pos:lt,nrm:et,pick:ct});let we=Xe.n?We.mode:"ghost",Ye=ze.part+"|"+we;D.has(Ye)||D.set(Ye,[]),D.get(Ye).push({pos:lt,nrm:et}),Xe.n&&(O.push({pos:lt,nrm:et,n:Xe.n,color:We.color}),W.push({pos:lt,nrm:et,s:ze,n:Xe.n,color:We.color}))})}),!M)return;Ae();let G=new Tt,se=new yn,xe=new R(T,T,T);if(D.forEach((ze,ce)=>{let[Xe,We]=ce.split("|");gt(Xe,We).forEach(({mk:lt,geo:et})=>{let ct=new vs(et,Ce[lt],ze.length);ze.forEach(({pos:we,nrm:Ye},It)=>{se.setFromUnitVectors(ge,Ye),G.compose(we,se,xe),ct.setMatrixAt(It,G)}),ct.frustumCulled=!1,ct.castShadow=!bn&&l.mode==="3d"&&!lt.startsWith("ghost")&&lt!=="miss",Y.add(ct)})}),O.length){let ze=new vs(w,Ce.ring,O.length),ce=new vs(j,Ce.halo,O.length),Xe=new pt;O.forEach((We,lt)=>{let et=(1.05+Math.min(We.n,6)*.22)*T;se.setFromUnitVectors(be,We.nrm);let ct=We.pos.clone().addScaledVector(We.nrm,.03);G.compose(ct,se,new R(et,et,1)),ze.setMatrixAt(lt,G);let we=We.pos.clone().addScaledVector(We.nrm,.02);G.compose(we,se,new R(et,et,1)),ce.setMatrixAt(lt,G),Xe.set(We.color),ze.setColorAt(lt,Xe),ce.setColorAt(lt,Xe)}),ze.frustumCulled=!1,ce.frustumCulled=!1,Y.add(ce,ze)}W.forEach(ze=>{let ce=L(ze.s.no,ze.n,ze.color),Xe=g?ze.nrm.clone().multiplyScalar(2.6).add(new R(0,.6,0)):new R(0,4.3,0);ce.position.copy(ze.pos).add(Xe),ce.userData={n:ze.n,no:ze.s.no,label:!0},Y.add(ce)});let Ue=U.find(ze=>ze.s.no===l.selected&&ze.n);if(Ue){let ze=2.75*T;se.setFromUnitVectors(be,Ue.nrm),le.quaternion.copy(se),le.scale.set(ze,ze,1),le.position.copy(Ue.pos).addScaledVector(Ue.nrm,.06),le.visible=!0,Y.add(le)}else le.visible=!1;H(),Ne(),ne(),Z()}let $e={"ENGINE COMP":{at:[1.78,1.16,0],boxes:[[1.3,.42,-.56,2.15,1,.56]]},"FRONT FLOOR":{at:[.45,.62,0],boxes:[[-.4,.22,-.86,1.3,.5,.86]]},"REAR FLOOR":{at:[-1.45,.62,0],boxes:[[-2.25,.18,-.86,-.4,.46,.86]]},"WHEEL HOUSE":{at:[-1.3,1.08,0],boxes:[[-1.8,.28,.52,-.8,.84,.88],[-1.8,.28,-.88,-.8,.84,-.52]]},"FR WHEEL HOUSE":{at:[1.4,.98,.8],boxes:[[.95,.28,.52,1.95,.84,.88],[.95,.28,-.88,1.95,.84,-.52]]},"BODY SIDE":{at:[-.1,1.14,-.86],boxes:[[-2,.34,-.92,1.3,1.3,-.8]]}},rt={"ENGINE COMP":"EC","FRONT FLOOR":"FF","REAR FLOOR":"RF","WHEEL HOUSE":"WH","FR WHEEL HOUSE":"FWH","BODY SIDE":"BS"},dt=fe("div","zones");dt.hidden=!0,oe("stage").insertBefore(dt,oe("flat"));let F=[],J=null,de=M?new Ut({color:13583161,transparent:!0,opacity:.13,depthWrite:!1,side:fn}):null;function Te(){let g=new Map;for(let v of n.rows)v.model!==l.model||v.stud_no!=null||!m(v)||!l.cats.has(v.category)||(g.has(v.location)||g.set(v.location,[]),g.get(v.location).push(v));return g}function Ne(){if(dt.replaceChildren(),F=[],J&&(k.remove(J),J.traverse(v=>{v.geometry&&v.geometry.dispose()}),J=null),!M||l.mode!=="body"||!l.showZones){dt.hidden=!0;return}dt.hidden=!1;let g=Te();l.zone&&!g.has(l.zone)&&(l.zone=null),g.forEach((v,E)=>{let T=$e[E];if(!T)return;let D=v.reduce((G,se)=>G+se.studs,0),O=fe("button","zbadge");O.type="button",O.setAttribute("aria-pressed",String(l.zone===E));let W=fe("span","zd");Fi.forEach(G=>{if(v.some(se=>se.category===G.key)){let se=fe("span","dot");se.style.background=G.color,W.appendChild(se)}}),O.append(W,fe("b","",yt(D)),fe("span","zl","\u0431\u0435\u0437 \u2116 \xB7 "+E),fe("span","zs",rt[E]||E)),O.title=E+": "+D+" \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u0430 \u2014 \u0442\u043E\u0447\u043D\u043E\u0435 \u043C\u0435\u0441\u0442\u043E \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E. \u041D\u0430\u0436\u043C\u0438\u0442\u0435, \u0447\u0442\u043E\u0431\u044B \u0443\u0432\u0438\u0434\u0435\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A.",O.onclick=()=>{l.zone=l.zone===E?null:E,l.selected=null,Ne(),Ps(),Ls(),l.zone&&Ht(E),Z()},dt.appendChild(O),F.push({b:O,pos:new R(T.at[0]*he,T.at[1]*he,T.at[2]*he)})}),F.forEach(v=>{v.bw=v.b.offsetWidth,v.bh=v.b.offsetHeight}),l.zone&&$e[l.zone]&&(J=new on,$e[l.zone].boxes.forEach(([v,E,T,D,O,W])=>{let G=new ut(new ii((D-v)*he,(O-E)*he,(W-T)*he),de);G.position.set((v+D)/2*he,(E+O)/2*he,(T+W)/2*he),G.renderOrder=3,J.add(G)}),k.add(J)),Nt()}let ot=new R;function Nt(){if(dt.hidden||!F.length)return;let g=N.clientWidth,v=N.clientHeight,E=[];F.map(({b:T,pos:D,bw:O,bh:W})=>{ot.copy(D).project(x);let G=ot.z<1&&Math.abs(ot.x)<1.05&&Math.abs(ot.y)<1.05;return T.hidden===G&&(T.hidden=!G),G?{b:T,x:(ot.x+1)/2*g,y:(1-ot.y)/2*v,bw:O,bh:W}:null}).filter(Boolean).sort((T,D)=>T.y-D.y).forEach(T=>{let D=T.y;for(let O=0;O<=E.length;O++){let W=!1;for(let G of E){let se=(G.bh+T.bh)/2+3;Math.abs(G.x-T.x)<(G.bw+T.bw)/2+4&&Math.abs(G.y-D)<se-.5&&(D=G.y+se,W=!0)}if(!W)break}E.push({x:T.x,y:D,bw:T.bw,bh:T.bh}),T.b.style.transform=`translate(${T.x.toFixed(1)}px, ${D.toFixed(1)}px) translate(-50%, -50%)`})}function Ht(g){let v=$e[g];if(!v)return;let E=new R(v.at[0]*he,v.at[1]*he*.75,v.at[2]*he);bt(E.clone().add(new R(26,22,v.at[2]<0?-34:34)),E)}let Hn=new po,it=new Map,Mn=bn?8:16,Ss=typeof createImageBitmap=="function"&&!/^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent)?new _o().setOptions({imageOrientation:"flipY",premultiplyAlpha:"none"}):null;function or(g,v,E){if(!Ss)return Hn.load(g,v,void 0,E);Ss.load(g,T=>{let D=new an(T);D.flipY=!1,D.needsUpdate=!0,v(D)},void 0,E)}function To(g,v){if(it.has(g))return v(it.get(g));or(g,E=>{E.encoding=_t,E.anisotropy=Math.min(4,y.capabilities.getMaxAnisotropy()),ke(()=>{y.initTexture(E),it.set(g,E),v(E),ar(E)})},()=>{})}function ar(g){if(it.size<=Mn)return;let v=A();for(let[E,T]of it){if(it.size<=Mn)break;T===g||v.has(T)||(it.delete(E),T.dispose(),T.image&&T.image.close&&T.image.close())}}function A(){let g=new Set;return[He,ie].forEach(v=>v&&v.traverse(E=>{E.material&&E.material.map&&g.add(E.material.map)})),g}let H=()=>{M&&y.shadowMap.enabled&&l.mode==="3d"&&(y.shadowMap.needsUpdate=!0)};function Q(g,v){if(it.has(g)){let E=it.get(g);return it.delete(g),it.set(g,E),v(E)}or(g,E=>{E.encoding=_t,E.anisotropy=Math.min(4,y.capabilities.getMaxAnisotropy()),y.initTexture(E),it.set(g,E),ar(E),v(E),ne()},()=>{oe("loading").hidden=!1,oe("loading").textContent="\u041A\u0430\u0440\u0442\u0438\u043D\u043A\u0430 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u043B\u0430\u0441\u044C: "+g})}let V=0;function ne(){!M||V||(V=setTimeout(()=>{V=0,ke(()=>{try{y.compile(k,x)}catch{}})},150))}function ke(g){!K&&!re?g():setTimeout(()=>ke(g),160)}let Ge=[];function je(){if(bn||!Ge.length)return;let g=x.position.distanceTo(P.target);for(let v=Ge.length-1;v>=0;v--){let E=Ge[v];if(!E.mesh.parent){Ge.splice(v,1);continue}g<E.dist&&(Ge.splice(v,1),To(E.hiUrl,T=>{let D=E.mesh.material;D&&(D.map=T,D.emissiveMap&&(D.emissiveMap=T),D.bumpMap&&(D.bumpMap=T),Z())}))}}function Qe(g){M&&(oe("loading").hidden=!1,oe("loading").textContent="\u0417\u0430\u0433\u0440\u0443\u0436\u0430\u044E \u0441\u0445\u0435\u043C\u0443\u2026",Q(S(g),v=>{if(l.mode!=="3d")return;oe("loading").hidden=!0,ie&&(k.remove(ie),ie.traverse(O=>{O.geometry&&O.geometry.dispose(),O.material&&O.material.dispose()})),q=100,B=100*g.h/g.w,ie=new on;let E=new ut(new ri(q,B),new En({map:v,roughness:.92,metalness:0}));E.rotation.x=-Math.PI/2,E.position.y=.31,E.receiveShadow=!bn,E.userData.drawing=!0,ie.add(E),Ge.push({mesh:E,hiUrl:S(g,!0),dist:Ln(q,B)*.8});let T=new ut(new ii(q,.6,B),new En({color:14472650,roughness:1}));T.position.y=-.02,T.userData.drawing=!0,ie.add(T),k.add(ie),Cs();let D=z.shadow.camera;D.left=-q*.6,D.right=q*.6,D.top=B*.7,D.bottom=-B*.7,D.near=1,D.far=300,D.updateProjectionMatrix(),H(),Ie(),Xn("tilt",!0)}))}let tt=null,He=null,st=null,Lt=(g,v)=>{for(let E=1;E<g.length;E++)if(v<=g[E][0]){let[T,D]=g[E-1],[O,W]=g[E];return D+(W-D)*(v-T)/(O-T)}return g[g.length-1][1]},Qt=[[-2.3,1],[-2.05,1.06],[-1.6,1.12],[-1.22,1.45],[-.4,1.55],[.55,1.52],[1.25,1],[1.6,.95],[2.3,.78]],Pn=[[-2.3,.74],[-2,.87],[-1.5,.89],[1.6,.89],[2.05,.84],[2.3,.7]];function kn(g){let v=Lt(Pn,g),E=Lt(Qt,g),T=.2,D=Math.min(.98,E-.02),O=D+(E-D)*.7;return[[v,T],[v,D],[v*.9,O],[v*.72,E],[-v*.72,E],[-v*.9,O],[-v,D],[-v,T]]}function Rt(){let g=new on;g.scale.setScalar(he);let v=46,E=8,T=[],D=[],O=[];for(let Ke=0;Ke<=v;Ke++)O.push(-2.3+4.6*Ke/v);O.forEach(Ke=>kn(Ke).forEach(([qe,Mt])=>T.push(Ke,Mt,qe)));for(let Ke=0;Ke<v;Ke++)for(let qe=0;qe<E-1;qe++){let Mt=Ke*E+qe,At=Mt+E;D.push(Mt,At,Mt+1,At,At+1,Mt+1)}let W=new zt;W.setAttribute("position",new mt(T,3)),W.setIndex(D),W.computeVertexNormals(),g.add(new ut(W,new Ut({color:10466503,transparent:!0,opacity:.12,side:fn,depthWrite:!1})));let G=[],se=(Ke,qe)=>G.push(Ke[0],Ke[1],Ke[2],qe[0],qe[1],qe[2]);[0,1,3,4,6,7].forEach(Ke=>{for(let qe=0;qe<v;qe++)se(T.slice((qe*E+Ke)*3,(qe*E+Ke)*3+3),T.slice(((qe+1)*E+Ke)*3,((qe+1)*E+Ke)*3+3))}),[-2.3,-1.22,-.1,.55,1.25,2.3].forEach(Ke=>{let qe=kn(Ke);for(let Mt=0;Mt<E-1;Mt++)se([Ke,qe[Mt][1],qe[Mt][0]],[Ke,qe[Mt+1][1],qe[Mt+1][0]])});let xe=new zt;xe.setAttribute("position",new mt(G,3)),g.add(new js(xe,new bs({color:7241100,transparent:!0,opacity:.6})));let Ue=new ut(new ri(1.5,.72),new Ut({color:14275527,transparent:!0,opacity:.45,side:fn,depthWrite:!1}));Ue.rotation.y=Math.PI/2,Ue.position.set(n.dims.dashX,.66,0),g.add(Ue);let ze=new Ut({color:3817285,transparent:!0,opacity:.16,depthWrite:!1}),ce=new En({color:6121072,roughness:.7}),Xe=new Ut({color:13358044,transparent:!0,opacity:.35,side:fn,depthWrite:!1});[n.dims.frontAxle,n.dims.rearAxle].forEach(Ke=>[-1,1].forEach(qe=>{let Mt=new ut(new vn(.34,.34,.22,28),ze);Mt.rotation.x=Math.PI/2,Mt.position.set(Ke,.34,qe*.8),g.add(Mt);let At=new ut(new nr(.42,.018,6,32,Math.PI),ce);At.position.set(Ke,.34,qe*.895),g.add(At);let hn=new vn(.47,.47,.28,28,1,!0,0,Math.PI);hn.rotateZ(Math.PI/2),hn.rotateY(Math.PI/2);let un=new ut(hn,Xe);un.position.set(Ke,.32,qe*(.875-.16)),g.add(un)}));let We=n.dims,lt=We.dashX,et=2.15,ct=new Ut({color:12174543,transparent:!0,opacity:.4,side:fn,depthWrite:!1}),we=new Ut({color:9214374,transparent:!0,opacity:.55,depthWrite:!1});[-1,1].forEach(Ke=>{let qe=new ut(new ri(et-lt,.55),ct);qe.position.set((lt+et)/2,.72,Ke*.565),g.add(qe);let Mt=new ut(new ii(et-lt+.05,.1,.08),we);Mt.position.set((lt+et)/2,.46,Ke*.45),g.add(Mt)});let Ye=[];[[lt,.44],[et,.44],[et,1],[lt,1]].forEach((Ke,qe,Mt)=>{let At=Mt[(qe+1)%4];[-.565,.565].forEach(hn=>Ye.push(Ke[0],Ke[1],hn,At[0],At[1],hn))});let It=new zt;It.setAttribute("position",new mt(Ye,3)),g.add(new js(It,new bs({color:7241100,transparent:!0,opacity:.75})));let cn=(Ke,qe,Mt,At)=>{let hn=document.createElement("canvas");hn.width=400,hn.height=96;let un=hn.getContext("2d");un.fillStyle="rgba(244,240,234,0.92)",un.fillRect(0,0,400,96),un.fillStyle="#5E6670",un.font='800 50px "Manrope", sans-serif',un.textAlign="center",un.textBaseline="middle",un.fillText(Ke,200,50);let ai=new Qs(hn);ai.encoding=_t;let Vi=new $s(new ys({map:ai,depthTest:!1,sizeAttenuation:!1}));Vi.scale.set(.095/he,.0228/he,1),Vi.position.set(qe,Mt,At),Vi.renderOrder=9,g.add(Vi)};return cn("\u041F\u0415\u0420\u0401\u0414",2.75,.55,0),cn("\u0417\u0410\u0414",-2.75,.55,0),cn("\u041F\u0420\u0410\u0412. \u0411\u041E\u0420\u0422",.7,1.85,.95),cn("\u041B\u0415\u0412. \u0411\u041E\u0420\u0422",-.7,1.85,-.95),cn("\u041C\u041E\u0422. \u041E\u0422\u0421\u0415\u041A",1.85,1.3,0),g}let at={A13T:{step:-.52,well:[-1.71,0,.33],tunnel:.13,bars:[[-.15,.1],[.35,.12]]},A01:{step:-.47,well:[-1.75,0,.32],tunnel:.16,bars:[[.06,.1],[.52,.1]]},P01:{step:-.42,well:null,tunnel:.12,bars:[[-.1,.12],[.38,.12]]},CS55p:{step:-.45,well:[-1.55,0,.36],tunnel:.1,bars:[[.09,.12],[.58,.1]]}},Zt=(g,v,E)=>{let T=Math.min(1,Math.max(0,(E-g)/(v-g)));return T*T*(3-2*T)};function xt(g,v,E){let T=at[g]||at.A13T,D=Math.abs(E),O=1-Zt(T.step-.07,T.step+.07,v),W=0,G=Zt(T.step+.02,T.step+.22,v);W+=G*(1-Zt(T.tunnel,T.tunnel+.1,D))*(.12+.08*Zt(T.step,1.1,v)),T.bars.forEach(([xe,Ue])=>{W+=.045*(1-Zt(Ue/2,Ue/2+.035,Math.abs(v-xe)))*Zt(T.tunnel+.09,T.tunnel+.15,D)*(1-Zt(.72,.77,D))*(1-O)});let se=Zt(.75,.82,D)*Zt(-.95,-.8,v)*(1-Zt(1,1.12,v));if(W+=se*(.13-W),T.well){let xe=Math.hypot(v-T.well[0],E-T.well[1]);W-=.15*(1-Zt(T.well[2]*.65,T.well[2]*1.05,xe))}return W+=Zt(.97,1.3,v)*(.3-W),W+=.04*(1-Zt(-2.2,-2.08,v)),W}function Wn(g,v,E,T){let O=xt(g,v,E),W=(xt(g,v+.008,E)-xt(g,v-.008,E))/(2*.008),G=(xt(g,v,E+.008)-xt(g,v,E-.008))/(2*.008),se=new R(-W,1,-G).normalize();return T||se.negate(),{y:(T?n.dims.floorTop:n.dims.floorBot)+O,n:se}}function lr(g,v,E){let T=n.dims,D=bn?150:300,O=bn?70:140,W=new ri(g.x1-g.x0,T.W,D,O);W.rotateX(v?-Math.PI/2:Math.PI/2),W.translate((g.x0+g.x1)/2,v?T.floorTop:T.floorBot,0);let G=W.attributes.position;for(let ce=0;ce<G.count;ce++)G.setY(ce,G.getY(ce)+xt(E,G.getX(ce),G.getZ(ce)));W.computeVertexNormals();let se=W.attributes.normal,xe=new Float32Array(G.count*3),Ue=.035,ze=v?new R(-.35,.85,-.4).normalize():new R(.3,-.85,.42).normalize();for(let ce=0;ce<G.count;ce++){let Xe=G.getX(ce),We=G.getZ(ce),lt=xt(E,Xe,We),et=(xt(E,Xe+Ue,We)+xt(E,Xe-Ue,We)+xt(E,Xe,We+Ue)+xt(E,Xe,We-Ue)-4*lt)/(Ue*Ue),ct=1-Math.min(.28,Math.max(0,v?et:-et)*.011),we=.6+.4*Math.max(0,se.getX(ce)*ze.x+se.getY(ce)*ze.y+se.getZ(ce)*ze.z),Ye=Math.min(1,we*ct*(v?1.04:1));xe[ce*3]=Ye,xe[ce*3+1]=Ye,xe[ce*3+2]=Ye}return W.setAttribute("color",new mt(xe,3)),W}let xi=g=>new Ut({map:g,vertexColors:!0,alphaTest:.5}),_i=new Map;function Ft(g){if(_i.has(g))return _i.get(g);let v=n.dims,E=(n.body[g]||[]).map(T=>({...T,pts:T.pts.map(D=>{let O=Math.abs(D[1]-v.floorTop)<.006&&D[4]>.9,W=Math.abs(D[1]-v.floorBot)<.006&&D[4]<-.9;if(!O&&!W)return D;let G=Wn(g,D[0],D[2],O);return[D[0],G.y,D[2],G.n.x,G.n.y,G.n.z]})}));return _i.set(g,E),E}function Bn(){if(!M)return;if(oe("loading").hidden=!0,tt||(tt=Rt(),k.add(tt)),tt.visible=!0,ie&&(ie.visible=!1),st!==l.model){He&&(k.remove(He),He.traverse(O=>{O.geometry&&O.geometry.dispose(),O.material&&O.material.dispose()})),He=new on,He.scale.setScalar(he),st=l.model,k.add(He);let v=n.tex[l.model]||{},E=l.model,T=(O,W)=>Q(O.img+"-1024.webp",G=>{if(st!==E)return;let se=new ut(lr(O,W,E),xi(G));se.userData.drawing=!0,se.userData.alphaCut=.5,He.add(se),Cs(),Ge.push({mesh:se,hiUrl:O.img+".webp",dist:Ln(56,30)*.8}),H(),Z()});v.top&&T(v.top,!0),v.bottom&&T(v.bottom,!1);let D=He;(n.walls[l.model]||[]).forEach(O=>Q(O.img+(bn?"-512.webp":".webp"),W=>{if(D!==He)return;let G=new ut(new ri(1,1),new Ut({map:W,alphaTest:.5,polygonOffset:!0,polygonOffsetFactor:2,polygonOffsetUnits:4})),se=new R(...O.u),xe=new R(...O.v),Ue=new R().crossVectors(xe,se).normalize(),ze=new R(...O.p0).addScaledVector(se,.5).addScaledVector(xe,.5).addScaledVector(Ue,-.015);G.matrix.makeBasis(se,xe.clone().negate(),Ue).setPosition(ze),G.matrixAutoUpdate=!1,G.userData.drawing=!0,G.userData.alphaCut=.5,He.add(G),Cs(),Z()}))}He.visible=!0;let g=z.shadow.camera;g.left=-32,g.right=32,g.top=32,g.bottom=-32,g.near=1,g.far=300,g.updateProjectionMatrix(),Ie()}function Ts(){if(!M)return;let g=l.mode==="body";tt&&(tt.visible=g),He&&(He.visible=g),ie&&(ie.visible=l.mode==="3d"),g||Ne(),P.maxPolarAngle=g?Math.PI-.02:Math.PI*.47,P.minDistance=g?3:6,P.maxDistance=g?160:260}function bt(g,v,E){if(!M)return;if(E||gh){x.position.copy(g),P.target.copy(v),P.update(),Z();return}let T=x.position.clone(),D=P.target.clone(),O=performance.now();re=W=>{let G=Math.min(1,(W-O)/650),se=G<.5?2*G*G:1-Math.pow(-2*G+2,2)/2;x.position.lerpVectors(T,g,se),P.target.lerpVectors(D,v,se),G>=1&&(re=null)},Z()}function Ln(g,v){let E=Qa.degToRad(x.fov)/2,T=Math.atan(Math.tan(E)*x.aspect);return Math.max(g/2/Math.tan(T),v/2/Math.tan(E))*1.06}function Xn(g,v){if(!M)return;if(l.mode==="body"){let T=new R(0,6,0),D=Ln(56,30);return g==="top"?bt(new R(0,D*1.1,.01),new R(0,3,0),v):g==="bottom"?bt(new R(0,-D*1.1,.01),new R(0,3,0),v):bt(g==="side"?new R(0,7,D*1.05):new R(D*.62,D*.5,D*.72),T,v)}let E=Ln(q,B);g==="top"?bt(new R(0,E,.01),new R(0,0,0),v):bt(new R(0,E*.86,E*.52),new R(0,0,B*.05),v)}function cr(g){if(!M||l.mode==="2d")return;let v=U.find(E=>E.s.no===g.no);if(v){if(l.mode==="body"){let E=v.nrm.clone().multiplyScalar(14).add(new R(6,6,6));return bt(v.pos.clone().add(E),v.pos.clone())}bt(new R(v.pos.x+6,30,v.pos.z+24),new R(v.pos.x,1,v.pos.z))}}function xh(){if(!M)return;l.mode!=="body"&&Bi("body");let g=new Set((n.walls[l.model]||[]).map(D=>D.kind)),v=new R(1.55*he,.7*he,0),E;g.has("dash_out")?E=new R(3.5*he,1.9*he,.9*he):g.has("bay_side")?E=new R(2.7*he,2*he,1.7*he):g.has("dash_in")?(E=new R(-.7*he,1.55*he,.45*he),v.set(1.3*he,.68*he,0)):E=new R(3.3*he,2.2*he,1.4*he),bt(E,v);let T=n.models.find(D=>D.id===l.model);fr(g.has("dash_out")||g.has("bay_side")||g.has("dash_in")?"\u041C\u043E\u0442\u043E\u0440\u043D\u044B\u0439 \u043E\u0442\u0441\u0435\u043A "+T.id+": "+[g.has("dash_out")&&"\u0449\u0438\u0442 \u0441\u043E \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u043E\u0442\u0441\u0435\u043A\u0430",g.has("dash_in")&&"\u0449\u0438\u0442 \u0441\u043E \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u0441\u0430\u043B\u043E\u043D\u0430",g.has("bay_side")&&"\u043B\u0435\u0432\u0430\u044F \u0441\u0442\u0435\u043D\u043A\u0430 \u043E\u0442\u0441\u0435\u043A\u0430"].filter(Boolean).join(", ")+"."+(g.has("dash_out")&&g.has("dash_in")?" \u0412\u0438\u0434 \u0438\u0437 \u0441\u0430\u043B\u043E\u043D\u0430 \u2014 \u043F\u043E\u0432\u0435\u0440\u043D\u0438\u0442\u0435 \u043A\u0430\u043C\u0435\u0440\u0443 \u043D\u0430\u0437\u0430\u0434.":""):"\u0423 "+T.id+" \u0432 Excel \u043D\u0435\u0442 \u0441\u0445\u0435\u043C\u044B \u043C\u043E\u0442\u043E\u0440\u043D\u043E\u0433\u043E \u043E\u0442\u0441\u0435\u043A\u0430 \u2014 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u0437\u043E\u043D\u0430 \u0441\u0442\u0430\u043D\u0446\u0438\u0438 ENGINE COMP. \u0414\u0435\u0444\u0435\u043A\u0442\u044B \u043E\u0442\u0441\u0435\u043A\u0430 \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u0430 \u2014 \u043D\u0430 \u043F\u043B\u0430\u0448\u043A\u0435 \xAB\u0431\u0435\u0437 \u2116\xBB.")}let _h=["FRONT FLOOR","REAR FLOOR","WHEEL HOUSE","FR WHEEL HOUSE","ENGINE COMP","BODY SIDE"],hr={"FRONT FLOOR":"\u043F\u0435\u0440\u0435\u0434\u043D\u0438\u0439 \u043F\u043E\u043B","REAR FLOOR":"\u0437\u0430\u0434\u043D\u0438\u0439 \u043F\u043E\u043B","WHEEL HOUSE":"\u0437\u0430\u0434\u043D\u0438\u0435 \u043A\u043E\u043B\u0451\u0441\u043D\u044B\u0435 \u0430\u0440\u043A\u0438","FR WHEEL HOUSE":"\u043F\u0435\u0440\u0435\u0434\u043D\u0438\u0435 \u043A\u043E\u043B\u0451\u0441\u043D\u044B\u0435 \u0430\u0440\u043A\u0438","ENGINE COMP":"\u043C\u043E\u0442\u043E\u0440\u043D\u044B\u0439 \u043E\u0442\u0441\u0435\u043A","BODY SIDE":"\u0431\u043E\u043A\u043E\u0432\u0438\u043D\u0430"},ki=null,ur=0,As=g=>new R(g[0],g[1],g[2]),dr=g=>As(g.p0).addScaledVector(As(g.u),.5).addScaledVector(As(g.v),.5),yh=(g,v)=>v.boxes.some(([E,T,D,O,W,G])=>g.x>E-.12&&g.x<O+.12&&g.y>T-.12&&g.y<W+.12&&g.z>D-.12&&g.z<G+.12);function Ao(g){oe("stBar").querySelectorAll("button").forEach(v=>v.setAttribute("aria-pressed",String(v.dataset.loc===g)))}function vh(){let g=oe("stBar");g.replaceChildren();let v={};n.rows.forEach(T=>{T.model===l.model&&m(T)&&l.cats.has(T.category)&&(v[T.location]=(v[T.location]||0)+T.studs)});let E=new Set([...Object.keys(n.stationStuds[l.model]||{}),...Object.keys(v)]);_h.filter(T=>E.has(T)&&$e[T]).forEach(T=>{let D=fe("button");D.type="button",D.dataset.loc=T,D.setAttribute("aria-pressed",String(ki===T)),D.title=T+" \u2014 "+hr[T]+": \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043D\u0430 \u043A\u0443\u0437\u043E\u0432\u0435"+(v[T]?" \xB7 \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A: "+v[T]:""),D.append(document.createTextNode(rt[T]||T)),v[T]&&D.appendChild(fe("span","",yt(v[T]))),D.onclick=()=>bh(T),g.appendChild(D)})}function bh(g){if(!M)return;if(l.mode!=="body"&&Bi("body"),ur=ki===g?ur+1:0,ki=g,Ao(g),g==="ENGINE COMP"){xh();return}let E=$e[g],T=(n.walls[l.model]||[]).filter(ce=>yh(dr(ce),E)).sort((ce,Xe)=>dr(ce).z-dr(Xe).z);if(T.length){let ce=T[ur%T.length],Xe=As(ce.u),We=As(ce.v),lt=dr(ce),et=new R().crossVectors(We,Xe).normalize(),ct=lt.clone().multiplyScalar(he),we=Ln(Xe.length()*he*1.3,We.length()*he*1.3);bt(ct.clone().addScaledVector(et,we).add(new R(0,we*.25,0)),ct);let Ye=lt.z<0?"\u043B\u0435\u0432\u0430\u044F":"\u043F\u0440\u0430\u0432\u0430\u044F";fr(g+" \xB7 "+hr[g]+": "+Ye+" \u0441\u0442\u043E\u0440\u043E\u043D\u0430."+(T.length>1?" \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \u2014 "+(lt.z<0?"\u043F\u0440\u0430\u0432\u0430\u044F":"\u043B\u0435\u0432\u0430\u044F")+".":""));return}let D=1/0,O=-1/0,W=1/0,G=-1/0,se=1/0,xe=-1/0;if(E.boxes.forEach(ce=>{D=Math.min(D,ce[0]),W=Math.min(W,ce[1]),se=Math.min(se,ce[2]),O=Math.max(O,ce[3]),G=Math.max(G,ce[4]),xe=Math.max(xe,ce[5])}),g==="FRONT FLOOR"||g==="REAR FLOOR"){let ce=ur%2===1,Xe=new R((D+O)/2*he,.285*he,0),We=Ln((O-D+.35)*he,2*he);bt(Xe.clone().add(new R(0,ce?-We*.9:We*.9,We*.42)),Xe),fr(g+" \xB7 "+hr[g]+": "+(ce?"\u0441\u043D\u0438\u0437\u0443 (\u0434\u043D\u0438\u0449\u0435). \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \u2014 \u0441\u0432\u0435\u0440\u0445\u0443.":"\u0441\u0432\u0435\u0440\u0445\u0443. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437 \u2014 \u0441\u043D\u0438\u0437\u0443 (\u0434\u043D\u0438\u0449\u0435)."));return}let Ue=new R((D+O)/2*he,(W+G)/2*he,(se+xe)/2*he),ze=Ln((O-D+.8)*he,(xe-se+.6)*he);bt(Ue.clone().add(new R(.35,.75,.9).normalize().multiplyScalar(ze)),Ue),fr(g+" \xB7 "+hr[g]+": \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u0432 Excel \u043D\u0435\u0442 \u2014 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u0437\u043E\u043D\u0430 \u0441\u0442\u0430\u043D\u0446\u0438\u0438 \u043D\u0430 \u043A\u0443\u0437\u043E\u0432\u0435.")}M&&P.addEventListener("start",()=>{ki&&(ki=null,Ao(null))});let yi=oe("stage"),rl=()=>document.fullscreenElement||document.webkitFullscreenElement,Eo=()=>{let g=!!rl()||yi.classList.contains("fs");oe("fsBtn").setAttribute("aria-pressed",String(g)),oe("fsBtn").title=g?"\u0412\u044B\u0439\u0442\u0438 \u0438\u0437 \u043F\u043E\u043B\u043D\u043E\u044D\u043A\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0440\u0435\u0436\u0438\u043C\u0430 (Esc)":"\u0412\u043E \u0432\u0435\u0441\u044C \u044D\u043A\u0440\u0430\u043D (Esc \u2014 \u0432\u044B\u0439\u0442\u0438)",Z()},Es=g=>{yi.classList.toggle("fs",g),document.documentElement.style.overflow=g?"hidden":"",Eo()};oe("fsBtn").onclick=()=>{if(yi.classList.contains("fs"))return Es(!1);if(rl()){(document.exitFullscreen||document.webkitExitFullscreen).call(document);return}let g=yi.requestFullscreen||yi.webkitRequestFullscreen;if(!g||!(document.fullscreenEnabled||document.webkitFullscreenEnabled))return Es(!0);try{let v=g.call(yi);v&&v.catch&&v.catch(()=>Es(!0))}catch{Es(!0)}},document.addEventListener("fullscreenchange",Eo),document.addEventListener("webkitfullscreenchange",Eo),document.addEventListener("keydown",g=>{g.key==="Escape"&&yi.classList.contains("fs")&&oe("viewMenu").hidden&&Es(!1)});let ol=0;function fr(g){let v=oe("toast");v.textContent=g,v.hidden=!1,clearTimeout(ol),ol=setTimeout(()=>{v.hidden=!0},6e3)}oe("camTop").onclick=()=>Xn("top"),oe("camBottom").onclick=()=>Xn("bottom"),oe("camSide").onclick=()=>Xn("side"),oe("camTilt").onclick=()=>Xn("tilt"),oe("camReset").onclick=()=>{l.selected=null,ki=null,Ao(null),yl(),Xn("tilt")};let mn=oe("tip"),pr=new R;function al(g){let v=y.domElement.getBoundingClientRect(),E=g.clientX-v.left,T=g.clientY-v.top,D=null,O=1e9;for(let W of U){if(pr.copy(W.pick).project(x),pr.z>1)continue;let G=(pr.x+1)/2*v.width,se=(1-pr.y)/2*v.height,xe=Math.hypot(G-E,se-T)-(W.n?8:0);xe<O&&(O=xe,D=W)}return O<22?D:null}function Mh(g,v){mn.replaceChildren(fe("b","","\u2116"+v.s.no));let E=n.parts[v.s.part];mn.appendChild(document.createTextNode(" \xB7 "+(E?E.pn:"")));let T=fe("div","",v.n?Object.entries(v.byCat).map(([G,se])=>oi[G].short+" "+se).join(", "):"\u043D\u0435\u0442 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0435");T.className="muted",mn.appendChild(T);let D=oe("stage").getBoundingClientRect(),O=g.clientX-D.left+14,W=g.clientY-D.top+14;mn.hidden=!1,O+mn.offsetWidth>D.width-8&&(O=g.clientX-D.left-mn.offsetWidth-14),W+mn.offsetHeight>D.height-8&&(W=g.clientY-D.top-mn.offsetHeight-14),mn.style.left=O+"px",mn.style.top=W+"px"}if(M){let g=y.domElement,v=null;g.addEventListener("pointermove",E=>{if(E.buttons){mn.hidden=!0;return}let T=al(E);if(g.style.cursor=T?"pointer":"",!T){mn.hidden=!0;return}Mh(E,T)}),g.addEventListener("pointerleave",()=>{mn.hidden=!0}),g.addEventListener("pointerdown",E=>{v=[E.clientX,E.clientY]}),g.addEventListener("pointerup",E=>{if(!v||Math.hypot(E.clientX-v[0],E.clientY-v[1])>6)return;let T=al(E);T&&mr(T.s)})}function mr(g,v){l.selected=g.no,l.zone=null,yl(),v!==!1&&cr(g)}function Co(){let g=oe("flat");g.replaceChildren();let v=l.view;if(!v)return;let E=fe("div","flat-wrap");E.style.aspectRatio=v.w+" / "+v.h;let T=fe("img");T.src=S(v,!bn),T.alt="\u0421\u0445\u0435\u043C\u0430 "+v.model+", "+v.name,T.decoding="async",T.style.opacity=l.drawOp,E.appendChild(T);let D=f(v);v.studs.forEach(O=>{let W=C(D.get(O.no)||[]);if(!W.n)return;let G=oi[W.top]||oi["\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E"];O.pts.forEach(se=>{let xe=fe("button","pin",String(W.n));xe.type="button",xe.style.left=se[0]*100+"%",xe.style.top=se[1]*100+"%",xe.style.background=G.color,xe.setAttribute("aria-label","\u0428\u043F\u0438\u043B\u044C\u043A\u0430 "+O.no+", \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 "+W.n),l.selected===O.no&&xe.classList.add("on"),xe.onclick=()=>mr(O,!1),E.appendChild(xe)})}),g.appendChild(E)}let wh={body:"\u0423\u0441\u043B\u043E\u0432\u043D\u044B\u0439 \u043A\u0443\u0437\u043E\u0432: \u0442\u043E\u0447\u043A\u0438 \u0441\u043E \u0432\u0441\u0435\u0445 \u0441\u0445\u0435\u043C \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u044B \u043D\u0430 \u043F\u043E\u043B, \u043C\u043E\u0442\u043E\u0440\u043D\u044B\u0439 \u0449\u0438\u0442, \u0431\u043E\u043A\u043E\u0432\u0438\u043D\u044B \u0438 \u0430\u0440\u043A\u0438. \u0412\u0440\u0430\u0449\u0430\u0442\u044C \u2014 \u043B\u0435\u0432\u0430\u044F \u043A\u043D\u043E\u043F\u043A\u0430, \u0434\u0432\u0438\u0433\u0430\u0442\u044C \u2014 \u043F\u0440\u0430\u0432\u0430\u044F, \u043A\u043E\u043B\u0435\u0441\u043E \u2014 \u043F\u0440\u0438\u0431\u043B\u0438\u0437\u0438\u0442\u044C.","3d":"\u0421\u0445\u0435\u043C\u0430 \u0438\u0437 Excel. \u0412\u0440\u0430\u0449\u0430\u0442\u044C \u2014 \u043B\u0435\u0432\u0430\u044F \u043A\u043D\u043E\u043F\u043A\u0430, \u0434\u0432\u0438\u0433\u0430\u0442\u044C \u2014 \u043F\u0440\u0430\u0432\u0430\u044F, \u043F\u0440\u0438\u0431\u043B\u0438\u0436\u0430\u0442\u044C \u2014 \u043A\u043E\u043B\u0435\u0441\u043E. \u041A\u043B\u0438\u043A \u043F\u043E \u0448\u043F\u0438\u043B\u044C\u043A\u0435 \u2014 \u0438\u0441\u0442\u043E\u0440\u0438\u044F.","2d":"\u0421\u0445\u0435\u043C\u0430 \u0432 2D. \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u043D\u0430 \u043A\u0440\u0443\u0436\u043E\u043A \u2014 \u043E\u0442\u043A\u0440\u043E\u0435\u0442\u0441\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u044F \u0448\u043F\u0438\u043B\u044C\u043A\u0438."};function Cs(){let g=l.drawOp,v=g<.999,E=O=>{if(!O.userData.drawing)return;let W=O.material;W.transparent!==v&&(W.transparent=v,W.needsUpdate=!0),W.opacity=g,W.depthWrite=!v,O.visible=g>.02,O.userData.alphaCut&&(W.alphaTest=O.userData.alphaCut*Math.max(g,.05))};M&&(ie&&ie.traverse(E),He&&He.traverse(E),Z());let T=document.querySelector("#flat img");T&&(T.style.opacity=g);let D=Math.round(g*100);oe("drawOp").value=D,oe("drawOpVal").textContent=D+"%",oe("drawToggle").setAttribute("aria-pressed",String(v))}let ll=l.drawOp<.999?l.drawOp:.3,Po=(g,v)=>{if(l.drawOp=g,g<.999&&(ll=g),Cs(),v)try{localStorage.setItem(o,String(g))}catch{}};oe("drawOp").oninput=g=>Po(g.target.value/100,!1),oe("drawOp").onchange=g=>Po(g.target.value/100,!0),oe("drawToggle").onclick=()=>Po(l.drawOp<.999?1:ll,!0);function Bi(g){g!=="2d"&&!M&&(g="2d"),l.mode=g,[["modeBody","body"],["mode3d","3d"],["mode2d","2d"]].forEach(([v,E])=>oe(v).setAttribute("aria-pressed",String(g===E))),oe("scene").hidden=g==="2d",oe("flat").hidden=g!=="2d",document.querySelectorAll("[data-for]").forEach(v=>{v.hidden=!v.dataset.for.split(" ").includes(g)}),oe("camTilt").textContent=g==="body"?"3/4":"\u041D\u0430\u043A\u043B\u043E\u043D",oe("hint")&&(oe("hint").textContent=wh[g]),Ts(),g==="2d"?(oe("loading").hidden=!0,Co()):g==="body"?(Bn(),Xn("tilt",!0)):Qe(l.view),pl(),Ps(),Ls()}oe("modeBody").onclick=()=>Bi("body"),oe("mode3d").onclick=()=>Bi("3d"),oe("mode2d").onclick=()=>Bi("2d");let cl="stud-map.kpiMore",hl=(g,v)=>{if(oe("kBodiesT").hidden=!g,oe("kMapT").hidden=!g,oe("kMore").setAttribute("aria-expanded",String(g)),oe("kMore").firstChild.textContent=g?"\u0421\u043A\u0440\u044B\u0442\u044C":"\u0415\u0449\u0451 2",v)try{localStorage.setItem(cl,g?"1":"0")}catch{}};hl((()=>{try{return localStorage.getItem(cl)==="1"}catch{return!1}})(),!1),oe("kMore").onclick=()=>hl(oe("kMore").getAttribute("aria-expanded")!=="true",!0);let Lo=oe("menuBtn"),gr=oe("viewMenu"),Ro=(g,v)=>{gr.hidden=!g,Lo.setAttribute("aria-expanded",String(g)),!g&&v&&Lo.focus()};Lo.onclick=()=>Ro(gr.hidden),document.addEventListener("pointerdown",g=>{!gr.hidden&&!oe("vmwrap").contains(g.target)&&Ro(!1)},!0),document.addEventListener("keydown",g=>{g.key==="Escape"&&!gr.hidden&&Ro(!1,!0)});let ul=oe("zonesToggle"),dl=()=>ul.setAttribute("aria-checked",String(l.showZones));dl(),ul.onclick=()=>{l.showZones=!l.showZones,dl();try{localStorage.setItem(c,l.showZones?"1":"0")}catch{}!l.showZones&&l.zone&&(l.zone=null,Ps(),Ls()),Ne(),Z()};function Sh(){let g=oe("models");g.replaceChildren(),n.models.forEach(v=>{let E=n.rows.filter(D=>D.model===v.id&&m(D)).reduce((D,O)=>D+O.studs,0),T=fe("button","chip");T.type="button",T.setAttribute("aria-pressed",String(l.model===v.id)),T.append(fe("span","",v.brand+" "+v.id),fe("span","n",yt(E))),T.onclick=()=>{l.model=v.id,l.selected=null,fl(),Ui(!0)},g.appendChild(T)})}function fl(){let g=p(l.model);l.view=g.slice().sort((v,E)=>b(E)-b(v))[0]||g[0]}function pl(){oe("viewSec").hidden=l.mode==="body";let g=oe("views");g.replaceChildren(),p(l.model).forEach(T=>{let D=b(T),O=fe("button","tab");O.type="button",O.setAttribute("role","tab"),O.setAttribute("aria-selected",String(T===l.view)),O.append(fe("span","",T.name),fe("span","n"+(D?"":" z"),yt(D))),O.onclick=()=>{l.view=T,l.selected=null,Ui(!0)},g.appendChild(O)});let v=n.models.find(T=>T.id===l.model);oe("vtitle").replaceChildren(document.createTextNode(v.brand+" "+v.id))}function Th(){let g=oe("weeks");g.replaceChildren();let v=_();[["all","\u0412\u0441\u0435"]].concat(s.map(E=>[E,E])).forEach(([E,T])=>{let D=v.filter(W=>E==="all"||W.week===E).reduce((W,G)=>W+G.studs,0),O=fe("button","chip");O.type="button",O.setAttribute("aria-pressed",String(l.week===E)),O.append(fe("span","",T),fe("span","n",yt(D))),O.onclick=()=>{l.week=E,Ui(!1)},g.appendChild(O)})}let Ah=(g,v)=>{let E="http://www.w3.org/2000/svg",T=document.createElementNS(E,"svg");T.setAttribute("viewBox","0 0 24 24"),T.setAttribute("aria-hidden","true");let D=(W,G)=>{let se=document.createElementNS(E,W);return Object.entries(G).forEach(([xe,Ue])=>se.setAttribute(xe,Ue)),T.appendChild(se),se};D("line",{x1:2,y1:21,x2:22,y2:21,stroke:"#9A948A","stroke-width":1.5});let O="#C47A48";return g==="ok"&&(D("rect",{x:6,y:18.5,width:12,height:2.5,fill:O}),D("rect",{x:10,y:4,width:4,height:15,fill:O})),g==="stick"&&(D("ellipse",{cx:12,cy:19.5,rx:7,ry:2.2,fill:"#3A2E2A"}),D("rect",{x:10,y:5,width:4,height:14,fill:O,transform:"rotate(12 12 19)"})),g==="missing"&&(D("rect",{x:10,y:4,width:4,height:15,fill:"none",stroke:v,"stroke-dasharray":"2 2"}),D("ellipse",{cx:12,cy:20,rx:3,ry:1.2,fill:"#1C1C1C"})),g==="broken"&&(D("rect",{x:6,y:18.5,width:12,height:2.5,fill:O}),D("path",{d:"M10 19 V12 l1.2 -1.4 l1.2 1.2 l1.6 -1.6 V19 Z",fill:O}),D("rect",{x:15,y:15.5,width:7,height:3,fill:O,rx:.5})),g==="bent"&&(D("rect",{x:6,y:18.5,width:12,height:2.5,fill:O}),D("path",{d:"M10 19 V12 L17 5 L19.8 7.8 L14 13.6 V19 Z",fill:O})),g==="torn"&&(D("ellipse",{cx:12,cy:19.8,rx:6,ry:1.8,fill:"#C9CED6",stroke:"#8E959F","stroke-width":.6}),D("rect",{x:10.5,y:17,width:3,height:2.6,fill:O})),g==="unknown"&&(D("rect",{x:10,y:6,width:4,height:13,fill:"#B7BBC1"}),D("text",{x:18,y:9,"font-size":9,fill:v,"font-weight":700}).textContent="?"),T};function Eh(){let g=oe("cats");g.replaceChildren();let v=_().filter(m);Fi.forEach(E=>{if(!n.rows.some(W=>W.category===E.key))return;let T=v.filter(W=>W.category===E.key).reduce((W,G)=>W+G.studs,0),D=fe("button","chip cat");D.type="button",D.setAttribute("aria-pressed",String(l.cats.has(E.key)));let O=fe("span","dot");O.style.background=E.color,D.append(O,fe("span","",E.short),fe("span","n",yt(T))),D.onclick=()=>{l.cats.has(E.key)?l.cats.delete(E.key):l.cats.add(E.key),Ui(!1)},g.appendChild(D)})}function ml(g,v,E,T){if(g.replaceChildren(),!v.length){g.appendChild(fe("span","empty","\u041D\u0435\u0442 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 \u0432 \u044D\u0442\u043E\u0439 \u043D\u0435\u0434\u0435\u043B\u0435."));return}let D=Math.max(...v.map(O=>T?O.rate||0:O.v),1e-9);v.forEach(O=>{let W=fe("span","lbl");if(O.color){let Ue=fe("span","dot");Ue.style.background=O.color,W.appendChild(Ue)}W.appendChild(document.createTextNode(O.label)),O.title&&(W.title=O.title);let G=fe("span","track"),se=fe("span","fill");se.style.width=100*(T?O.rate||0:O.v)/D+"%",se.style.background=O.color||"var(--accent)",G.appendChild(se);let xe=fe("span","v",yt(O.v));xe.appendChild(fe("small",""," "+(O.right!=null?O.right:T?"\u2014":Math.round(100*O.v/E)+"%"))),g.append(W,G,xe)})}function Ch(){let g=n.models.find(we=>we.id===l.model),v=_().filter(m),E=v.reduce((we,Ye)=>we+Ye.studs,0),T=v.filter(we=>we.stud_no!=null).reduce((we,Ye)=>we+Ye.studs,0);oe("sumTitle").textContent=g.brand+" "+g.id+" \xB7 "+(l.week==="all"?"\u0432\u0441\u0435 \u043D\u0435\u0434\u0435\u043B\u0438":l.week);let D=l.week==="all"?s:[l.week],O=D.filter(we=>!a(we)&&v.some(Ye=>Ye.week===we)),W=0,G="";!O.length&&D.some(we=>a(we))?(W=D.reduce((we,Ye)=>we+a(Ye),0),G="\u043F\u043E \u043D\u0435\u0434\u0435\u043B\u044F\u043C (\u043B\u0438\u0441\u0442 \xAB\u0412\u044B\u043F\u0443\u0441\u043A\xBB)"):l.week==="all"&&n.volumeModelTotal[l.model]&&(W=n.volumeModelTotal[l.model],G="\u0437\u0430 \u0432\u0435\u0441\u044C \u043F\u0435\u0440\u0438\u043E\u0434 (\u043B\u0438\u0441\u0442 Graphs \u0440\u0435\u0435\u0441\u0442\u0440\u0430)");let se=W>0,xe=D.reduce((we,Ye)=>we+new Set(v.filter(It=>It.week===Ye).map(mh)).size,0),Ue=n.stationStuds[l.model]||{},ze=Object.values(Ue).reduce((we,Ye)=>we+Ye,0),ce=se&&ze>0;oe("kProd").textContent=se?yt(W):"\u2014",oe("kProdLbl").textContent=se?"\u0432\u044B\u043F\u0443\u0449\u0435\u043D\u043E \u043A\u0443\u0437\u043E\u0432\u043E\u0432":"\u0432\u044B\u043F\u0443\u0441\u043A \u0437\u0430 "+l.week+" \u043D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D",oe("kProd").parentElement.title=se?"\u0412\u044B\u043F\u0443\u0441\u043A "+g.id+" "+G:"\u0412 \u0440\u0435\u0435\u0441\u0442\u0440\u0435 \u0432\u044B\u043F\u0443\u0441\u043A \u043F\u043E \u043C\u043E\u0434\u0435\u043B\u044F\u043C \u0435\u0441\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u0437\u0430 \u0432\u0435\u0441\u044C \u043F\u0435\u0440\u0438\u043E\u0434 (\u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \xAB\u0412\u0441\u0435 \u043D\u0435\u0434\u0435\u043B\u0438\xBB)"+(n.volumeAll[l.week]?"; \u0432\u0441\u0435\u0445 \u043C\u043E\u0434\u0435\u043B\u0435\u0439 \u0437\u0430 "+l.week+" \u2014 "+yt(n.volumeAll[l.week]):""),oe("kBodies").textContent=yt(xe),oe("kBodiesLbl").textContent="\u043A\u0443\u0437\u043E\u0432\u043E\u0432 \u0441 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u043C"+(se?" \xB7 "+Cn(100*xe/W):""),oe("kTotal").textContent=yt(E),oe("kTotalLbl").textContent="\u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A"+(ce?" \xB7 "+Cn(100*E/(ze*W)):""),oe("kTotal").parentElement.title=ce?"\u041F\u0440\u043E\u0446\u0435\u043D\u0442 \u2014 \u043E\u0442 \u0432\u0441\u0435\u0445 \u0448\u043F\u0438\u043B\u0435\u043A: "+ze+" \u0448\u043F\u0438\u043B\u0435\u043A \u043D\u0430 \u043A\u0443\u0437\u043E\u0432 \u043F\u043E \u0441\u0445\u0435\u043C\u0430\u043C \xD7 "+yt(W)+" \u043A\u0443\u0437\u043E\u0432\u043E\u0432":"",oe("kMap").textContent=yt(T),oe("kMap").parentElement.title="\u0418\u0437 "+yt(E)+" \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A \u0443 "+yt(T)+" \u0432 \u0440\u0435\u0435\u0441\u0442\u0440\u0435 \u0437\u0430\u043F\u0438\u0441\u0430\u043D \u043D\u043E\u043C\u0435\u0440 \u0448\u043F\u0438\u043B\u044C\u043A\u0438 \u2014 \u043E\u043D\u0438 \u0441\u0442\u043E\u044F\u0442 \u0442\u043E\u0447\u043A\u043E\u0439 \u043D\u0430 \u0441\u0445\u0435\u043C\u0435. \u041E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 "+yt(E-T)+" \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u0430 \u2014 \u043D\u0430 \u043A\u0443\u0437\u043E\u0432\u0435 \u043F\u043B\u0430\u0448\u043A\u0438 \xAB\u0431\u0435\u0437 \u2116\xBB \u043F\u043E \u0441\u0442\u0430\u043D\u0446\u0438\u044F\u043C",oe("kMapLbl").textContent="\u0441 \u2116 \u0448\u043F\u0438\u043B\u044C\u043A\u0438 \u2014 \u0442\u043E\u0447\u043A\u043E\u0439 \u043D\u0430 \u0441\u0445\u0435\u043C\u0435"+(E?" \xB7 \u0438\u0437 "+yt(E):"");let Xe=ce?"\xB7 % \u043E\u0442 \u0448\u043F\u0438\u043B\u0435\u043A":"\xB7 \u0434\u043E\u043B\u044F \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432";oe("catUnit").textContent=Xe,oe("locUnit").textContent=ce?"\xB7 % \u043E\u0442 \u0448\u043F\u0438\u043B\u0435\u043A \u0441\u0442\u0430\u043D\u0446\u0438\u0438":"\xB7 \u0434\u043E\u043B\u044F \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432",oe("catUnit").title=ce?"\u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A / ("+ze+" \u0448\u043F\u0438\u043B\u0435\u043A \u043D\u0430 \u043A\u0443\u0437\u043E\u0432 \xD7 "+yt(W)+" \u043A\u0443\u0437\u043E\u0432\u043E\u0432)":l.week!=="all"?"\u0412\u044B\u043F\u0443\u0441\u043A\u0430 \u043C\u043E\u0434\u0435\u043B\u0438 \u0437\u0430 \u043D\u0435\u0434\u0435\u043B\u044E \u043D\u0435\u0442 \u2014 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u0434\u043E\u043B\u044F \u043E\u0442 \u0432\u0441\u0435\u0445 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432":"\u0414\u043E\u043B\u044F \u043E\u0442 \u0432\u0441\u0435\u0445 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 \u043C\u043E\u0434\u0435\u043B\u0438";let We={};v.forEach(we=>{We[we.category]=(We[we.category]||0)+we.studs});let lt=Fi.filter(we=>We[we.key]).map(we=>{let Ye=We[we.key],It=ce?100*Ye/(ze*W):null;return{label:we.short,v:Ye,color:we.color,rate:It,right:It!=null?Cn(It):null}}).sort((we,Ye)=>Ye.v-we.v);ml(oe("catBars"),lt,Math.max(1,E),ce);let et={};v.forEach(we=>{et[we.location]=(et[we.location]||0)+we.studs});let ct=Object.entries(et).map(([we,Ye])=>{let It=Ue[we],cn=ce&&It?100*Ye/(It*W):null;return{label:It?we+" \xB7 "+It+" \u0448\u043F.":we,v:Ye,rate:cn,right:cn!=null?Cn(cn):null,title:It?"":"\u0421\u0445\u0435\u043C\u044B \u044D\u0442\u043E\u0439 \u0441\u0442\u0430\u043D\u0446\u0438\u0438 \u043D\u0435\u0442 \u2014 \u0447\u0438\u0441\u043B\u043E \u0448\u043F\u0438\u043B\u0435\u043A \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E"}}).sort((we,Ye)=>(we.label==="\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E")-(Ye.label==="\u041D\u0435 \u0443\u043A\u0430\u0437\u0430\u043D\u043E")||Ye.v-we.v);ml(oe("locBars"),ct,Math.max(1,E),ce&&ct.some(we=>we.rate!=null))}function Ph(g,v){if(!(g>0))return 1;let E=10**Math.floor(Math.log10(g)),T=g/E,D=v&&E<10?[1,2,5,10]:[1,2,2.5,5,10],O=10;for(let G of D)if(G>=T-1e-9){O=G;break}let W=O*E;return v?Math.max(1,Math.round(W)):W}function Hg(g){if(g<=0)return 1;let v=10**Math.floor(Math.log10(g)),E=g/v;return(E<=1?1:E<=2?2:E<=2.5?2.5:E<=5?5:10)*v}function xr(){let g=l.trendScope==="all",v=X=>g?n.volumeAll[X]||0:a(X),E=s.some(X=>v(X)>0);E||(l.trendMode="n");let T=l.trendMode==="pct";oe("trendMode").hidden=!E,oe("tctl").hidden=!E,oe("trendMode").querySelectorAll("button").forEach(X=>X.setAttribute("aria-pressed",String(X.dataset.m===l.trendMode))),oe("trendUnit").textContent=(g?"\xB7 \u0432\u0441\u0435 \u043C\u043E\u0434\u0435\u043B\u0438":"\xB7 "+l.model)+(T?" \xB7 \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u044C, %":" \xB7 \u0448\u043F\u0438\u043B\u0435\u043A");let D=(g?n.rows:_()).filter(X=>l.cats.has(X.category)),O=X=>X.model+"|"+mh(X),W=Fi.filter(X=>D.some(Le=>Le.category===X.key)),G=s.map(X=>{let Le=D.filter(Ee=>Ee.week===X),Fe=v(X),ht=W.map(Ee=>{let kt=Le.filter(Gi=>Gi.category===Ee.key),vi=kt.reduce((Gi,Oh)=>Gi+Oh.studs,0),yr=new Set(kt.map(O)).size;return{c:Ee,n:vi,b:yr,v:T?Fe?100*vi/Fe:0:vi}}),De=Le.reduce((Ee,kt)=>Ee+kt.studs,0),Et=new Set(Le.map(O)).size;return{w:X,vol:Fe,seg:ht,n:De,b:Et,total:T?Fe?100*De/Fe:null:De,top:ht.reduce((Ee,kt)=>Ee+kt.v,0)}}),se=oe("trend");se.replaceChildren();let xe=Math.max(300,Math.round(se.clientWidth||340)),Ue=xe>560?310:240,ze=xe>=440,ce=40,Xe=ze?182:10,We=22,lt=26,et=xe-ce-Xe,ct=Ue-We-lt,we=l.trendHidden,Ye=Math.max(T?.01:4,...G.flatMap(X=>X.total==null?[]:W.map((Le,Fe)=>we.has(Le.key)?0:X.seg[Fe].v||0))),It=Ph(Ye/3,!T),cn=Ye*1.1,Ke=X=>We+ct-ct*X/cn,qe=X=>G.length>1?ce+16+(et-32)*X/(G.length-1):ce+et/2,Mt=X=>T?Cn(X):yt(X),At=$t("svg",{viewBox:`0 0 ${xe} ${Ue}`,width:xe,height:Ue,role:"img","aria-label":"\u0422\u0440\u0435\u043D\u0434 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 \u043F\u043E \u043D\u0435\u0434\u0435\u043B\u044F\u043C: \u0432\u0441\u0435\u0433\u043E \u0438 \u043F\u043E \u0432\u0438\u0434\u0430\u043C. \u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u2014 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 \u043D\u0438\u0436\u0435."}),hn=[];for(let X=0;X<=Ye+It*1e-6;X+=It)hn.push(+X.toFixed(6));hn.forEach(X=>{$t("line",{x1:ce,x2:ce+et,y1:Ke(X),y2:Ke(X),class:X?"grid":"base"},At),$t("text",{x:ce-6,y:Ke(X)+3.5,class:"tick","text-anchor":"end"},At).textContent=Mt(X)});let un=G.findIndex(X=>X.w===l.week);un>=0&&$t("rect",{x:qe(un)-16,y:We-10,width:32,height:ct+10,rx:5,class:"selband"},At);let ai=$t("line",{x1:0,x2:0,y1:We-10,y2:We+ct,class:"cross"},At);ai.style.display="none";let Vi=X=>{let Le=[],Fe=[];return X.forEach((ht,De)=>{ht==null?(Fe.length&&Le.push(Fe),Fe=[]):Fe.push([qe(De),Ke(ht)])}),Fe.length&&Le.push(Fe),Le},Rh=X=>{let Le=X.length,Fe=Ee=>Ee.toFixed(1);if(Le<3)return X.map((Ee,kt)=>(kt?"L":"M")+Fe(Ee[0])+","+Fe(Ee[1])).join("");let ht=[],De=[];for(let Ee=0;Ee<Le-1;Ee++)ht.push((X[Ee+1][1]-X[Ee][1])/(X[Ee+1][0]-X[Ee][0]));De[0]=ht[0],De[Le-1]=ht[Le-2];for(let Ee=1;Ee<Le-1;Ee++)De[Ee]=ht[Ee-1]*ht[Ee]<=0?0:(ht[Ee-1]+ht[Ee])/2;for(let Ee=0;Ee<Le-1;Ee++){if(ht[Ee]===0){De[Ee]=0,De[Ee+1]=0;continue}let kt=De[Ee]/ht[Ee],vi=De[Ee+1]/ht[Ee],yr=kt*kt+vi*vi;if(yr>9){let Gi=3/Math.sqrt(yr);De[Ee]=Gi*kt*ht[Ee],De[Ee+1]=Gi*vi*ht[Ee]}}let Et="M"+Fe(X[0][0])+","+Fe(X[0][1]);for(let Ee=0;Ee<Le-1;Ee++){let kt=(X[Ee+1][0]-X[Ee][0])/3;Et+="C"+Fe(X[Ee][0]+kt)+","+Fe(X[Ee][1]+De[Ee]*kt)+" "+Fe(X[Ee+1][0]-kt)+","+Fe(X[Ee+1][1]-De[Ee+1]*kt)+" "+Fe(X[Ee+1][0])+","+Fe(X[Ee+1][1])}return Et},Ih=X=>Vi(X).map(Rh).join(""),wn=[],vl=W.map((X,Le)=>({c:X,k:Le,vals:G.map(Fe=>Fe.total==null?null:Fe.seg[Le].v),sum:G.reduce((Fe,ht)=>Fe+ht.seg[Le].n,0)})).filter(X=>!we.has(X.c.key)).sort((X,Le)=>X.sum-Le.sum),Dh=Math.max(1,...vl.map(X=>X.sum));if(vl.forEach(X=>{let Le=X.sum<Dh*.15;$t("path",{d:Ih(X.vals),fill:"none",stroke:X.c.color,"stroke-width":Le?1.5:2.5,"stroke-opacity":Le?.6:1,"stroke-linejoin":"round","stroke-linecap":"round"},At),X.vals.forEach((ht,De)=>{ht!=null&&$t("circle",{cx:qe(De),cy:Ke(ht),r:Le?2.5:3.5,fill:X.c.color,"fill-opacity":Le?.7:1,stroke:"#FBFAF7","stroke-width":1.5},At)});let Fe=-1;X.vals.forEach((ht,De)=>{ht!=null&&(Fe=De)}),Fe>=0&&wn.push({y0:Ke(X.vals[Fe]),x0:qe(Fe),text:X.c.short,val:Mt(X.vals[Fe]),color:X.c.color,minor:Le})}),ze&&wn.length){wn.sort((De,Et)=>De.y0-Et.y0);let X=16;wn.forEach((De,Et)=>{De.y=Et?Math.max(De.y0,wn[Et-1].y+X):De.y0});let Le=We+ct+4,Fe=wn.length;if(wn[Fe-1].y>Le){wn[Fe-1].y=Le;for(let De=Fe-2;De>=0;De--)wn[De].y=Math.min(wn[De].y,wn[De+1].y-X)}let ht=ce+et+10;wn.forEach(De=>{$t("path",{d:`M${De.x0+5},${De.y0}L${ht-6},${De.y}`,class:"elink"},At),$t("circle",{cx:ht,cy:De.y,r:3.5,fill:De.color},At);let Et=$t("text",{x:ht+8,y:De.y+4,class:"elab"+(De.minor?" minor":"")},At);Et.textContent=De.text+" ",$t("tspan",{class:"ev"},Et).textContent=De.val})}G.forEach((X,Le)=>$t("text",{x:qe(Le),y:Ue-6,class:"wk"+(Le===un?" on":""),"text-anchor":"middle"},At).textContent=X.w);let Rn=fe("div","ttip");Rn.hidden=!0;let bl=(X,Le)=>{Rn.replaceChildren();let Fe=fe("div","th",X.w+" \xB7 "+(T?X.total==null?"\u043D\u0435\u0442 \u0432\u044B\u043F\u0443\u0441\u043A\u0430":"\u0434\u0435\u0444\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u044C "+Cn(X.total):"\u0432\u0441\u0435\u0433\u043E "+yt(X.n)+" \u0448\u0442"));Rn.appendChild(Fe),X.vol&&Rn.appendChild(fe("div","tv","\u0432\u044B\u043F\u0443\u0441\u043A "+yt(X.vol)+" \xB7 \u043A\u0443\u0437\u043E\u0432\u043E\u0432 \u0441 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u043C "+yt(X.b)+" ("+Cn(100*X.b/X.vol)+")")),X.seg.slice().sort((De,Et)=>Et.n-De.n).forEach(De=>{if(!De.n)return;let Et=fe("div","tr"),Ee=fe("span","dot");Ee.style.background=De.c.color,Et.append(Ee,fe("span","",De.c.short),fe("b","",T?Cn(De.v)+" ("+De.n+" \u0448\u0442)":yt(De.n))),Rn.appendChild(Et)}),X.n||Rn.appendChild(fe("div","tv","\u0434\u0435\u0444\u0435\u043A\u0442\u043E\u0432 \u043D\u0435\u0442")),ai.setAttribute("x1",qe(Le)),ai.setAttribute("x2",qe(Le)),ai.style.display="";let ht=Le<G.length/2;Rn.style.left=(qe(Le)+(ht?14:-14))/xe*100+"%",Rn.style.transform=ht?"none":"translateX(-100%)",Rn.hidden=!1},Ml=()=>{Rn.hidden=!0,ai.style.display="none"};G.forEach((X,Le)=>{let Fe=Le===0?ce:(qe(Le-1)+qe(Le))/2,ht=Le===G.length-1?ce+et:(qe(Le)+qe(Le+1))/2,De=$t("rect",{x:Fe,y:0,width:ht-Fe,height:Ue,class:"hit",tabindex:0,role:"button","aria-pressed":String(l.week===X.w),"aria-label":X.w+": "+(T?X.total==null?"\u043D\u0435\u0442 \u0432\u044B\u043F\u0443\u0441\u043A\u0430":"\u0434\u0435\u0444\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u044C "+Cn(X.total):yt(X.n)+" \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A")+". \u041D\u0430\u0436\u043C\u0438\u0442\u0435, \u0447\u0442\u043E\u0431\u044B \u0432\u044B\u0431\u0440\u0430\u0442\u044C \u043D\u0435\u0434\u0435\u043B\u044E."},At);De.addEventListener("pointerenter",()=>bl(X,Le)),De.addEventListener("focus",()=>bl(X,Le)),De.addEventListener("pointerleave",Ml),De.addEventListener("blur",Ml);let Et=()=>{l.week=l.week===X.w?"all":X.w,Ui(!1)};De.addEventListener("click",Et),De.addEventListener("keydown",Ee=>{(Ee.key==="Enter"||Ee.key===" ")&&(Ee.preventDefault(),Et())})}),se.append(At,Rn);let wl=oe("trendLegend");wl.replaceChildren();let Nh=(X,Le)=>{let Fe=$t("svg",{viewBox:"0 0 22 10",width:22,height:10,"aria-hidden":"true"});return Le?$t("rect",{x:1,y:2,width:20,height:7,rx:2,class:"tarea-sw"},Fe):($t("line",{x1:1,x2:21,y1:5,y2:5,stroke:X,"stroke-width":2.5,"stroke-linecap":"round"},Fe),$t("circle",{cx:11,cy:5,r:3,fill:X},Fe)),Fe};W.forEach(X=>{let Le=fe("button","li"+(X.total?" tot":""));Le.type="button",Le.setAttribute("aria-pressed",String(!we.has(X.key))),Le.title=we.has(X.key)?"\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C":"\u0421\u043A\u0440\u044B\u0442\u044C",Le.append(Nh(X.color,X.total),document.createTextNode(X.short)),Le.onclick=()=>{we.has(X.key)?we.delete(X.key):we.add(X.key),xr()},wl.appendChild(Le)});let Sl=oe("trendTable");Sl.replaceChildren();let Io=fe("table","ttab"),Do=fe("tr");Do.appendChild(fe("th","",T?"\u0414\u0435\u0444\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u044C, %":"\u0414\u0435\u0444\u0435\u043A\u0442\u043E\u0432, \u0448\u0442")),G.forEach(X=>Do.appendChild(fe("th",l.week===X.w?"on":"",X.w)));let Tl=fe("thead");Tl.appendChild(Do),Io.appendChild(Tl);let Al=fe("tbody"),_r=(X,Le,Fe,ht)=>{let De=fe("tr",Fe||""),Et=fe("td");if(ht){let Ee=fe("span","dot");Ee.style.background=ht,Et.appendChild(Ee)}Et.appendChild(document.createTextNode(X)),De.appendChild(Et),Le.forEach((Ee,kt)=>De.appendChild(fe("td",l.week===G[kt].w?"on":"",Ee))),Al.appendChild(De)};W.forEach((X,Le)=>_r(X.short,G.map(Fe=>T?Fe.vol?Cn(Fe.seg[Le].v):"\u2014":yt(Fe.seg[Le].n)),"",X.color)),_r("\u0412\u0441\u0435\u0433\u043E",G.map(X=>X.total==null?"\u2014":T?Cn(X.total):yt(X.total)),"tot"),E&&(_r("\u0412\u044B\u043F\u0443\u0441\u043A, \u043A\u0443\u0437\u043E\u0432\u043E\u0432",G.map(X=>X.vol?yt(X.vol):"\u2014"),"sub"),_r("\u041A\u0443\u0437\u043E\u0432\u043E\u0432 \u0441 \u0434\u0435\u0444\u0435\u043A\u0442\u043E\u043C",G.map(X=>X.vol?Cn(100*X.b/X.vol):"\u2014"),"sub")),Io.appendChild(Al),Sl.appendChild(Io),oe("trendNote").textContent=T?"\u0414\u0435\u0444\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u044C = \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A / \u0432\u044B\u043F\u0443\u0441\u043A \u043D\u0435\u0434\u0435\u043B\u0438 \xD7 100, \u043A\u0430\u043A \u0432 WEEKLY ANALYSIS.":""}oe("trendMode").querySelectorAll("button").forEach(g=>{g.onclick=()=>{l.trendMode=g.dataset.m,xr()}});let gl="stud-map.trendTable",xl=(g,v)=>{if(oe("trendTable").hidden=!g,oe("tblMore").setAttribute("aria-expanded",String(g)),oe("tblMore").firstChild.textContent=g?"\u0421\u043A\u0440\u044B\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443":"\u0422\u0430\u0431\u043B\u0438\u0446\u0430",v)try{localStorage.setItem(gl,g?"1":"0")}catch{}};xl((()=>{try{return localStorage.getItem(gl)==="1"}catch{return!1}})(),!1),oe("tblMore").onclick=()=>xl(oe("trendTable").hidden,!0);let _l=0;new ResizeObserver(()=>{let g=Math.round(oe("trend").clientWidth);g&&Math.abs(g-_l)>8&&(_l=g,xr())}).observe(oe("trend"));function Ps(){let g=oe("studList");g.replaceChildren();let v=l.mode==="body";oe("studsTitle").textContent=v?"\u0414\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0435 \u0448\u043F\u0438\u043B\u044C\u043A\u0438 \u043D\u0430 \u043A\u0443\u0437\u043E\u0432\u0435":"\u0428\u043F\u0438\u043B\u044C\u043A\u0438 \u043D\u0430 \u044D\u0442\u043E\u043C \u0432\u0438\u0434\u0435";let E=v?Oe():f(l.view),D=(v?Ft(l.model).map(O=>({no:O.no,part:O.part,pts:O.pts})):l.view.studs).map(O=>({s:O,rs:E.get(O.no)||[]})).filter(O=>O.rs.length).sort((O,W)=>W.rs.length-O.rs.length||O.s.no-W.s.no);if(!D.length){g.appendChild(fe("p","empty",v?"\u0423 \u044D\u0442\u043E\u0439 \u043C\u043E\u0434\u0435\u043B\u0438 \u043D\u0435\u0442 \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A \u0441 \u043D\u043E\u043C\u0435\u0440\u043E\u043C \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0435.":"\u041D\u0430 \u044D\u0442\u043E\u043C \u0432\u0438\u0434\u0435 \u043D\u0435\u0442 \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u043C \u0444\u0438\u043B\u044C\u0442\u0440\u0435."));return}D.forEach(({s:O,rs:W})=>{let G=fe("button","studbtn");G.type="button",l.selected===O.no&&G.setAttribute("aria-current","true");let se=fe("span","mid");[...new Set(W.map(Ue=>Ue.category))].forEach(Ue=>{let ze=fe("span","dot");ze.style.background=oi[Ue].color,ze.title=Ue,se.appendChild(ze)});let xe=n.parts[O.part];se.appendChild(fe("span","pn",xe?xe.pn:"")),G.append(fe("span","no","\u2116"+O.no),se,fe("span","cnt","\xD7"+W.reduce((Ue,ze)=>Ue+ze.studs,0))),G.onclick=()=>mr(O),g.appendChild(G)})}function Ls(){let g=oe("info");if(g.replaceChildren(),l.zone&&l.mode==="body"){let ce=(Te().get(l.zone)||[]).slice().sort((ct,we)=>ct.date.localeCompare(we.date)),Xe=ce.reduce((ct,we)=>ct+we.studs,0),We=fe("div","card"),lt=fe("div");lt.append(fe("div","title","\u0421\u0442\u0430\u043D\u0446\u0438\u044F "+l.zone),fe("div","pn",yt(Xe)+" \u0434\u0435\u0444\u0435\u043A\u0442\u043D\u044B\u0445 \u0448\u043F\u0438\u043B\u0435\u043A \u0431\u0435\u0437 \u043D\u043E\u043C\u0435\u0440\u0430")),We.appendChild(lt),We.appendChild(fe("p","note","\u0412 \u0440\u0435\u0435\u0441\u0442\u0440\u0435 \u0443 \u044D\u0442\u0438\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u043D\u0435 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D \xAB\u041D\u043E\u043C\u0435\u0440 \u0448\u043F\u0438\u043B\u044C\u043A\u0438\xBB, \u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u0442\u043E\u0447\u043D\u043E\u0433\u043E \u043C\u0435\u0441\u0442\u0430 \u043D\u0430 \u043A\u0443\u0437\u043E\u0432\u0435 \u043D\u0435\u0442 \u2014 \u043F\u043E\u0434\u0441\u0432\u0435\u0447\u0435\u043D\u0430 \u0437\u043E\u043D\u0430 \u0441\u0442\u0430\u043D\u0446\u0438\u0438. \u0417\u0430\u043F\u0438\u0441\u0435\u0439: "+ce.length+"."));let et=fe("div","hist");ce.forEach(ct=>{let we=fe("div"),Ye=fe("span","c"),It=fe("span","dot");It.style.background=oi[ct.category].color,Ye.append(It,document.createTextNode(ct.category));let cn=fe("span","x","\u043A\u0443\u0437\u043E\u0432 "+(ct.body_no||"\u2014")+(ct.studs>1?" \xB7 "+ct.studs+" \u0448\u0442":""));ct.mass&&cn.appendChild(fe("span","tag","\u043C\u0430\u0441\u0441\u043E\u0432\u043E\u0435")),we.append(fe("span","",So(ct.date)),fe("span","",ct.week),Ye,cn),et.appendChild(we)}),We.appendChild(et),g.appendChild(We);return}let v=l.mode==="body"?Ft(l.model):l.view.studs,E=l.selected!=null?v.find(ce=>ce.no===l.selected):null;if(!E){g.appendChild(fe("p","empty","\u041D\u0430\u0436\u043C\u0438\u0442\u0435 \u043D\u0430 \u0448\u043F\u0438\u043B\u044C\u043A\u0443 \u043D\u0430 \u0441\u0445\u0435\u043C\u0435 \u0438\u043B\u0438 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435."));return}let T=n.parts[E.part]||{},D=n.rows.filter(ce=>ce.model===l.model&&ce.stud_no===E.no).sort((ce,Xe)=>ce.date.localeCompare(Xe.date)),O=p(l.model).filter(ce=>ce.studs.some(Xe=>Xe.no===E.no)).map(ce=>ce.name).join(", "),W=fe("div","card"),G=fe("div","head"),se=fe("img","photo");se.src="parts/"+encodeURIComponent(E.part)+".png",se.alt="\u0424\u043E\u0442\u043E \u0448\u043F\u0438\u043B\u044C\u043A\u0438 "+(T.pn||""),se.loading="lazy",se.width=64,se.height=64;let xe=fe("div");xe.append(fe("div","title","\u0428\u043F\u0438\u043B\u044C\u043A\u0430 \u2116"+E.no),fe("div","pn",T.pn||"\u2014"),fe("div","note",T.name||"")),G.append(se,xe),W.appendChild(G);let Ue=[...new Set(D.map(ce=>ce.location))].join(", ");W.appendChild(fe("p","note","\u0421\u0445\u0435\u043C\u0430: "+(O||"\u2014")+(Ue?" \xB7 \u0441\u0442\u0430\u043D\u0446\u0438\u044F: "+Ue:"")+" \xB7 \u0432\u0441\u0435\u0433\u043E \u0437\u0430\u043F\u0438\u0441\u0435\u0439: "+D.length));let ze=fe("div","hist");D.forEach(ce=>{let Xe=fe("div");(!m(ce)||!l.cats.has(ce.category))&&(Xe.className="off");let We=fe("span","c"),lt=fe("span","dot");lt.style.background=oi[ce.category].color,We.append(lt,document.createTextNode(ce.category));let et=fe("span","x","\u043A\u0443\u0437\u043E\u0432 "+(ce.body_no||"\u2014"));ce.mass&&et.appendChild(fe("span","tag","\u043C\u0430\u0441\u0441\u043E\u0432\u043E\u0435")),Xe.append(fe("span","",So(ce.date)),fe("span","",ce.week),We,et),ze.appendChild(Xe)}),W.appendChild(ze),g.appendChild(W)}function Lh(){let g=oe("legend");g.replaceChildren(),[["ok","#C47A48","\u041D\u043E\u0440\u043C\u0430 (\u0448\u043F\u0438\u043B\u044C\u043A\u0430 \u0432\u0438\u0434\u0430)"]].concat(Fi.map(v=>[v.mode,v.color,v.short+" \u2014 "+v.what])).forEach(([v,E,T])=>{let D=fe("div");D.append(Ah(v,E),fe("span","",T)),g.appendChild(D)})}function yl(){Ps(),Ls(),l.mode==="2d"?Co():Ie()}function Ui(g){Sh(),pl(),Th(),Eh(),Ch(),xr(),Ps(),Ls(),vh(),l.mode!=="init"&&(l.mode==="2d"?Co():l.mode==="body"?g?Bn():Ie():g?Qe(l.view):Ie())}function Wg(){}if(oe("ghost").onchange=g=>{l.ghost=g.target.checked,l.mode!=="2d"&&Ie()},M){let g=()=>{let v=N.clientWidth,E=N.clientHeight;!v||!E||(y.setSize(v,E,!1),x.aspect=v/E,x.updateProjectionMatrix(),Z())};new ResizeObserver(g).observe(N),g(),document.addEventListener("visibilitychange",()=>{document.hidden||Z()})}Lh(),fl(),l.mode="init",Ui(!1),Bi(M?"body":"2d"),Cs(),window.__viz={state:l,DATA:n,select:mr,get frames(){return $},get tex(){return[...it.keys()]},cam:()=>M?{p:x.position.toArray().map(g=>+g.toFixed(2)),t:P.target.toArray().map(g=>+g.toFixed(2))}:null,get info(){return M?{calls:y.info.render.calls,tris:y.info.render.triangles,objects:Y.children.length}:null}}}Gg();})();
